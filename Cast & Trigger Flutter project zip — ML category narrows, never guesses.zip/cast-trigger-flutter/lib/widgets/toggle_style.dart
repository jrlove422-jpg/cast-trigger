import 'package:flutter/material.dart';

/// Toggle styling (2026-11-05, George's direction).
///
/// The old pattern made the SELECTED button look unselected: a
/// Fish/Hunt ElevatedButton used `onPressed: null` when selected,
/// so the selected button was the disabled dark-grey one and the
/// unselected button was the moss-green lit one — exactly
/// backwards. The rule now, everywhere in the app:
/// - SELECTED = gold background (0xFFD4AF37) with dark text.
/// - UNSELECTED = dark grey background with light text.
/// - Both buttons are always tappable; tapping the already
///   selected one is a no-op, never a disabled (null) button.
class ToggleStyle {
  static const Color gold = Color(0xFFD4AF37);
  static const Color goldText = Color(0xFF121417);
  static const Color dark = Color(0xFF2A2F33);
  static const Color darkText = Color(0xFFE8E8E8);

  /// Style for a two-button Fish/Hunt-style toggle. Pass true
  /// for the button that is currently selected.
  static ButtonStyle kindButton(bool selected) {
    return ElevatedButton.styleFrom(
      backgroundColor: selected ? gold : dark,
      foregroundColor: selected ? goldText : darkText,
    );
  }

  /// Style for every SegmentedButton in the app (Scout /
  /// Catch-Harvest, Standard / Topographic, share-card
  /// placement): the selected segment is gold-lit with dark
  /// text, unselected segments are dark with light text.
  static ButtonStyle segmented<T>() {
    return SegmentedButton.styleFrom(
      selectedBackgroundColor: gold,
      selectedForegroundColor: goldText,
      backgroundColor: dark,
      foregroundColor: darkText,
    );
  }
}
