import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Drawn map pins — no emoji.
///
/// The old Spots pins were emoji glyphs on a dark circle ('🐟🦴',
/// a fish emoji next to a bone emoji), which read as two unrelated
/// pictures side by side. The prototype's pins are drawn bone SVGs
/// in bone-white on a dark pin (fish skeleton, deer skull +
/// antlers, bird skull, squirrel skull + buck teeth, predator
/// skull), one per species family. Those five SVG paths are
/// transcribed here into a CustomPainter (same 24x24 viewBox,
/// same stroke geometry), so the Flutter pin is the same drawing
/// as the prototype's, without adding a plugin dependency.
///
/// Scout = live animal (filled silhouette of the same family,
/// moss-green pin). Catch/Harvest = bone (stroke drawing,
/// bone-white on a dark pin). The family follows the species
/// automatically; there is no pin-style toggle.
enum PinFamily { fish, deer, bird, squirrel, predator, unknown }

PinFamily pinFamilyForSpecies(String species, bool isFish) {
  if (isFish) return PinFamily.fish;
  if (species == 'Whitetail Deer') return PinFamily.deer;
  if (species == 'Wild Turkey' ||
      species == 'Ruffed Grouse' ||
      species == 'Northern Bobwhite Quail' ||
      species == 'Mourning Dove' ||
      species == 'American Woodcock') {
    return PinFamily.bird;
  }
  if (species.contains('Squirrel')) return PinFamily.squirrel;
  if (species == 'Coyote' ||
      species.contains('Fox') ||
      species == 'Bobcat') {
    return PinFamily.predator;
  }
  return PinFamily.unknown;
}

/// A map pin: dark (bone) or moss-green (Scout) teardrop with the
/// species family's glyph drawn inside it. The log-card icon is
/// the same widget at a smaller size, so card and map always match.
class PinMarker extends StatelessWidget {
  const PinMarker({
    super.key,
    required this.family,
    required this.isBone,
    this.width = 40,
    this.height = 52,
  });

  final PinFamily family;
  final bool isBone;
  final double width;
  final double height;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: CustomPaint(
        painter: _PinPainter(family: family, isBone: isBone),
      ),
    );
  }
}

class _PinPainter extends CustomPainter {
  _PinPainter({required this.family, required this.isBone});

  final PinFamily family;
  final bool isBone;

  static const Color boneWhite = Color(0xFFF5F0E1);
  static const Color boneDark = Color(0xFF171912);
  static const Color moss = Color(0xFF6B8F5E);

  @override
  void paint(Canvas canvas, Size size) {
    // Teardrop pin: circle on top, point at the bottom. The glyph
    // lives in a 24x24 box inside the circle.
    final scale = size.width / 40;
    canvas.save();
    canvas.scale(scale, scale);
    final pinPaint = Paint()
      ..color = isBone ? boneDark : moss
      ..style = PaintingStyle.fill;
    final borderPaint = Paint()
      ..color = boneWhite
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    final cx = 20.0;
    final cy = 18.0;
    const r = 16.0;
    // Teardrop: bottom point, then the circle's lower-left point,
    // then a 270-degree arc over the top to the lower-right point,
    // then back to the bottom point. (Canvas angles: 0 = east,
    // pi/2 = south, so the lower-left point is at 0.75*pi and the
    // arc sweeps +1.5*pi over the top to 0.25*pi.)
    final teardrop = Path()
      ..moveTo(cx, 50)
      ..lineTo(cx - r * 0.707, cy + r * 0.707)
      ..arcTo(
        Rect.fromCircle(center: Offset(cx, cy), radius: r),
        math.pi * 0.75,
        math.pi * 1.5,
        false,
      )
      ..lineTo(cx, 50)
      ..close();
    canvas.drawPath(teardrop, pinPaint);
    canvas.drawPath(teardrop, borderPaint);
    // Glyph box: 24x24, top-left (8, 6) in the 40x52 pin space.
    canvas.translate(8, 6);
    if (isBone) {
      _paintBone(canvas, family);
    } else {
      _paintLive(canvas, family);
    }
    canvas.restore();
  }

  // ---- Bone drawings: stroke, bone-white, transcribed from the
  // prototype's PIN_BONE_SVGS (24x24 viewBox). ----
  void _paintBone(Canvas canvas, PinFamily family) {
    final stroke = Paint()
      ..color = boneWhite
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.7
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final fill = Paint()
      ..color = boneWhite
      ..style = PaintingStyle.fill;
    switch (family) {
      case PinFamily.fish:
        // Fish skeleton: head, spine, ribs, tail fork.
        final head = Path()
          ..moveTo(2.6, 12)
          ..cubicTo(2.6, 9.7, 4.4, 8, 6.8, 8)
          ..lineTo(8.5, 10)
          ..lineTo(8.5, 14)
          ..lineTo(6.8, 16)
          ..cubicTo(4.4, 16, 2.6, 14.3, 2.6, 12)
          ..close();
        canvas.drawPath(head, stroke);
        canvas.drawCircle(const Offset(5.4, 11), 0.9, fill);
        canvas.drawLine(const Offset(8.5, 12), const Offset(19.1, 12), stroke);
        for (final x in [11.0, 14.0, 16.8]) {
          canvas.drawLine(Offset(x, 12), Offset(x - 1, 8.9), stroke);
          canvas.drawLine(Offset(x, 12), Offset(x - 1, 15.1), stroke);
        }
        canvas.drawLine(const Offset(19.1, 12), const Offset(21.7, 8.9), stroke);
        canvas.drawLine(const Offset(19.1, 12), const Offset(21.7, 15.1), stroke);
      case PinFamily.deer:
        // Deer skull + antlers.
        final antlers = Path()
          ..moveTo(8.6, 8.2)
          ..cubicTo(6.7, 6.8, 5.7, 4.9, 6.0, 2.7)
          ..moveTo(6.9, 5.4)
          ..cubicTo(5.8, 5.0, 4.8, 5.1, 4.0, 5.8)
          ..moveTo(8.6, 8.2)
          ..cubicTo(9.0, 6.2, 9.9, 4.9, 11.1, 4.2)
          ..moveTo(15.4, 8.2)
          ..cubicTo(17.3, 6.8, 18.3, 4.9, 18.0, 2.7)
          ..moveTo(17.1, 5.4)
          ..cubicTo(18.2, 5.0, 19.2, 5.1, 20.0, 5.8)
          ..moveTo(15.4, 8.2)
          ..cubicTo(15.0, 6.2, 14.1, 4.9, 12.9, 4.2);
        canvas.drawPath(antlers, stroke);
        final skull = Path()
          ..moveTo(8.9, 7.6)
          ..lineTo(15.1, 7.6)
          ..lineTo(14.2, 13.4)
          ..lineTo(13.1, 19.3)
          ..lineTo(10.9, 19.3)
          ..lineTo(9.8, 13.4)
          ..close();
        canvas.drawPath(skull, stroke);
        canvas.drawCircle(const Offset(10.7, 11), 1, fill);
        canvas.drawCircle(const Offset(13.3, 11), 1, fill);
        canvas.drawLine(const Offset(11, 16.6), const Offset(13, 16.6), stroke);
      case PinFamily.bird:
        // Bird skull: round head, beak, leg.
        canvas.drawCircle(const Offset(8.8, 9.2), 4.4, stroke);
        canvas.drawCircle(const Offset(7.8, 8.4), 1, fill);
        final beak = Path()
          ..moveTo(12.4, 7.2)
          ..lineTo(21, 10)
          ..lineTo(12.6, 12.2);
        canvas.drawPath(beak, stroke);
        canvas.drawLine(const Offset(12.9, 12.9), const Offset(18.1, 12), stroke);
        canvas.drawLine(const Offset(7.2, 13.2), const Offset(5.6, 17), stroke);
        canvas.drawLine(const Offset(5.6, 17), const Offset(3.8, 19.4), stroke);
        canvas.drawLine(const Offset(5.6, 17), const Offset(8.6, 17), stroke);
      case PinFamily.squirrel:
        // Squirrel skull: ears, round head, buck teeth.
        canvas.drawLine(const Offset(8.7, 6.2), const Offset(8, 3.6), stroke);
        canvas.drawLine(const Offset(15.3, 6.2), const Offset(16, 3.6), stroke);
        canvas.drawCircle(const Offset(12, 10.2), 5, stroke);
        canvas.drawCircle(const Offset(10, 9.6), 1.1, fill);
        canvas.drawCircle(const Offset(14, 9.6), 1.1, fill);
        final teeth = Path()
          ..moveTo(10.6, 14.6)
          ..lineTo(10.6, 18.4)
          ..lineTo(13.4, 18.4)
          ..lineTo(13.4, 14.6)
          ..moveTo(12, 14.6)
          ..lineTo(12, 18.4);
        canvas.drawPath(teeth, stroke);
      case PinFamily.predator:
        // Predator skull: pointed ear, round head, snout.
        final ear = Path()
          ..moveTo(6.2, 6.8)
          ..lineTo(7.2, 3.6)
          ..lineTo(9.6, 5.6);
        canvas.drawPath(ear, stroke);
        canvas.drawCircle(const Offset(8.6, 10), 4.3, stroke);
        canvas.drawCircle(const Offset(7.6, 9.2), 1, fill);
        final snout = Path()
          ..moveTo(12.2, 8.4)
          ..lineTo(19.4, 10.4)
          ..lineTo(19.4, 13.2)
          ..lineTo(12.5, 13.8);
        canvas.drawPath(snout, stroke);
        canvas.drawLine(const Offset(16.4, 13.2), const Offset(15.7, 15.8), stroke);
        canvas.drawLine(const Offset(15.7, 15.8), const Offset(14.7, 13.4), stroke);
      case PinFamily.unknown:
        // A plain bone: shaft with a knob at each end.
        canvas.drawLine(const Offset(7, 12), const Offset(17, 12), stroke);
        canvas.drawCircle(const Offset(6, 10.5), 1.6, fill);
        canvas.drawCircle(const Offset(6, 13.5), 1.6, fill);
        canvas.drawCircle(const Offset(18, 10.5), 1.6, fill);
        canvas.drawCircle(const Offset(18, 13.5), 1.6, fill);
    }
  }

  // ---- Live drawings: filled silhouette of the same family, in
  // bone-white on the moss-green pin, so a Scout pin never looks
  // like a skeleton. ----
  void _paintLive(Canvas canvas, PinFamily family) {
    final fill = Paint()
      ..color = boneWhite
      ..style = PaintingStyle.fill;
    final stroke = Paint()
      ..color = boneWhite
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.7
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final dark = Paint()
      ..color = moss
      ..style = PaintingStyle.fill;
    switch (family) {
      case PinFamily.fish:
        final body = Path()
          ..moveTo(3, 12)
          ..cubicTo(3, 8.5, 6, 7, 10, 7)
          ..lineTo(16, 7)
          ..lineTo(19, 12)
          ..lineTo(16, 17)
          ..lineTo(10, 17)
          ..cubicTo(6, 17, 3, 15.5, 3, 12)
          ..close();
        canvas.drawPath(body, fill);
        final tail = Path()
          ..moveTo(19, 12)
          ..lineTo(22.5, 8.5)
          ..lineTo(22.5, 15.5)
          ..close();
        canvas.drawPath(tail, fill);
        canvas.drawCircle(const Offset(6.5, 11), 1, dark);
      case PinFamily.deer:
        // Filled skull + stroked antlers (same antler paths as bone).
        final skull = Path()
          ..moveTo(8.9, 7.6)
          ..lineTo(15.1, 7.6)
          ..lineTo(14.2, 13.4)
          ..lineTo(13.1, 19.3)
          ..lineTo(10.9, 19.3)
          ..lineTo(9.8, 13.4)
          ..close();
        canvas.drawPath(skull, fill);
        canvas.drawLine(const Offset(8.6, 8.2), const Offset(6, 2.7), stroke);
        canvas.drawLine(const Offset(8.6, 8.2), const Offset(11.1, 4.2), stroke);
        canvas.drawLine(const Offset(15.4, 8.2), const Offset(18, 2.7), stroke);
        canvas.drawLine(const Offset(15.4, 8.2), const Offset(12.9, 4.2), stroke);
        canvas.drawCircle(const Offset(10.7, 11), 1, dark);
        canvas.drawCircle(const Offset(13.3, 11), 1, dark);
      case PinFamily.bird:
        canvas.drawCircle(const Offset(9, 10), 5.5, fill);
        final beak = Path()
          ..moveTo(13.5, 8)
          ..lineTo(21, 10.5)
          ..lineTo(13.5, 13)
          ..close();
        canvas.drawPath(beak, fill);
        canvas.drawCircle(const Offset(7.5, 9), 1, dark);
      case PinFamily.squirrel:
        canvas.drawCircle(const Offset(12, 11), 5.5, fill);
        final earL = Path()
          ..moveTo(8.5, 7)
          ..lineTo(7.5, 3.5)
          ..lineTo(10.5, 6)
          ..close();
        final earR = Path()
          ..moveTo(15.5, 7)
          ..lineTo(16.5, 3.5)
          ..lineTo(13.5, 6)
          ..close();
        canvas.drawPath(earL, fill);
        canvas.drawPath(earR, fill);
        canvas.drawCircle(const Offset(10, 10.5), 1, dark);
        canvas.drawCircle(const Offset(14, 10.5), 1, dark);
        // Bushy tail, stroked.
        final tail = Path()
          ..moveTo(17, 13)
          ..cubicTo(21, 12, 21.5, 7, 18.5, 5.5);
        canvas.drawPath(tail, stroke);
      case PinFamily.predator:
        canvas.drawCircle(const Offset(11, 11), 5.5, fill);
        final earL = Path()
          ..moveTo(7, 7.5)
          ..lineTo(6, 3.5)
          ..lineTo(9.5, 5.5)
          ..close();
        final earR = Path()
          ..moveTo(15, 7.5)
          ..lineTo(16, 3.5)
          ..lineTo(12.5, 5.5)
          ..close();
        canvas.drawPath(earL, fill);
        canvas.drawPath(earR, fill);
        final snout = Path()
          ..moveTo(14, 9)
          ..lineTo(20, 11)
          ..lineTo(14, 14.5)
          ..close();
        canvas.drawPath(snout, fill);
        canvas.drawCircle(const Offset(9, 10), 1, dark);
      case PinFamily.unknown:
        // Paw print.
        canvas.drawCircle(const Offset(12, 14), 3.2, fill);
        canvas.drawCircle(const Offset(8, 9), 1.6, fill);
        canvas.drawCircle(const Offset(12, 8), 1.6, fill);
        canvas.drawCircle(const Offset(16, 9), 1.6, fill);
    }
  }

  @override
  bool shouldRepaint(covariant _PinPainter old) =>
      old.family != family || old.isBone != isBone;
}
