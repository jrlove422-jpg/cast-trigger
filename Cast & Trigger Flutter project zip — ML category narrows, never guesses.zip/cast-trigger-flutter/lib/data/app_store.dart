import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'wv_data.dart';

/// One planned trip. A trip saved from the Planner is NOT auto-created.
/// A trip created by the Spots trip-ask is flagged [autoCreated] and is
/// removed again if its log is removed; a pre-existing trip that a log
/// was tied to STAYS when that log is removed.
class Trip {
  Trip({
    required this.id,
    required this.date,
    DateTime? endDate,
    required this.species,
    required this.isFish,
    required this.county,
    required this.place,
    this.weapon = '',
    this.autoCreated = false,
  }) : endDate = endDate ?? date;

  final String id;
  final DateTime date; // start date only (midnight)
  final DateTime endDate; // end date only (midnight); == date = 1 day
  final String species;
  final bool isFish;
  final String county;
  final String place; // water, or hunting area
  final String weapon;
  final bool autoCreated;

  static DateTime dateOnly(DateTime d) => DateTime(d.year, d.month, d.day);

  /// Multi-day when end is after start. A single-day trip is a
  /// range where start == end, so old saved trips still work.
  bool get isMultiDay => dateOnly(endDate).isAfter(dateOnly(date));

  /// Number of days in the range, inclusive (1 for a single day).
  int get durationDays =>
      dateOnly(endDate).difference(dateOnly(date)).inDays + 1;

  /// True when [d] falls on any day of this trip, start..end.
  bool coversDate(DateTime d) {
    final day = dateOnly(d);
    return !day.isBefore(dateOnly(date)) &&
        !day.isAfter(dateOnly(endDate));
  }

  static const List<String> _monthAbbr = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
  ];

  /// Short display, e.g. "Nov 7", "Nov 7–14", "Nov 30–Dec 2",
  /// "Dec 30, 2026–Jan 2, 2027". Year shown when the range
  /// crosses a year boundary, or for a single day.
  String get rangeLabel {
    final start = dateOnly(date);
    final end = dateOnly(endDate);
    String md(DateTime d) => '${_monthAbbr[d.month - 1]} ${d.day}';
    if (!isMultiDay) return '${md(start)}, ${start.year}';
    if (start.year == end.year) {
      if (start.month == end.month) {
        return '${_monthAbbr[start.month - 1]} ${start.day}–${end.day}, '
            '${start.year}';
      }
      return '${md(start)}–${md(end)}, ${start.year}';
    }
    return '${md(start)}, ${start.year}–${md(end)}, ${end.year}';
  }

  /// Duration text, e.g. "1 day" / "8 days".
  String get durationLabel =>
      durationDays == 1 ? '1 day' : '$durationDays days';

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'endDate': endDate.toIso8601String(),
        'species': species,
        'isFish': isFish,
        'county': county,
        'place': place,
        'weapon': weapon,
        'autoCreated': autoCreated,
      };

  factory Trip.fromJson(Map<String, dynamic> j) {
    final start = DateTime.parse(j['date'] as String);
    // Migration: trips saved before endDate existed have no
    // 'endDate' key — they are single-day trips, end == start.
    final endRaw = j['endDate'] as String?;
    return Trip(
      id: j['id'] as String,
      date: start,
      endDate: endRaw != null ? DateTime.parse(endRaw) : start,
      species: j['species'] as String,
      isFish: j['isFish'] as bool,
      county: j['county'] as String,
      place: j['place'] as String,
      weapon: (j['weapon'] as String?) ?? '',
      autoCreated: (j['autoCreated'] as bool?) ?? false,
    );
  }
}

/// One log entry: a Scout spot OR a Catch/Harvest.
/// Scout entries NEVER feed Stats. Catch/Harvest entries feed Stats.
/// No GPS is ever put in a share card: [place] + [county] only.
/// [lat]/[lng] are used ONLY for the on-device Spots map pin.
/// Manual lat/lng, if entered, always wins. If blank, the store
/// auto-assigns the prototype's water/county reference pin for the
/// log's place (pinForPlace in wv_data.dart): a known water pins at
/// that water, otherwise the county seat area (county-level, never
/// the exact spot). A place matching neither is listed by name with
/// no pin, and no coordinates are ever invented for it.
class LogEntry {
  LogEntry({
    required this.id,
    required this.isScout,
    required this.isFish,
    required this.species,
    required this.date,
    required this.county,
    required this.place,
    this.lengthIn,
    this.weightLb,
    this.baitOrWeapon = '',
    this.shotDistanceYds,
    this.photoPath,
    this.lat,
    this.lng,
    this.tripId,
    this.tripAutoCreated = false,
  });

  final String id;
  final bool isScout;
  final bool isFish;
  final String species;
  final DateTime date;
  final String county;
  final String place;
  final double? lengthIn;
  final double? weightLb; // estimated for fish, manual/estimated for game
  final String baitOrWeapon;
  final int? shotDistanceYds;
  final String? photoPath;
  final double? lat;
  final double? lng;
  final String? tripId;
  final bool tripAutoCreated;

  LogEntry copyWith({
    bool? isScout,
    bool? isFish,
    String? species,
    DateTime? date,
    String? county,
    String? place,
    double? lengthIn,
    double? weightLb,
    String? baitOrWeapon,
    int? shotDistanceYds,
    String? photoPath,
    double? lat,
    double? lng,
    String? tripId,
    bool? tripAutoCreated,
  }) {
    return LogEntry(
      id: id,
      isScout: isScout ?? this.isScout,
      isFish: isFish ?? this.isFish,
      species: species ?? this.species,
      date: date ?? this.date,
      county: county ?? this.county,
      place: place ?? this.place,
      lengthIn: lengthIn ?? this.lengthIn,
      weightLb: weightLb ?? this.weightLb,
      baitOrWeapon: baitOrWeapon ?? this.baitOrWeapon,
      shotDistanceYds: shotDistanceYds ?? this.shotDistanceYds,
      photoPath: photoPath ?? this.photoPath,
      lat: lat ?? this.lat,
      lng: lng ?? this.lng,
      tripId: tripId ?? this.tripId,
      tripAutoCreated: tripAutoCreated ?? this.tripAutoCreated,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'isScout': isScout,
        'isFish': isFish,
        'species': species,
        'date': date.toIso8601String(),
        'county': county,
        'place': place,
        'lengthIn': lengthIn,
        'weightLb': weightLb,
        'baitOrWeapon': baitOrWeapon,
        'shotDistanceYds': shotDistanceYds,
        'photoPath': photoPath,
        'lat': lat,
        'lng': lng,
        'tripId': tripId,
        'tripAutoCreated': tripAutoCreated,
      };

  factory LogEntry.fromJson(Map<String, dynamic> j) => LogEntry(
        id: j['id'] as String,
        isScout: j['isScout'] as bool,
        isFish: j['isFish'] as bool,
        species: j['species'] as String,
        date: DateTime.parse(j['date'] as String),
        county: j['county'] as String,
        place: j['place'] as String,
        lengthIn: (j['lengthIn'] as num?)?.toDouble(),
        weightLb: (j['weightLb'] as num?)?.toDouble(),
        baitOrWeapon: (j['baitOrWeapon'] as String?) ?? '',
        shotDistanceYds: (j['shotDistanceYds'] as num?)?.toInt(),
        photoPath: j['photoPath'] as String?,
        lat: (j['lat'] as num?)?.toDouble(),
        lng: (j['lng'] as num?)?.toDouble(),
        tripId: j['tripId'] as String?,
        tripAutoCreated: (j['tripAutoCreated'] as bool?) ?? false,
      );
}

/// Central, offline, on-device store. All Stats are DERIVED from
/// [logs] — nothing is hardcoded. The real app starts EMPTY for a
/// new user; prototype test logs are deliberately NOT seeded here.
class AppStore extends ChangeNotifier {
  AppStore._();

  static final AppStore instance = AppStore._();

  List<Trip> trips = [];
  List<LogEntry> logs = [];
  bool wholeAppLock = false;
  bool _loaded = false;

  /// A trip the user asked to load back into the Planner.
  /// PlannerScreen listens for this and applies it once.
  Trip? pendingPlannerTrip;

  static String newId() =>
      DateTime.now().microsecondsSinceEpoch.toString();

  Future<void> load() async {
    if (_loaded) return;
    _loaded = true;
    try {
      final prefs = await SharedPreferences.getInstance();
      final tripsRaw = prefs.getString('ct_trips');
      if (tripsRaw != null) {
        final list = jsonDecode(tripsRaw) as List<dynamic>;
        trips = list
            .map((e) => Trip.fromJson(e as Map<String, dynamic>))
            .toList();
      }
      final logsRaw = prefs.getString('ct_logs');
      if (logsRaw != null) {
        final list = jsonDecode(logsRaw) as List<dynamic>;
        logs = list
            .map((e) => LogEntry.fromJson(e as Map<String, dynamic>))
            .toList();
        // Migration: logs saved before auto-pin existed, with a
        // known water/county and no coordinates, pin now without
        // re-entering them.
        var migrated = false;
        logs = logs.map((l) {
          final pinned = _withAutoPin(l);
          if (!identical(pinned, l)) migrated = true;
          return pinned;
        }).toList();
        if (migrated) await _save();
      }
      wholeAppLock = prefs.getBool('ct_whole_app_lock') ?? false;
    } catch (_) {
      // Corrupt local data must never crash the app; start empty.
      trips = [];
      logs = [];
    }
    notifyListeners();
  }

  Future<void> _save() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(
        'ct_trips',
        jsonEncode(trips.map((t) => t.toJson()).toList()),
      );
      await prefs.setString(
        'ct_logs',
        jsonEncode(logs.map((l) => l.toJson()).toList()),
      );
    } catch (_) {
      // Offline persistence failure is surfaced by the caller if needed;
      // in-memory state is still usable for this session.
    }
  }

  /// Trips covering [date]: a single-day trip on that date, or a
  /// multi-day trip whose start..end range includes that date.
  /// This is what the Spots trip-ask and the calendar filter use,
  /// so a catch on day 4 of a week trip finds that trip.
  List<Trip> tripsForDate(DateTime date) {
    final found = trips.where((t) => t.coversDate(date)).toList();
    found.sort((a, b) => a.species.compareTo(b.species));
    return found;
  }

  Future<void> addTrip(Trip trip) async {
    trips.add(trip);
    trips.sort((a, b) => a.date.compareTo(b.date));
    notifyListeners();
    await _save();
  }

  Future<void> removeTrip(String id) async {
    trips.removeWhere((t) => t.id == id);
    notifyListeners();
    await _save();
  }

  /// Auto-pin a log that has no usable coordinates: manual lat/lng
  /// (both present) always wins; otherwise the prototype's water /
  /// county reference pin for the log's place, or the log unchanged
  /// when nothing matches (listed, no pin — never invented).
  LogEntry _withAutoPin(LogEntry log) {
    if (log.lat != null && log.lng != null) return log;
    final pin = pinForPlace(log.place, log.county);
    if (pin == null) return log;
    return log.copyWith(lat: pin.lat, lng: pin.lng);
  }

  Future<void> addLog(LogEntry log) async {
    logs.add(_withAutoPin(log));
    logs.sort((a, b) => b.date.compareTo(a.date));
    notifyListeners();
    await _save();
  }

  Future<void> updateLog(LogEntry updated) async {
    final index = logs.indexWhere((l) => l.id == updated.id);
    if (index >= 0) {
      logs[index] = _withAutoPin(updated);
      logs.sort((a, b) => b.date.compareTo(a.date));
      notifyListeners();
      await _save();
    }
  }

  /// Remove a log, cascading per spec: an auto-created trip goes with
  /// its log; a pre-existing trip that was tied to stays in Planned
  /// Trips. Stats re-derive automatically because they read [logs].
  Future<void> removeLog(String id) async {
    final index = logs.indexWhere((l) => l.id == id);
    if (index < 0) return;
    final log = logs[index];
    logs.removeAt(index);
    if (log.tripAutoCreated && log.tripId != null) {
      trips.removeWhere((t) => t.id == log.tripId);
    }
    notifyListeners();
    await _save();
  }

  Future<void> setWholeAppLock(bool value) async {
    wholeAppLock = value;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('ct_whole_app_lock', value);
    } catch (_) {}
  }

  void requestPlannerLoad(Trip trip) {
    pendingPlannerTrip = trip;
    notifyListeners();
  }

  void clearPendingPlannerTrip() {
    pendingPlannerTrip = null;
  }

  // ---- Stats, derived from logs only. No Hours anywhere. ----
  List<LogEntry> get catchLogs =>
      logs.where((l) => !l.isScout).toList();

  List<LogEntry> get scoutLogs => logs.where((l) => l.isScout).toList();

  /// Trips tile: one elapsed trip per Catch/Harvest log, per the
  /// prototype rule, counting only logs dated today or earlier.
  int get tripsCount {
    final today = Trip.dateOnly(DateTime.now());
    return catchLogs
        .where((l) => !Trip.dateOnly(l.date).isAfter(today))
        .length;
  }

  int get fishCount =>
      catchLogs.where((l) => l.isFish).length;

  int get gameCount =>
      catchLogs.where((l) => !l.isFish).length;

  bool isFishSpecies(String species) => fishSpecies.contains(species);

  /// Fish caught per month, newest first, as (label, count) pairs.
  /// Label is yyyy-MM; the Stats screen formats it for display.
  List<MapEntry<String, int>> fishByMonth() {
    final counts = <String, int>{};
    for (final log in catchLogs.where((l) => l.isFish)) {
      final key =
          '${log.date.year}-${log.date.month.toString().padLeft(2, '0')}';
      counts[key] = (counts[key] ?? 0) + 1;
    }
    final entries = counts.entries.toList()
      ..sort((a, b) => b.key.compareTo(a.key));
    return entries.take(12).toList();
  }

  /// Personal bests, strictly split by category. Only fields actually
  /// collected are used — no invented bests (e.g. no turkey-beard
  /// best, because beard length is not a collected field).
  List<String> fishBests() {
    final fish = catchLogs.where((l) => l.isFish).toList();
    if (fish.isEmpty) return [];
    final out = <String>[];
    LogEntry? longest;
    LogEntry? heaviest;
    LogEntry? largestBass;
    for (final log in fish) {
      if (log.lengthIn != null &&
          (longest == null || log.lengthIn! > (longest.lengthIn ?? 0))) {
        longest = log;
      }
      if (log.weightLb != null &&
          (heaviest == null || log.weightLb! > (heaviest.weightLb ?? 0))) {
        heaviest = log;
      }
      if (log.species.contains('Bass') &&
          log.lengthIn != null &&
          (largestBass == null ||
              log.lengthIn! > (largestBass.lengthIn ?? 0))) {
        largestBass = log;
      }
    }
    if (longest != null) {
      out.add(
        'Longest fish: ${longest.species} — ${longest.lengthIn} in',
      );
    }
    if (heaviest != null) {
      out.add(
        'Heaviest fish (est.): ${heaviest.species} — ~${heaviest.weightLb} lb',
      );
    }
    if (largestBass != null) {
      out.add(
        'Largest bass: ${largestBass.species} — ${largestBass.lengthIn} in',
      );
    }
    return out;
  }

  List<String> gameBests() {
    final game = catchLogs.where((l) => !l.isFish).toList();
    if (game.isEmpty) return [];
    final out = <String>[];
    LogEntry? heaviest;
    LogEntry? longestShot;
    for (final log in game) {
      if (log.weightLb != null &&
          (heaviest == null || log.weightLb! > (heaviest.weightLb ?? 0))) {
        heaviest = log;
      }
      if (log.shotDistanceYds != null &&
          (longestShot == null ||
              log.shotDistanceYds! > (longestShot.shotDistanceYds ?? 0))) {
        longestShot = log;
      }
    }
    if (heaviest != null) {
      out.add(
        'Heaviest harvest (est.): ${heaviest.species} — ~${heaviest.weightLb} lb',
      );
    }
    if (longestShot != null) {
      out.add(
        'Longest shot: ${longestShot.species} — ${longestShot.shotDistanceYds} yds',
      );
    }
    return out;
  }
}
