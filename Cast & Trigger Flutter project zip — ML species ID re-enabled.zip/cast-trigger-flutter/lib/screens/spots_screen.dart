import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart';
import 'package:path_provider/path_provider.dart';

import '../data/app_store.dart';
import '../data/species_id.dart';
import '../data/wv_data.dart';
import 'share_card_screen.dart';

/// Photo pick, LICENSE-STYLE (license_screen.dart _pickPhoto /
/// _takePhoto, which work on George's phone).
///
/// Verbatim in spirit: `ImagePicker().pickImage(source: ...)` with
/// NO imageQuality, NO maxWidth, NO launch check, NO delay, NO
/// dialog pop/reopen. Then `readAsBytes()`, write those bytes to a
/// file in the app documents directory (so the log's photoPath
/// survives the picker's temp cache being cleared), and return the
/// saved path. The caller stages it in state on the same page with
/// setState and shows the preview — exactly like the license
/// screen stages _stagedBytes. A cancelled pick returns
/// null/null; any failure returns a human error instead of
/// throwing, so the caller can show it and let the user retry
/// or save without a photo.
Future<({String? path, String? error})> pickPhotoLicenseStyle(
  ImageSource source,
) async {
  try {
    final picked = await ImagePicker().pickImage(source: source);
    if (picked == null) return (path: null, error: null);
    final bytes = await picked.readAsBytes();
    final dir = await getApplicationDocumentsDirectory();
    final savedPath =
        '${dir.path}/ct_${DateTime.now().microsecondsSinceEpoch}.jpg';
    await File(savedPath).writeAsBytes(bytes, flush: true);
    if (!File(savedPath).existsSync()) {
      throw Exception('Photo save failed');
    }
    return (path: savedPath, error: null);
  } catch (e) {
    return (
      path: null,
      error: 'Could not load that photo: $e. '
          'Try a different photo, or save without one.',
    );
  }
}

/// Spots — now also the log feed. No separate Log tab.
///
/// - Sliding Scout / Catch-Harvest toggle; the two panels never mix.
/// - Scout entries touch NO Stats counters. Catch/Harvest entries feed
///   Stats in the same tap, through AppStore.
/// - The ONLY add entry point is the moss-green + in the Spots header.
/// - Every photo is edited with a gold pencil in its upper-right
///   corner. Log cards carry pencil + trash in the upper-right corner;
///   trash is two-tap confirm ("Tap again to remove").
/// - Maps: Standard (OpenStreetMap) / Topographic (OpenTopoMap —
///   real topo tiles with SRTM contours, NOT a terrain-style
///   approximation). Tiles need internet; without it the map tiles
///   simply do not load, but the lists below still work offline.
///   Wind tags appear ONLY on the map, beside pins, labelled Sample.
///   No wind data is shown below maps.
/// - NO coordinates are ever invented. A log without user-entered
///   lat/lng is listed by name with "Listed, no map pin".
/// - Share cards show water/county only, never GPS.
class SpotsScreen extends StatefulWidget {
  const SpotsScreen({super.key});

  @override
  State<SpotsScreen> createState() => _SpotsScreenState();
}

class _SpotsScreenState extends State<SpotsScreen> {
  final AppStore _store = AppStore.instance;
  bool _showScout = true;
  bool _topo = false;
  String? _pendingRemoveId;

  @override
  void initState() {
    super.initState();
    _store.load();
  }

  // ---- Sample wind, deterministic per place, labelled Sample. ----
  static const _dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  static const _arrows = {
    'N': '↓',
    'NE': '↙',
    'E': '←',
    'SE': '↖',
    'S': '↑',
    'SW': '↗',
    'W': '→',
    'NW': '↘',
  };

  String _windTag(String place) {
    var hash = 0;
    for (final c in place.codeUnits) {
      hash = (hash * 31 + c) % 100000;
    }
    final dir = _dirs[hash % _dirs.length];
    final speed = 5 + (hash % 10);
    return '${_arrows[dir]} $dir · $speed mph · Sample';
  }

  String _boneFor(LogEntry log) {
    if (log.isFish) return '🐟🦴';
    if (log.species == 'Whitetail Deer') return '🦌🦴';
    if (log.species.contains('Squirrel')) return '🐿️🦴';
    if (log.species == 'Coyote' ||
        log.species.contains('Fox') ||
        log.species == 'Bobcat') {
      return '🐺🦴';
    }
    return '🦴'; // turkey / game birds / unknown
  }

  String _liveFor(LogEntry log) {
    if (log.isFish) return '🐟';
    if (log.species == 'Whitetail Deer') return '🦌';
    if (log.species == 'Wild Turkey') return '🦃';
    if (log.species.contains('Squirrel')) return '🐿️';
    if (log.species.contains('Fox') || log.species == 'Coyote') {
      return '🦊';
    }
    return '🐾';
  }

  String _formatDate(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  /// HISTORY: the old Add flow was a showDialog modal; the picker
  /// was launched from inside it and could render behind the
  /// modal barrier as a blank black panel. Later rounds moved the
  /// pick out of the dialog (pop with draft, 350ms delay, launch
  /// check, reopen) and disabled ML Kit — the failure did not
  /// change. This build replaces all of that with the plain
  /// full-screen page + license-style pick below.
  /// Add / edit a log on a plain full-screen page — the LICENSE
  /// pattern (2026-11-05, George's direction).
  ///
  /// The license screen works on George's phone; Spots did not.
  /// The difference was everything Spots wrapped around the pick:
  /// a showDialog modal (barrierDismissible: false) + PopScope,
  /// Take/Upload popping the dialog with a draft, _openAdd waiting
  /// 350ms, launching the picker via a launch check
  /// (AppLifecycleListener, 8s), copying, then reopening the
  /// dialog with the draft + photo, then ML Kit. ML Kit was
  /// disabled as a diagnostic and the failure did not change,
  /// so ML Kit was ruled out as the photo bug. Once the
  /// license-style pick was proven working on-device, ML Kit
  /// was re-enabled (2026-11-05) as a fire-and-forget
  /// suggestion after the photo is staged — never blocking
  /// Save, the preview, or the page.
  ///
  /// This build mirrors license_screen.dart _pickPhoto/_takePhoto
  /// exactly: a plain page (Navigator.push, no dialog, no
  /// PopScope), buttons call the picker directly, the photo is
  /// staged on the same page with setState, and Save returns the
  /// log to this screen, which then runs the trip ask / store
  /// save. Back (system or AppBar) returns null — no log saved,
  /// no draft trap, no PopScope to veto a pop.
  Future<void> _openAdd({LogEntry? editing}) async {
    final log = await Navigator.of(context).push<LogEntry>(
      MaterialPageRoute<LogEntry>(
        builder: (_) => _AddLogPage(existing: editing),
      ),
    );
    if (log == null) return;
    if (editing != null) {
      // Edit preserves the original trip link; Stats re-derive.
      await _store.updateLog(log);
    } else if (!log.isScout) {
      await _applyTripAsk(log);
    } else {
      await _store.addLog(log);
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            editing != null
                ? 'Log updated.'
                : log.isScout
                    ? 'Scout spot saved. Scout does not change Stats.'
                    : 'Catch / harvest saved. Stats updated.',
          ),
        ),
      );
    }
  }

  /// Trip ask, Catch/Harvest only. If a trip exists for the log's
  /// date, ask to tie to it (default Yes). Otherwise (or on "No"),
  /// ask for a trip location and create the trip. Saving is blocked
  /// if there is no location at all for a new trip.
  Future<void> _applyTripAsk(LogEntry log) async {
    final trips = _store.tripsForDate(log.date);
    if (trips.isNotEmpty) {
      final tie = await showDialog<bool>(
        context: context,
        builder: (ctx) {
          final t = trips.first;
          return AlertDialog(
            title: const Text('Tie this catch / harvest to a trip?'),
            content: Text(
              'A trip exists for ${_formatDate(log.date)}: '
              '${t.species} at ${t.place}, ${t.county} County. '
              'Tie this catch / harvest to it?',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(false),
                child: const Text('No — create a new trip instead'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.of(ctx).pop(true),
                child: const Text('Yes — tie it to this trip'),
              ),
            ],
          );
        },
      );
      if (tie == true) {
        await _store.addLog(
          log.copyWith(tripId: trips.first.id, tripAutoCreated: false),
        );
        return;
      }
    }
    // No trip, or user chose a new trip: ask for a location.
    final locationController = TextEditingController(text: log.place);
    final location = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('Create a trip for this day'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'No trip exists for this date. Enter a trip location '
              'to create one in Planned Trips.',
            ),
            const SizedBox(height: 12),
            TextField(
              controller: locationController,
              decoration: const InputDecoration(
                labelText: 'Trip location',
              ),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.of(ctx).pop(
              locationController.text.trim(),
            ),
            child: const Text('Create trip & save log'),
          ),
        ],
      ),
    );
    if (location == null || location.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Not saved: a Catch / Harvest log needs a trip, and '
              'a new trip needs a location.',
            ),
          ),
        );
      }
      return;
    }
    final trip = Trip(
      id: AppStore.newId(),
      date: Trip.dateOnly(log.date),
      species: log.species,
      isFish: log.isFish,
      county: log.county,
      place: location,
      autoCreated: true,
    );
    await _store.addTrip(trip);
    await _store.addLog(
      log.copyWith(tripId: trip.id, tripAutoCreated: true),
    );
  }

  /// Photo replacement, LICENSE-STYLE: the choice sheet has an
  /// explicit dark background and a visible Cancel row; the pick
  /// itself is the same direct license-style call as the Add page
  /// (no launch check, no delay, no file_picker fallback). Any
  /// failure shows a SnackBar and the old photo is kept.
  Future<void> _replacePhoto(LogEntry log) async {
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: const Color(0xFF1E2429),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(
              title: Text(
                'Replace photo',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('Take picture'),
              onTap: () => Navigator.of(ctx).pop(ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.upload),
              title: const Text('Upload picture'),
              onTap: () => Navigator.of(ctx).pop(ImageSource.gallery),
            ),
            ListTile(
              leading: const Icon(Icons.close),
              title: const Text('Cancel'),
              onTap: () => Navigator.of(ctx).pop(),
            ),
          ],
        ),
      ),
    );
    if (source == null) return;
    // License-style pick, direct from this plain screen.
    // Cancelled = both null: keep the old photo silently.
    // Error = SnackBar below.
    final picked = await pickPhotoLicenseStyle(source);
    if (picked.path != null) {
      await _store.updateLog(log.copyWith(photoPath: picked.path));
    } else if (picked.error != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${picked.error} The old photo was kept.'),
        ),
      );
    }
  }


  Widget _photoWidget(LogEntry log, {double height = 160}) {
    final path = log.photoPath;
    final hasPhoto = path != null && File(path).existsSync();
    return Stack(
      children: [
        Container(
          height: height,
          width: double.infinity,
          color: const Color(0xFF1E2429),
          child: hasPhoto
              ? Image.file(
                  File(path),
                  fit: BoxFit.cover,
                  errorBuilder: (_, error, stackTrace) => const Icon(
                    Icons.photo,
                    size: 48,
                  ),
                )
              : const Icon(Icons.photo, size: 48),
        ),
        // Gold pencil, upper-right corner, on every photo.
        Positioned(
          top: 6,
          right: 6,
          child: InkWell(
            onTap: () => _replacePhoto(log),
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: const BoxDecoration(
                color: Color(0xFFD4AF37),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.edit,
                size: 16,
                color: Colors.black,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _logCard(LogEntry log) {
    final isPendingRemove = _pendingRemoveId == log.id;
    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Photo keeps its own gold pencil, upper-right, inside
          // _photoWidget. Card pencil + trash are in the card-body
          // header row (right-aligned) instead of stacked on top
          // of the photo pencil, so both stay tappable — stacking
          // them in the same corner would have covered the photo
          // pencil and made photo-only replacement untappable.
          _photoWidget(log),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Spacer(),
                    InkWell(
                      onTap: () => _openAdd(editing: log),
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: const BoxDecoration(
                          color: Color(0xFFD4AF37),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.edit,
                          size: 16,
                          color: Colors.black,
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    InkWell(
                      onTap: () async {
                        if (isPendingRemove) {
                          await _store.removeLog(log.id);
                          setState(() => _pendingRemoveId = null);
                        } else {
                          setState(() => _pendingRemoveId = log.id);
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: isPendingRemove
                              ? Colors.red
                              : Colors.black54,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.delete,
                          size: 16,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
                Text(
                  '${log.isScout ? _liveFor(log) : _boneFor(log)} '
                  '${log.species}',
                  style: GoogleFonts.caveatBrush(fontSize: 24),
                ),
                const SizedBox(height: 4),
                Text(
                  '${_formatDate(log.date)} · ${log.place}, '
                  '${log.county} County',
                ),
                if (log.isFish && log.lengthIn != null)
                  Text('Length: ${log.lengthIn} in'),
                if (log.weightLb != null)
                  Text(
                    'Est. weight: ~${log.weightLb} lb',
                  ),
                if (log.baitOrWeapon.isNotEmpty)
                  Text(
                    log.isFish
                        ? 'Bait: ${log.baitOrWeapon}'
                        : 'Weapon: ${log.baitOrWeapon}',
                  ),
                if (log.shotDistanceYds != null)
                  Text('Shot distance: ${log.shotDistanceYds} yds'),
                if (log.lat == null || log.lng == null)
                  const Text(
                    'Listed, no map pin (no coordinates entered).',
                    style: TextStyle(fontStyle: FontStyle.italic),
                  ),
                if (isPendingRemove)
                  const Text(
                    'Tap trash again to remove.',
                    style: TextStyle(color: Colors.red),
                  ),
                if (!log.isScout) ...[
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => ShareCardScreen(log: log),
                        ),
                      );
                    },
                    child: const Text('View share card'),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _mapSection(List<LogEntry> entries) {
    final pinned = entries
        .where((e) => e.lat != null && e.lng != null)
        .toList();
    final center = pinned.isNotEmpty
        ? LatLng(pinned.first.lat!, pinned.first.lng!)
        : const LatLng(38.6, -80.8);
    final markers = pinned.map((e) {
      return Marker(
        point: LatLng(e.lat!, e.lng!),
        width: 180,
        height: 72,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Pin art, fixed by panel (no pin-style toggle):
                // Scout = live animal, Catch/Harvest = bone, both
                // set automatically by species via _liveFor/_boneFor.
                // LIMITATION, stated plainly: these are emoji glyphs
                // on a dark pin, NOT custom bone SVG drawings. The
                // prototype's bone SVGs were not re-drawn as Flutter
                // map-marker SVGs in this chunk; the species mapping
                // and the Scout-live / Catch-bone distinction are
                // preserved, and the pin re-draws on species change
                // because it is built from the log entry itself.
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: const BoxDecoration(
                    color: Colors.black87,
                    shape: BoxShape.circle,
                  ),
                  child: Text(
                    _showScout ? _liveFor(e) : _boneFor(e),
                    style: const TextStyle(
                      fontSize: 20,
                      color: Color(0xFFF5F0E1), // bone-white
                    ),
                  ),
                ),
                const SizedBox(width: 4),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.black87,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    _windTag(e.place),
                    style: const TextStyle(fontSize: 11),
                  ),
                ),
              ],
            ),
          ],
        ),
      );
    }).toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text(
              'Map',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const Spacer(),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: false, label: Text('Standard')),
                ButtonSegment(value: true, label: Text('Topographic')),
              ],
              selected: {_topo},
              onSelectionChanged: (v) =>
                  setState(() => _topo = v.first),
            ),
          ],
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 260,
          child: FlutterMap(
            options: MapOptions(
              initialCenter: center,
              initialZoom: pinned.isNotEmpty ? 10 : 7,
            ),
            children: [
              TileLayer(
                // Standard: OpenStreetMap. Topographic: OpenTopoMap,
                // real topo tiles (SRTM contours + elevation shading).
                // Both need internet for tiles; lists work offline.
                urlTemplate: _topo
                    ? 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png'
                    : 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.casttrigger',
              ),
              MarkerLayer(markers: markers),
            ],
          ),
        ),
        const SizedBox(height: 4),
        Text(
          _topo
              ? 'Topographic: OpenTopoMap tiles (SRTM contours). '
                  'Tiles need internet. Wind tags are Sample data, '
                  'not live weather.'
              : 'Standard: © OpenStreetMap contributors. Wind tags '
                  'are Sample data, not live weather.',
          style: const TextStyle(
            fontSize: 12,
            fontStyle: FontStyle.italic,
          ),
        ),
        if (pinned.isEmpty)
          const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text(
              'No pins on this map yet — add coordinates to a log '
              'to pin it. No coordinates are invented.',
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _store,
      builder: (context, _) {
        final entries = _showScout ? _store.scoutLogs : _store.catchLogs;
        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Spots',
                      style: GoogleFonts.caveatBrush(fontSize: 30),
                    ),
                  ),
                  // The ONLY add entry point: moss-green + in the
                  // Spots header corner. No bottom add buttons.
                  InkWell(
                    onTap: () => _openAdd(),
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: const BoxDecoration(
                        color: Color(0xFF6B8F5E),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.add,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              const Text(
                'Private by default. Share cards show water/county '
                'only, never GPS.',
                style: TextStyle(fontStyle: FontStyle.italic),
              ),
              const SizedBox(height: 12),
              SegmentedButton<bool>(
                segments: const [
                  ButtonSegment(value: true, label: Text('Scout')),
                  ButtonSegment(
                    value: false,
                    label: Text('Catch / Harvest'),
                  ),
                ],
                selected: {_showScout},
                onSelectionChanged: (v) =>
                    setState(() => _showScout = v.first),
              ),
              const SizedBox(height: 12),
              _mapSection(entries),
              const SizedBox(height: 16),
              if (entries.isEmpty)
                const Text(
                  'Nothing here yet. Tap + in the header to add a '
                  'photo log.',
                )
              else
                for (final log in entries) ...[
                  _logCard(log),
                  const SizedBox(height: 12),
                ],
            ],
          ),
        );
      },
    );
  }
}

/// Add / edit log, as a plain full-screen page — the LICENSE
/// pattern (2026-11-05, George's direction). Scout vs
/// Catch/Harvest is chosen BEFORE saving. Photo is optional;
/// after a photo is picked, ML Kit suggests a species
/// (re-enabled 2026-11-05, suggestion only, never blocking
/// Save); the species picker below is always the confirmation
/// step, and manual entry always works.
class _AddLogPage extends StatefulWidget {
  const _AddLogPage({this.existing});

  final LogEntry? existing;

  @override
  State<_AddLogPage> createState() => _AddLogPageState();
}

class _AddLogPageState extends State<_AddLogPage> {
  static const String manualEntry = 'Manual / other entry';

  bool _isScout = true;
  bool _isFish = true;
  String _species = 'Largemouth Bass';
  DateTime _date = DateTime.now();
  String _county = 'Kanawha';
  String _water = 'Kanawha River';
  final TextEditingController _areaController = TextEditingController();
  final TextEditingController _lengthController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _baitController = TextEditingController();
  final TextEditingController _shotController = TextEditingController();
  final TextEditingController _latController = TextEditingController();
  final TextEditingController _lngController = TextEditingController();
  String? _photoPath;
  String? _photoError;

  // Automatic species suggestion (ML Kit, re-enabled 2026-11-05
  // on top of the working license-style photo flow). Fire-and-
  // forget only: it runs AFTER a photo is picked and staged on
  // this same page, never blocks Save, the preview, or the page,
  // and never runs for a photo the user did not just pick (no
  // identification on page open for an existing log's photo).
  // _identificationRun is a token: each new photo bumps it, so
  // a slow result for an old photo can never overwrite the
  // result for the photo now on screen.
  bool _identifying = false;
  SpeciesSuggestion? _suggestion;
  String? _idNote;
  int _identificationRun = 0;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    if (e != null) {
      _isScout = e.isScout;
      _isFish = e.isFish;
      _species = e.species;
      _date = e.date;
      _county = e.county;
      if (e.isFish) {
        _water = e.place;
      } else {
        _areaController.text = e.place;
      }
      if (e.lengthIn != null) {
        _lengthController.text = e.lengthIn.toString();
      }
      if (e.weightLb != null) {
        _weightController.text = e.weightLb.toString();
      }
      _baitController.text = e.baitOrWeapon;
      if (e.shotDistanceYds != null) {
        _shotController.text = e.shotDistanceYds.toString();
      }
      if (e.lat != null) _latController.text = e.lat.toString();
      if (e.lng != null) _lngController.text = e.lng.toString();
      _photoPath = e.photoPath;
    }
  }

  @override
  void dispose() {
    _areaController.dispose();
    _lengthController.dispose();
    _weightController.dispose();
    _baitController.dispose();
    _shotController.dispose();
    _latController.dispose();
    _lngController.dispose();
    super.dispose();
  }

  List<String> get _speciesOptions {
    final options = _isFish ? fishSpecies : gameSpecies;
    return [...options, manualEntry];
  }

  /// Spots water list, filtered by county AND fish species, mirroring
  /// the Planner rule (Fix #1 family): a fish log's water must be a
  /// water where that fish occurs. Hunting / manual returns all.
  List<String> get _availableWaters {
    if (_isFish) {
      return watersForCountyAndFish(_county, _species);
    }
    return watersForCounty(_county);
  }

  /// Build the current form as a LogEntry, for Save.
  /// Invalid lat/lng text is dropped (parsed as null);
  /// _save() still validates it before saving.
  LogEntry _buildLog() {
    final existing = widget.existing;
    final place = _isFish ? _water : _areaController.text.trim();
    return LogEntry(
      id: existing?.id ?? AppStore.newId(),
      isScout: _isScout,
      isFish: _isFish,
      species: _species,
      date: _date,
      county: _county,
      place: place,
      lengthIn: double.tryParse(_lengthController.text.trim()),
      weightLb: double.tryParse(_weightController.text.trim()),
      baitOrWeapon: _baitController.text.trim(),
      shotDistanceYds: int.tryParse(_shotController.text.trim()),
      photoPath: _photoPath,
      lat: double.tryParse(_latController.text.trim()),
      lng: double.tryParse(_lngController.text.trim()),
      tripId: existing?.tripId,
      tripAutoCreated: existing?.tripAutoCreated ?? false,
    );
  }

  /// Photo pick, LICENSE-STYLE (license_screen.dart _pickPhoto /
  /// _takePhoto): call the picker directly from this plain page,
  /// no dialog pop, no delay, no launch check, no file_picker
  /// fallback. The photo is written to app documents and staged
  /// in state on this same page with setState, so the preview
  /// appears here immediately. The pick flow is NOT awaited on
  /// identification: _runIdentification is called fire-and-forget
  /// after the photo is staged, and _save() never waits for it.
  Future<void> _pickPhoto(ImageSource source) async {
    final result = await pickPhotoLicenseStyle(source);
    if (!mounted) return;
    if (result.error != null) {
      setState(() => _photoError = result.error);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.error!)),
      );
    } else if (result.path != null) {
      final path = result.path!;
      setState(() {
        _photoPath = path;
        _photoError = null;
      });
      // Fire-and-forget: do NOT await. The preview is already
      // on screen and Save works immediately, with or without
      // a suggestion. A new photo bumps the run token, so a
      // slow result for a previous photo is ignored.
      _runIdentification(path);
    }
  }

  /// ML Kit identification, run only after a photo is picked on
  /// this page. Never blocks saving: _save() does not await it,
  /// and the user can Save at any time while it runs.
  /// SpeciesIdService.identify() already has a 20-second timeout
  /// and a catch-all that returns "unidentified" on any failure,
  /// so this can only ever end in a suggestion, a non-game note,
  /// or an "unidentified" note — never a hang and never a throw.
  /// The run token + the _photoPath check discard stale results:
  /// if the user picked a newer photo, replaced the photo, or
  /// left the page (mounted == false), this result is dropped.
  Future<void> _runIdentification(String savedPath) async {
    final run = ++_identificationRun;
    setState(() {
      _identifying = true;
      _suggestion = null;
      _idNote = null;
    });
    final result = await SpeciesIdService.identify(savedPath);
    if (!mounted) return;
    if (run != _identificationRun) return;
    if (_photoPath != savedPath) return;
    setState(() {
      _identifying = false;
      if (result.isGame || result.isNonGame) {
        _suggestion = result;
        _idNote = null;
      } else {
        _suggestion = null;
        _idNote = result.rawLabel.isNotEmpty
            ? 'Could not identify this photo from its label '
                '("${result.rawLabel}") — pick the species below. '
                'Saving is not blocked.'
            : 'Could not identify this photo — pick the species '
                'below. Saving is not blocked.';
      }
    });
  }

  /// Apply a suggestion the user tapped "Use". Exact suggestions
  /// set the species (and the Fish/Hunt kind, if the species is
  /// in the other kind). Category suggestions set the Fish/Hunt
  /// kind only and leave the exact species for the user to pick
  /// below — except that if the current species is not in the
  /// new kind at all (e.g. a fish species when the kind flips
  /// to game), the species is reset to the first candidate, so
  /// Save can never record a species from the wrong kind.
  /// A new water is chosen only if the old one is not valid for
  /// the new species/county (Planner rule: water never moves
  /// the species). The suggestion is a suggestion only, never
  /// a legal ID — the user still confirms below before saving.
  void _applySuggestion(SpeciesSuggestion suggestion) {
    setState(() {
      if (suggestion.suggestedSpecies != null) {
        _species = suggestion.suggestedSpecies!;
        _isFish = suggestion.isFish;
      } else {
        _isFish = suggestion.isFish;
        if (!_speciesOptions.contains(_species)) {
          _species = suggestion.candidateSpecies.isNotEmpty
              ? suggestion.candidateSpecies.first
              : (_isFish ? 'Largemouth Bass' : 'Whitetail Deer');
        }
      }
      if (_isFish && !_availableWaters.contains(_water)) {
        _water = _availableWaters.first;
      }
      _suggestion = null;
      _idNote = 'Suggestion applied — confirm the species below '
          'before saving. It is a suggestion only, not a legal ID.';
    });
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime.now().subtract(const Duration(days: 365 * 3)),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) setState(() => _date = picked);
  }

  String _formatDate(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  void _save() {
    if (_species.isEmpty) return;
    final place = _isFish ? _water : _areaController.text.trim();
    if (place.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Enter a water or hunting area first.'),
        ),
      );
      return;
    }
    final lat = double.tryParse(_latController.text.trim());
    final lng = double.tryParse(_lngController.text.trim());
    if ((_latController.text.trim().isNotEmpty && lat == null) ||
        (_lngController.text.trim().isNotEmpty && lng == null)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Coordinates must be numbers, or left blank.'),
        ),
      );
      return;
    }
    // Plain page, no PopScope: a direct pop works here.
    Navigator.of(context).pop(_buildLog());
  }

  @override
  Widget build(BuildContext context) {
    final photo = _photoPath;
    // LICENSE pattern: this is a plain full-screen page, NOT a
    // dialog, and there is NO PopScope here. System Back / the
    // AppBar back arrow simply pops the page returning null
    // (no log saved, no draft). Save and Cancel pop directly —
    // a PopScope vetoed every programmatic pop in the old
    // dialog, which was the photo bug.
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.existing != null ? 'Edit log' : 'Add a log',
          style: GoogleFonts.caveatBrush(fontSize: 28),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Photo tool, LICENSE-STYLE: Take / Upload call the
            // picker directly from this plain page and stage the
            // photo here with setState — no dialog pop, no
            // delay, no launch check. After a photo is picked,
            // ML Kit suggests a species below (suggestion only);
            // the species picker is always the confirmation step.
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickPhoto(ImageSource.camera),
                    icon: const Icon(Icons.camera_alt),
                    label: const Text('Take picture'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickPhoto(ImageSource.gallery),
                    icon: const Icon(Icons.upload),
                    label: const Text('Upload picture'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (_photoError != null) ...[
              Text(
                _photoError!,
                style: const TextStyle(color: Colors.red),
              ),
              const SizedBox(height: 8),
            ],
            if (photo != null && File(photo).existsSync()) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.file(
                  File(photo),
                  height: 140,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) =>
                      const SizedBox.shrink(),
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'Photo loaded ✓.',
                style: TextStyle(fontStyle: FontStyle.italic),
              ),
            ] else
              const Text(
                'Photo is optional. Pick the species below manually.',
                style: TextStyle(fontStyle: FontStyle.italic),
              ),
            // ML Kit suggestion (re-enabled 2026-11-05, on top of
            // the working license-style pick). Runs after a photo
            // is picked; the preview above is already on screen
            // and Save below works at any time, with or without
            // a suggestion. Suggestion only — never a legal ID.
            if (_identifying) ...[
              const SizedBox(height: 8),
              const Row(
                children: [
                  SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                  SizedBox(width: 8),
                  Text('Identifying photo… (suggestion only)'),
                ],
              ),
            ],
            if (!_identifying && _suggestion != null) ...[
              const SizedBox(height: 8),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFF1E2429),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: const Color(0xFFD4AF37),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (_suggestion!.isNonGame) ...[
                      Text(
                        'That looks like ${_suggestion!.rawLabel} '
                        '(${_suggestion!.confidencePct}) — not a '
                        'game species. Please pick manually below.',
                        style: const TextStyle(
                          color: Colors.redAccent,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const Text(
                        'A dog, cat, person, or other non-game '
                        'photo is never labelled as a game species.',
                        style: TextStyle(fontStyle: FontStyle.italic),
                      ),
                    ] else if (_suggestion!.suggestedSpecies !=
                        null) ...[
                      Text(
                        'Suggestion: ${_suggestion!.suggestedSpecies} '
                        '(${_suggestion!.confidencePct}, label '
                        '"${_suggestion!.rawLabel}")',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          ElevatedButton(
                            onPressed: () =>
                                _applySuggestion(_suggestion!),
                            child: const Text('Use this species'),
                          ),
                          const SizedBox(width: 8),
                          TextButton(
                            onPressed: () => setState(
                              () => _suggestion = null,
                            ),
                            child: const Text('Dismiss'),
                          ),
                        ],
                      ),
                    ] else ...[
                      Text(
                        'This looks like ${_suggestion!.rawLabel} '
                        '(${_suggestion!.confidencePct}) — exact '
                        'species not identified. Pick it below.',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          ElevatedButton(
                            onPressed: () =>
                                _applySuggestion(_suggestion!),
                            child: const Text('Use this category'),
                          ),
                          const SizedBox(width: 8),
                          TextButton(
                            onPressed: () => setState(
                              () => _suggestion = null,
                            ),
                            child: const Text('Dismiss'),
                          ),
                        ],
                      ),
                    ],
                    const SizedBox(height: 4),
                    const Text(
                      'Suggestion only — not a legal ID. '
                      'Confirm before saving.',
                      style: TextStyle(fontStyle: FontStyle.italic),
                    ),
                  ],
                ),
              ),
            ],
            if (!_identifying && _idNote != null) ...[
              const SizedBox(height: 8),
              Text(
                _idNote!,
                style: const TextStyle(fontStyle: FontStyle.italic),
              ),
            ],
            const SizedBox(height: 12),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: true, label: Text('Scout')),
                ButtonSegment(
                  value: false,
                  label: Text('Catch / Harvest'),
                ),
              ],
              selected: {_isScout},
              onSelectionChanged: (v) =>
                  setState(() => _isScout = v.first),
            ),
            const SizedBox(height: 8),
            if (_isScout)
              const Text(
                'Scout does not change Stats.',
                style: TextStyle(fontStyle: FontStyle.italic),
              ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: _isFish
                        ? null
                        : () => setState(() {
                              _isFish = true;
                              _species = 'Largemouth Bass';
                              if (!_availableWaters.contains(_water)) {
                                _water = _availableWaters.first;
                              }
                            }),
                    child: const Text('Fish'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton(
                    onPressed: !_isFish
                        ? null
                        : () => setState(() {
                              _isFish = false;
                              _species = 'Whitetail Deer';
                            }),
                    child: const Text('Hunt'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _speciesOptions.contains(_species)
                  ? _species
                  : manualEntry,
              decoration: const InputDecoration(labelText: 'Species'),
              items: _speciesOptions
                  .map(
                    (s) => DropdownMenuItem(value: s, child: Text(s)),
                  )
                  .toList(),
              onChanged: (v) {
                if (v == null) return;
                setState(() {
                  _species = v;
                  // Water must stay in the species-filtered list.
                  if (_isFish &&
                      !_availableWaters.contains(_water)) {
                    _water = _availableWaters.first;
                  }
                });
              },
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                const Text('Date: '),
                TextButton(
                  onPressed: _pickDate,
                  child: Text(_formatDate(_date)),
                ),
              ],
            ),
            DropdownButtonFormField<String>(
              value: _county,
              decoration: const InputDecoration(labelText: 'County'),
              items: wvCounties
                  .map(
                    (c) => DropdownMenuItem(
                      value: c,
                      child: Text('$c County'),
                    ),
                  )
                  .toList(),
              onChanged: (v) {
                if (v == null) return;
                setState(() {
                  _county = v;
                  _water = _availableWaters.first;
                });
              },
            ),
            const SizedBox(height: 12),
            if (_isFish)
              DropdownButtonFormField<String>(
                value: _availableWaters.contains(_water)
                    ? _water
                    : _availableWaters.first,
                decoration: const InputDecoration(labelText: 'Water'),
                items: _availableWaters
                    .map(
                      (w) => DropdownMenuItem(value: w, child: Text(w)),
                    )
                    .toList(),
                onChanged: (v) {
                  if (v != null) setState(() => _water = v);
                },
              )
            else
              TextField(
                controller: _areaController,
                decoration: const InputDecoration(
                  labelText: 'Hunting area',
                ),
              ),
            const SizedBox(height: 12),
            if (_isFish)
              TextField(
                controller: _lengthController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Length (in, optional)',
                ),
              ),
            TextField(
              controller: _weightController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: _isFish
                    ? 'Est. weight (lb, optional)'
                    : 'Est. weight (lb, optional, manual)',
              ),
            ),
            TextField(
              controller: _baitController,
              decoration: InputDecoration(
                labelText: _isFish ? 'Bait / lure' : 'Weapon / ammo',
              ),
            ),
            if (!_isFish)
              TextField(
                controller: _shotController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Shot distance (yds, optional)',
                ),
              ),
            const SizedBox(height: 12),
            const Text(
              'Map pin (optional): enter coordinates or leave blank. '
              'No coordinates are invented.',
              style: TextStyle(fontStyle: FontStyle.italic),
            ),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _latController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Latitude',
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _lngController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Longitude',
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('Cancel'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _save,
                    child: const Text('Save'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
