# Cast & Trigger — Flutter app, Chunk 1

**Chunk 1 only: scaffold + Planner.** The other tabs (Planned Trips,
Spots, Stats, My License) are placeholders saying
"Coming in a later chunk" so navigation works. Do not build Chunk 2
screens from this folder until Chunk 1 is reviewed.

## What is built

- 5-tab shell, in order: Planner, Planned Trips, Spots, Stats,
  My License. Planner is the only fully built screen.
- Planner: Fish/Hunt radio (Fish default), species picker, county
  dropdown with all 55 WV counties (Kanawha default, " County" suffix),
  water dropdown for fish / free-text hunting area for hunting, weapon
  picker for hunting (Bow / Firearm / Muzzleloader) changing the season
  verdict, pack list (Firearm pack list for hunting; Knife on every
  list), motto and save button: Fish = "Cast that line",
  Hunt = "Pull that trigger".
- Planner fish rule: species list is ALWAYS the full 28 + manual entry.
  Picking a fish narrows county/water to where it occurs (Musky 22 of
  55 counties, Walleye 28). A county or water change NEVER narrows or
  moves the species. Hunting/manual restores all 55 counties.
- Species: Gray/Fox Squirrel, native WV game birds (Ruffed Grouse,
  Northern Bobwhite Quail, Mourning Dove, American Woodcock,
  Wild Turkey), predators (Coyote, Red Fox, Gray Fox, Bobcat).
  Ring-necked Pheasant is deliberately NOT in the native game-bird list.
- Coyote spec: year-round, no bag limit, night hunting Jan 1–Dec 31
  with any color light / night vision, Sept 1–Dec 31 night hunting only
  on private land with written landowner consent, air rifles at least
  .22 caliber; "Written landowner consent" is a pack item.
- Dusk rule: for most hunting, if now is within 30 minutes before dusk
  or later, the trip date defaults to tomorrow; fishing does not shift.
  The dusk time in this chunk is a PLACEHOLDER (6:30 PM local) — no
  live sunset API is wired, and the UI says so.
- Waters: Summersville Lake ONLY in Nicholas County, never Mineral.
  Mineral = Jennings Randolph Lake, North Branch Potomac River,
  Patterson Creek, New Creek. Other county/water mappings are sample
  placeholders, clearly marked as such.
- Disclaimer gate: one-time "Read & Agree" on first open, short
  "Check before you go" warning + full 10-section disclaimer. The app
  is locked until the user scrolls to the end, checks
  "I have read and understand… I will always double-check the current
  official regulations", and taps "Agree & start using the app".
  Agreement version + date/time are saved locally with
  shared_preferences. Planner shows a "Disclaimer & user agreement"
  card with the saved date and a read-only re-read button.
  In the real app this must ALSO be recorded server-side.
- App bar, upper-right, every screen: WV pill (gold pill, with caret).
  Tapping opens "Your state": WV = Current, PA, OH, VA, KY, MD all
  grayed out with "Coming soon". Tapping a grayed state shows a toast
  and does not switch state.
- Release gate: private by default, no AI bite predictions, no fake
  predictions, offline-first local storage. Every season verdict shows
  "Sample data — check official WVDNR regulations" with a
  verified-date/source placeholder. Sample seasons are NEVER presented
  as official.

## What is NOT in this chunk

- No billing. No Premium purchase flow. The "Coming soon" states in the
  state menu are not a purchase.
- No Spots log feed, Stats, Planned Trips calendar, or My License
  storage beyond the placeholder tabs.
- No maps, no parcel/property-line data, no scraped onX/Fishbrain data,
  no invented coordinates.
- No LLC, domain, trademark filing, or contacting WV/Regrid.
- Trip persistence: the Planner save button shows a confirmation toast
  only. Real trip saving belongs with the Planned Trips chunk.

## Working name warning

Cast & Trigger is a WORKING NAME ONLY, NOT CLEARED. A live CAST mark
(USPTO Serial 97175263) is flagged for attorney review, and domain
availability is unverified. Do not file, buy a domain, or launch under
this name until that review is resolved. The disclaimer in this chunk
is a DRAFT for attorney review, not final legal text.

## Run it locally

Requires the Flutter SDK (not included in this folder, and not
available in the environment where this chunk was written — a full
Flutter compile was NOT run here; see Verification below).

```sh
cd cast-trigger-flutter
flutter pub get
flutter run
```

On first run you will see the disclaimer gate. Agree once, and the
Planner opens. Switch Fish/Hunt, pick a fish (try Muskellunge, then
Walleye), change county/water, and confirm the species never moves.

## Verification (honest status)

- Flutter / Dart toolchain was NOT available in the writing
  environment (`flutter` and `dart` not found), so `flutter analyze`
  and a full compile were NOT run here.
- Files were read back and checked by script: brace/paren balance,
  import paths resolve to files in this folder, county count = 55,
  fish count = 28, Musky counties = 22, Walleye counties = 28,
  Summersville Lake appears only under Nicholas, Mineral has exactly
  its four waters, and Ring-necked Pheasant is not in the game-species
  list (it appears only in a comment explaining its exclusion).
- Run `flutter analyze` on a machine with the Flutter SDK before
  treating this as compile-clean, and test on a real device/emulator
  before any further chunk.
