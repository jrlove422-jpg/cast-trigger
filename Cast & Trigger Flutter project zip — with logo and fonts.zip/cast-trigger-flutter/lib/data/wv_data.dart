/// West Virginia reference data for the Planner (Chunk 1).
///
/// WARNING — SAMPLE DATA ONLY.
/// Nothing in this file is official WVDNR regulation, season, bag-limit,
/// or stocking data. Every season verdict in the UI must carry the
/// "Sample data — check official WVDNR regulations" warning, and the real
/// app must replace this file with a versioned, human-reviewed config
/// pulled from official sources (see the project brief, section 13).
/// Never silently roll last year's dates forward.
///
/// Explicit exclusions, per spec:
/// - Ring-necked Pheasant is NOT in the native game-bird list: it is an
///   introduced species, not native to WV. Do not re-add it there.
/// - No invented coordinates, no scraped onX / Fishbrain data, no parcel
///   data of any kind in this chunk.

/// All 55 WV counties, alphabetically. The UI appends " County".
const List<String> wvCounties = [
  'Barbour',
  'Berkeley',
  'Boone',
  'Braxton',
  'Brooke',
  'Cabell',
  'Calhoun',
  'Clay',
  'Doddridge',
  'Fayette',
  'Gilmer',
  'Grant',
  'Greenbrier',
  'Hampshire',
  'Hancock',
  'Hardy',
  'Harrison',
  'Jackson',
  'Jefferson',
  'Kanawha',
  'Lewis',
  'Lincoln',
  'Logan',
  'Marion',
  'Marshall',
  'Mason',
  'McDowell',
  'Mercer',
  'Mineral',
  'Mingo',
  'Monongalia',
  'Monroe',
  'Morgan',
  'Nicholas',
  'Ohio',
  'Pendleton',
  'Pleasants',
  'Pocahontas',
  'Preston',
  'Putnam',
  'Raleigh',
  'Randolph',
  'Ritchie',
  'Roane',
  'Summers',
  'Taylor',
  'Tucker',
  'Tyler',
  'Upshur',
  'Wayne',
  'Webster',
  'Wetzel',
  'Wirt',
  'Wood',
  'Wyoming',
];

/// The 28 fish species, in the order used by the prototype.
/// 'Muskellunge (Musky)' is the display name for the Musky count note.
const List<String> fishSpecies = [
  'Largemouth Bass',
  'Smallmouth Bass',
  'Rainbow Trout',
  'Brown Trout',
  'Brook Trout',
  'Golden Rainbow Trout',
  'Muskellunge (Musky)',
  'Walleye',
  'Saugeye',
  'Sauger',
  'Yellow Perch',
  'Channel Catfish',
  'Flathead Catfish',
  'Blue Catfish',
  'Black Crappie',
  'White Crappie',
  'Bluegill',
  'Redear Sunfish',
  'Redbreast Sunfish',
  'Green Sunfish',
  'Rock Bass',
  'Spotted Bass',
  'Striped Bass',
  'Hybrid Striped Bass',
  'White Bass',
  'Common Carp',
  'Chain Pickerel',
  'Freshwater Drum',
];

/// Game species. Ring-necked Pheasant deliberately absent (see header).
const List<String> gameSpecies = [
  'Whitetail Deer',
  'Wild Turkey',
  'Gray Squirrel',
  'Fox Squirrel',
  'Ruffed Grouse',
  'Northern Bobwhite Quail',
  'Mourning Dove',
  'American Woodcock',
  'Coyote',
  'Red Fox',
  'Gray Fox',
  'Bobcat',
];

/// Counties where a fish occurs, for the Planner narrowing rule.
/// Only Musky and Walleye have explicit sample lists in Chunk 1, because
/// the spec pins their counts exactly: Musky 22 of 55, Walleye 28 of 55.
/// Every other fish defaults to all 55 counties (sample placeholder —
/// replace with verified WVDNR / stocking data in the real build).
///
/// Planner rule (final, do not regress):
/// - The species list is ALWAYS the full 28 + manual entry.
/// - Picking a fish narrows the county/water pickers to where it occurs.
/// - A county or water change NEVER narrows or moves the species pick.
/// - Hunting species or the manual/other entry restores all 55 counties.
const Map<String, List<String>> fishCounties = {
  'Muskellunge (Musky)': [
    'Barbour',
    'Braxton',
    'Cabell',
    'Calhoun',
    'Clay',
    'Fayette',
    'Gilmer',
    'Greenbrier',
    'Harrison',
    'Jackson',
    'Kanawha',
    'Lewis',
    'Lincoln',
    'Logan',
    'Marion',
    'Mason',
    'Monongalia',
    'Nicholas',
    'Preston',
    'Raleigh',
    'Randolph',
    'Wood',
  ],
  'Walleye': [
    'Barbour',
    'Berkeley',
    'Braxton',
    'Brooke',
    'Cabell',
    'Calhoun',
    'Doddridge',
    'Fayette',
    'Gilmer',
    'Greenbrier',
    'Hancock',
    'Harrison',
    'Jackson',
    'Kanawha',
    'Lewis',
    'Lincoln',
    'Marion',
    'Marshall',
    'Mason',
    'Monongalia',
    'Nicholas',
    'Ohio',
    'Pleasants',
    'Preston',
    'Putnam',
    'Raleigh',
    'Summers',
    'Wood',
  ],
};

/// Counties a fish occurs in, or all 55 when no explicit list exists.
List<String> countiesForFish(String species) {
  return fishCounties[species] ?? wvCounties;
}

/// Waters by county — SAMPLE PLACEHOLDER, except for the two hard rules:
/// - Summersville Lake appears ONLY under Nicholas County, never Mineral.
/// - Mineral County = Jennings Randolph Lake, North Branch Potomac
///   River, Patterson Creek, New Creek (exactly those four).
/// Counties without an explicit entry fall back to a single
/// "Other water in <county>" choice so the picker is never empty and
/// no water is invented for a county it is not in.
const Map<String, List<String>> watersByCounty = {
  'Nicholas': ['Summersville Lake', 'New River'],
  'Mineral': [
    'Jennings Randolph Lake',
    'North Branch Potomac River',
    'Patterson Creek',
    'New Creek',
  ],
  'Kanawha': ['Kanawha River', 'Elk River'],
  'Monongalia': ['Cheat Lake', 'Monongahela River'],
  'Fayette': ['New River', 'Gauley River'],
};

List<String> watersForCounty(String county) {
  return watersByCounty[county] ?? ['Other water in $county'];
}

/// Hunting weapons. Each changes the sample season verdict.
enum Weapon { bow, firearm, muzzleloader }

extension WeaponLabel on Weapon {
  String get label {
    switch (this) {
      case Weapon.bow:
        return 'Bow';
      case Weapon.firearm:
        return 'Firearm';
      case Weapon.muzzleloader:
        return 'Muzzleloader';
    }
  }
}

/// Sample season windows, by species group and weapon.
/// SAMPLE ONLY — see the file header. Replace with verified config.
String sampleSeasonWindow(String species, Weapon weapon) {
  if (species == 'Coyote') {
    return 'Year-round, no bag limit';
  }
  switch (weapon) {
    case Weapon.bow:
      return 'Sample bow window: Sep – Nov';
    case Weapon.firearm:
      return 'Sample firearm window: Nov – Dec';
    case Weapon.muzzleloader:
      return 'Sample muzzleloader window: Dec – Jan';
  }
}

/// Coyote spec (confirmed, from the brief):
/// Year-round, no bag limit. Night hunting with any color artificial
/// light / night vision permitted Jan 1 – Dec 31. Sept 1 – Dec 31 night
/// hunting ONLY on private land with written landowner consent.
/// Air rifles for coyote at least .22 caliber.
const String coyoteNote =
    'Coyote: year-round, no bag limit. Night hunting Jan 1–Dec 31 with '
    'any color light / night vision. Sept 1–Dec 31, night hunting only on '
    'private land with written landowner consent. Air rifles at least '
    '.22 caliber.';
