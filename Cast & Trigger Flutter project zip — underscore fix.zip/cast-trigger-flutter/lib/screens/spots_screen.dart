import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart';
import 'package:path_provider/path_provider.dart';

import '../data/app_store.dart';
import '../data/wv_data.dart';
import 'share_card_screen.dart';

/// Copy a picked photo into the app documents directory so the log's
/// photo survives the picker's temp cache being cleared.
Future<String> copyLogPhoto(String path) async {
  try {
    final dir = await getApplicationDocumentsDirectory();
    final name = 'ct_${DateTime.now().microsecondsSinceEpoch}.jpg';
    final dest = File('${dir.path}/$name');
    await File(path).copy(dest.path);
    return dest.path;
  } catch (_) {
    return path;
  }
}

/// Spots — now also the log feed. No separate Log tab.
///
/// - Sliding Scout / Catch-Harvest toggle; the two panels never mix.
/// - Scout entries touch NO Stats counters. Catch/Harvest entries feed
///   Stats in the same tap, through AppStore.
/// - The ONLY add entry point is the moss-green + in the Spots header.
/// - Every photo is edited with a gold pencil in its upper-right
///   corner. Log cards carry pencil + trash in the upper-right corner;
///   trash is two-tap confirm ("Tap again to remove").
/// - Maps: Standard (OpenStreetMap) / Topographic (OpenTopoMap —
///   real topo tiles with SRTM contours, NOT a terrain-style
///   approximation). Tiles need internet; without it the map tiles
///   simply do not load, but the lists below still work offline.
///   Wind tags appear ONLY on the map, beside pins, labelled Sample.
///   No wind data is shown below maps.
/// - NO coordinates are ever invented. A log without user-entered
///   lat/lng is listed by name with "Listed, no map pin".
/// - Share cards show water/county only, never GPS.
class SpotsScreen extends StatefulWidget {
  const SpotsScreen({super.key});

  @override
  State<SpotsScreen> createState() => _SpotsScreenState();
}

class _SpotsScreenState extends State<SpotsScreen> {
  final AppStore _store = AppStore.instance;
  bool _showScout = true;
  bool _topo = false;
  String? _pendingRemoveId;

  @override
  void initState() {
    super.initState();
    _store.load();
  }

  // ---- Sample wind, deterministic per place, labelled Sample. ----
  static const _dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  static const _arrows = {
    'N': '↓',
    'NE': '↙',
    'E': '←',
    'SE': '↖',
    'S': '↑',
    'SW': '↗',
    'W': '→',
    'NW': '↘',
  };

  String _windTag(String place) {
    var hash = 0;
    for (final c in place.codeUnits) {
      hash = (hash * 31 + c) % 100000;
    }
    final dir = _dirs[hash % _dirs.length];
    final speed = 5 + (hash % 10);
    return '${_arrows[dir]} $dir · $speed mph · Sample';
  }

  String _boneFor(LogEntry log) {
    if (log.isFish) return '🐟🦴';
    if (log.species == 'Whitetail Deer') return '🦌🦴';
    if (log.species.contains('Squirrel')) return '🐿️🦴';
    if (log.species == 'Coyote' ||
        log.species.contains('Fox') ||
        log.species == 'Bobcat') {
      return '🐺🦴';
    }
    return '🦴'; // turkey / game birds / unknown
  }

  String _liveFor(LogEntry log) {
    if (log.isFish) return '🐟';
    if (log.species == 'Whitetail Deer') return '🦌';
    if (log.species == 'Wild Turkey') return '🦃';
    if (log.species.contains('Squirrel')) return '🐿️';
    if (log.species.contains('Fox') || log.species == 'Coyote') {
      return '🦊';
    }
    return '🐾';
  }

  String _formatDate(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  Future<void> _openAdd({LogEntry? editing}) async {
    final result = await showDialog<LogEntry>(
      context: context,
      barrierDismissible: false,
      builder: (_) => _AddLogDialog(existing: editing),
    );
    if (result == null) return;
    if (editing != null) {
      // Edit preserves the original trip link; Stats re-derive.
      await _store.updateLog(result);
    } else if (!result.isScout) {
      await _applyTripAsk(result);
    } else {
      await _store.addLog(result);
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            editing != null
                ? 'Log updated.'
                : result.isScout
                    ? 'Scout spot saved. Scout does not change Stats.'
                    : 'Catch / harvest saved. Stats updated.',
          ),
        ),
      );
    }
  }

  /// Trip ask, Catch/Harvest only. If a trip exists for the log's
  /// date, ask to tie to it (default Yes). Otherwise (or on "No"),
  /// ask for a trip location and create the trip. Saving is blocked
  /// if there is no location at all for a new trip.
  Future<void> _applyTripAsk(LogEntry log) async {
    final trips = _store.tripsForDate(log.date);
    if (trips.isNotEmpty) {
      final tie = await showDialog<bool>(
        context: context,
        builder: (ctx) {
          final t = trips.first;
          return AlertDialog(
            title: const Text('Tie this catch / harvest to a trip?'),
            content: Text(
              'A trip exists for ${_formatDate(log.date)}: '
              '${t.species} at ${t.place}, ${t.county} County. '
              'Tie this catch / harvest to it?',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(false),
                child: const Text('No — create a new trip instead'),
              ),
              ElevatedButton(
                onPressed: () => Navigator.of(ctx).pop(true),
                child: const Text('Yes — tie it to this trip'),
              ),
            ],
          );
        },
      );
      if (tie == true) {
        await _store.addLog(
          log.copyWith(tripId: trips.first.id, tripAutoCreated: false),
        );
        return;
      }
    }
    // No trip, or user chose a new trip: ask for a location.
    final locationController = TextEditingController(text: log.place);
    final location = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Text('Create a trip for this day'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'No trip exists for this date. Enter a trip location '
              'to create one in Planned Trips.',
            ),
            const SizedBox(height: 12),
            TextField(
              controller: locationController,
              decoration: const InputDecoration(
                labelText: 'Trip location',
              ),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.of(ctx).pop(
              locationController.text.trim(),
            ),
            child: const Text('Create trip & save log'),
          ),
        ],
      ),
    );
    if (location == null || location.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Not saved: a Catch / Harvest log needs a trip, and '
              'a new trip needs a location.',
            ),
          ),
        );
      }
      return;
    }
    final trip = Trip(
      id: AppStore.newId(),
      date: Trip.dateOnly(log.date),
      species: log.species,
      isFish: log.isFish,
      county: log.county,
      place: location,
      autoCreated: true,
    );
    await _store.addTrip(trip);
    await _store.addLog(
      log.copyWith(tripId: trip.id, tripAutoCreated: true),
    );
  }

  Future<void> _replacePhoto(LogEntry log) async {
    final picker = ImagePicker();
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('Take picture'),
              onTap: () => Navigator.of(ctx).pop(ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.upload),
              title: const Text('Upload picture'),
              onTap: () => Navigator.of(ctx).pop(ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (source == null) return;
    final picked = await picker.pickImage(source: source);
    if (picked == null) return;
    final saved = await _copyPhoto(picked.path);
    await _store.updateLog(log.copyWith(photoPath: saved));
  }

  Future<String> _copyPhoto(String path) async =>
      copyLogPhoto(path);

  Widget _photoWidget(LogEntry log, {double height = 160}) {
    final path = log.photoPath;
    final hasPhoto = path != null && File(path).existsSync();
    return Stack(
      children: [
        Container(
          height: height,
          width: double.infinity,
          color: const Color(0xFF1E2429),
          child: hasPhoto
              ? Image.file(
                  File(path),
                  fit: BoxFit.cover,
                  errorBuilder: (_, error, stackTrace) => const Icon(
                    Icons.photo,
                    size: 48,
                  ),
                )
              : const Icon(Icons.photo, size: 48),
        ),
        // Gold pencil, upper-right corner, on every photo.
        Positioned(
          top: 6,
          right: 6,
          child: InkWell(
            onTap: () => _replacePhoto(log),
            child: Container(
              padding: const EdgeInsets.all(6),
              decoration: const BoxDecoration(
                color: Color(0xFFD4AF37),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.edit,
                size: 16,
                color: Colors.black,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _logCard(LogEntry log) {
    final isPendingRemove = _pendingRemoveId == log.id;
    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Photo keeps its own gold pencil, upper-right, inside
          // _photoWidget. Card pencil + trash are in the card-body
          // header row (right-aligned) instead of stacked on top
          // of the photo pencil, so both stay tappable — stacking
          // them in the same corner would have covered the photo
          // pencil and made photo-only replacement untappable.
          _photoWidget(log),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Spacer(),
                    InkWell(
                      onTap: () => _openAdd(editing: log),
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: const BoxDecoration(
                          color: Color(0xFFD4AF37),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.edit,
                          size: 16,
                          color: Colors.black,
                        ),
                      ),
                    ),
                    const SizedBox(width: 6),
                    InkWell(
                      onTap: () async {
                        if (isPendingRemove) {
                          await _store.removeLog(log.id);
                          setState(() => _pendingRemoveId = null);
                        } else {
                          setState(() => _pendingRemoveId = log.id);
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: isPendingRemove
                              ? Colors.red
                              : Colors.black54,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.delete,
                          size: 16,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
                Text(
                  '${log.isScout ? _liveFor(log) : _boneFor(log)} '
                  '${log.species}',
                  style: GoogleFonts.caveatBrush(fontSize: 24),
                ),
                const SizedBox(height: 4),
                Text(
                  '${_formatDate(log.date)} · ${log.place}, '
                  '${log.county} County',
                ),
                if (log.isFish && log.lengthIn != null)
                  Text('Length: ${log.lengthIn} in'),
                if (log.weightLb != null)
                  Text(
                    'Est. weight: ~${log.weightLb} lb',
                  ),
                if (log.baitOrWeapon.isNotEmpty)
                  Text(
                    log.isFish
                        ? 'Bait: ${log.baitOrWeapon}'
                        : 'Weapon: ${log.baitOrWeapon}',
                  ),
                if (log.shotDistanceYds != null)
                  Text('Shot distance: ${log.shotDistanceYds} yds'),
                if (log.lat == null || log.lng == null)
                  const Text(
                    'Listed, no map pin (no coordinates entered).',
                    style: TextStyle(fontStyle: FontStyle.italic),
                  ),
                if (isPendingRemove)
                  const Text(
                    'Tap trash again to remove.',
                    style: TextStyle(color: Colors.red),
                  ),
                if (!log.isScout) ...[
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => ShareCardScreen(log: log),
                        ),
                      );
                    },
                    child: const Text('View share card'),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _mapSection(List<LogEntry> entries) {
    final pinned = entries
        .where((e) => e.lat != null && e.lng != null)
        .toList();
    final center = pinned.isNotEmpty
        ? LatLng(pinned.first.lat!, pinned.first.lng!)
        : const LatLng(38.6, -80.8);
    final markers = pinned.map((e) {
      return Marker(
        point: LatLng(e.lat!, e.lng!),
        width: 180,
        height: 72,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Pin art, fixed by panel (no pin-style toggle):
                // Scout = live animal, Catch/Harvest = bone, both
                // set automatically by species via _liveFor/_boneFor.
                // LIMITATION, stated plainly: these are emoji glyphs
                // on a dark pin, NOT custom bone SVG drawings. The
                // prototype's bone SVGs were not re-drawn as Flutter
                // map-marker SVGs in this chunk; the species mapping
                // and the Scout-live / Catch-bone distinction are
                // preserved, and the pin re-draws on species change
                // because it is built from the log entry itself.
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: const BoxDecoration(
                    color: Colors.black87,
                    shape: BoxShape.circle,
                  ),
                  child: Text(
                    _showScout ? _liveFor(e) : _boneFor(e),
                    style: const TextStyle(
                      fontSize: 20,
                      color: Color(0xFFF5F0E1), // bone-white
                    ),
                  ),
                ),
                const SizedBox(width: 4),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 6,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.black87,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    _windTag(e.place),
                    style: const TextStyle(fontSize: 11),
                  ),
                ),
              ],
            ),
          ],
        ),
      );
    }).toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text(
              'Map',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const Spacer(),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: false, label: Text('Standard')),
                ButtonSegment(value: true, label: Text('Topographic')),
              ],
              selected: {_topo},
              onSelectionChanged: (v) =>
                  setState(() => _topo = v.first),
            ),
          ],
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 260,
          child: FlutterMap(
            options: MapOptions(
              initialCenter: center,
              initialZoom: pinned.isNotEmpty ? 10 : 7,
            ),
            children: [
              TileLayer(
                // Standard: OpenStreetMap. Topographic: OpenTopoMap,
                // real topo tiles (SRTM contours + elevation shading).
                // Both need internet for tiles; lists work offline.
                urlTemplate: _topo
                    ? 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png'
                    : 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.casttrigger',
              ),
              MarkerLayer(markers: markers),
            ],
          ),
        ),
        const SizedBox(height: 4),
        Text(
          _topo
              ? 'Topographic: OpenTopoMap tiles (SRTM contours). '
                  'Tiles need internet. Wind tags are Sample data, '
                  'not live weather.'
              : 'Standard: © OpenStreetMap contributors. Wind tags '
                  'are Sample data, not live weather.',
          style: const TextStyle(
            fontSize: 12,
            fontStyle: FontStyle.italic,
          ),
        ),
        if (pinned.isEmpty)
          const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text(
              'No pins on this map yet — add coordinates to a log '
              'to pin it. No coordinates are invented.',
            ),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _store,
      builder: (context, _) {
        final entries = _showScout ? _store.scoutLogs : _store.catchLogs;
        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Spots',
                      style: GoogleFonts.caveatBrush(fontSize: 30),
                    ),
                  ),
                  // The ONLY add entry point: moss-green + in the
                  // Spots header corner. No bottom add buttons.
                  InkWell(
                    onTap: () => _openAdd(),
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: const BoxDecoration(
                        color: Color(0xFF6B8F5E),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.add,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              const Text(
                'Private by default. Share cards show water/county '
                'only, never GPS.',
                style: TextStyle(fontStyle: FontStyle.italic),
              ),
              const SizedBox(height: 12),
              SegmentedButton<bool>(
                segments: const [
                  ButtonSegment(value: true, label: Text('Scout')),
                  ButtonSegment(
                    value: false,
                    label: Text('Catch / Harvest'),
                  ),
                ],
                selected: {_showScout},
                onSelectionChanged: (v) =>
                    setState(() => _showScout = v.first),
              ),
              const SizedBox(height: 12),
              _mapSection(entries),
              const SizedBox(height: 16),
              if (entries.isEmpty)
                const Text(
                  'Nothing here yet. Tap + in the header to add a '
                  'photo log.',
                )
              else
                for (final log in entries) ...[
                  _logCard(log),
                  const SizedBox(height: 12),
                ],
            ],
          ),
        );
      },
    );
  }
}

/// Add / edit log pop-up. Scout vs Catch/Harvest is chosen BEFORE
/// saving. Photo is optional. Species ID in this chunk is manual
/// entry (the user confirms the species); on-device ML species ID
/// from a photo is NOT built here — see the final report. No data
/// is shown as identified until the user enters a species.
class _AddLogDialog extends StatefulWidget {
  const _AddLogDialog({this.existing});

  final LogEntry? existing;

  @override
  State<_AddLogDialog> createState() => _AddLogDialogState();
}

class _AddLogDialogState extends State<_AddLogDialog> {
  static const String manualEntry = 'Manual / other entry';
  final ImagePicker _picker = ImagePicker();

  bool _isScout = true;
  bool _isFish = true;
  String _species = 'Largemouth Bass';
  DateTime _date = DateTime.now();
  String _county = 'Kanawha';
  String _water = 'Kanawha River';
  final TextEditingController _areaController = TextEditingController();
  final TextEditingController _lengthController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _baitController = TextEditingController();
  final TextEditingController _shotController = TextEditingController();
  final TextEditingController _latController = TextEditingController();
  final TextEditingController _lngController = TextEditingController();
  String? _photoPath;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    if (e != null) {
      _isScout = e.isScout;
      _isFish = e.isFish;
      _species = e.species;
      _date = e.date;
      _county = e.county;
      if (e.isFish) {
        _water = e.place;
      } else {
        _areaController.text = e.place;
      }
      if (e.lengthIn != null) {
        _lengthController.text = e.lengthIn.toString();
      }
      if (e.weightLb != null) {
        _weightController.text = e.weightLb.toString();
      }
      _baitController.text = e.baitOrWeapon;
      if (e.shotDistanceYds != null) {
        _shotController.text = e.shotDistanceYds.toString();
      }
      if (e.lat != null) _latController.text = e.lat.toString();
      if (e.lng != null) _lngController.text = e.lng.toString();
      _photoPath = e.photoPath;
    }
  }

  @override
  void dispose() {
    _areaController.dispose();
    _lengthController.dispose();
    _weightController.dispose();
    _baitController.dispose();
    _shotController.dispose();
    _latController.dispose();
    _lngController.dispose();
    super.dispose();
  }

  List<String> get _speciesOptions {
    final options = _isFish ? fishSpecies : gameSpecies;
    return [...options, manualEntry];
  }

  Future<void> _pickPhoto(ImageSource source) async {
    final picked = await _picker.pickImage(source: source);
    if (picked == null) return;
    final saved = await copyLogPhoto(picked.path);
    setState(() => _photoPath = saved);
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime.now().subtract(const Duration(days: 365 * 3)),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) setState(() => _date = picked);
  }

  String _formatDate(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  void _save() {
    if (_species.isEmpty) return;
    final place = _isFish ? _water : _areaController.text.trim();
    if (place.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Enter a water or hunting area first.'),
        ),
      );
      return;
    }
    final lat = double.tryParse(_latController.text.trim());
    final lng = double.tryParse(_lngController.text.trim());
    if ((_latController.text.trim().isNotEmpty && lat == null) ||
        (_lngController.text.trim().isNotEmpty && lng == null)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Coordinates must be numbers, or left blank.'),
        ),
      );
      return;
    }
    final existing = widget.existing;
    final log = LogEntry(
      id: existing?.id ?? AppStore.newId(),
      isScout: _isScout,
      isFish: _isFish,
      species: _species,
      date: _date,
      county: _county,
      place: place,
      lengthIn: double.tryParse(_lengthController.text.trim()),
      weightLb: double.tryParse(_weightController.text.trim()),
      baitOrWeapon: _baitController.text.trim(),
      shotDistanceYds: int.tryParse(_shotController.text.trim()),
      photoPath: _photoPath,
      lat: lat,
      lng: lng,
      tripId: existing?.tripId,
      tripAutoCreated: existing?.tripAutoCreated ?? false,
    );
    Navigator.of(context).pop(log);
  }

  @override
  Widget build(BuildContext context) {
    final photo = _photoPath;
    return AlertDialog(
      title: Text(
        widget.existing != null ? 'Edit log' : 'Add a log',
        style: GoogleFonts.caveatBrush(fontSize: 28),
      ),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Photo tool: Take / Upload, either/or. Species is
            // entered manually in this chunk — no ML ID is claimed.
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickPhoto(ImageSource.camera),
                    icon: const Icon(Icons.camera_alt),
                    label: const Text('Take picture'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickPhoto(ImageSource.gallery),
                    icon: const Icon(Icons.upload),
                    label: const Text('Upload picture'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (photo != null && File(photo).existsSync())
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.file(
                  File(photo),
                  height: 140,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              )
            else
              const Text(
                'Photo is optional. Species below is entered '
                'manually — no photo ID is claimed in this chunk.',
                style: TextStyle(fontStyle: FontStyle.italic),
              ),
            const SizedBox(height: 12),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: true, label: Text('Scout')),
                ButtonSegment(
                  value: false,
                  label: Text('Catch / Harvest'),
                ),
              ],
              selected: {_isScout},
              onSelectionChanged: (v) =>
                  setState(() => _isScout = v.first),
            ),
            const SizedBox(height: 8),
            if (_isScout)
              const Text(
                'Scout does not change Stats.',
                style: TextStyle(fontStyle: FontStyle.italic),
              ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: _isFish
                        ? null
                        : () => setState(() {
                              _isFish = true;
                              _species = 'Largemouth Bass';
                            }),
                    child: const Text('Fish'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton(
                    onPressed: !_isFish
                        ? null
                        : () => setState(() {
                              _isFish = false;
                              _species = 'Whitetail Deer';
                            }),
                    child: const Text('Hunt'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _speciesOptions.contains(_species)
                  ? _species
                  : manualEntry,
              decoration: const InputDecoration(labelText: 'Species'),
              items: _speciesOptions
                  .map(
                    (s) => DropdownMenuItem(value: s, child: Text(s)),
                  )
                  .toList(),
              onChanged: (v) {
                if (v != null) setState(() => _species = v);
              },
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                const Text('Date: '),
                TextButton(
                  onPressed: _pickDate,
                  child: Text(_formatDate(_date)),
                ),
              ],
            ),
            DropdownButtonFormField<String>(
              value: _county,
              decoration: const InputDecoration(labelText: 'County'),
              items: wvCounties
                  .map(
                    (c) => DropdownMenuItem(
                      value: c,
                      child: Text('$c County'),
                    ),
                  )
                  .toList(),
              onChanged: (v) {
                if (v == null) return;
                setState(() {
                  _county = v;
                  _water = watersForCounty(_county).first;
                });
              },
            ),
            const SizedBox(height: 12),
            if (_isFish)
              DropdownButtonFormField<String>(
                value: _water,
                decoration: const InputDecoration(labelText: 'Water'),
                items: watersForCounty(_county)
                    .map(
                      (w) => DropdownMenuItem(value: w, child: Text(w)),
                    )
                    .toList(),
                onChanged: (v) {
                  if (v != null) setState(() => _water = v);
                },
              )
            else
              TextField(
                controller: _areaController,
                decoration: const InputDecoration(
                  labelText: 'Hunting area',
                ),
              ),
            const SizedBox(height: 12),
            if (_isFish)
              TextField(
                controller: _lengthController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Length (in, optional)',
                ),
              ),
            TextField(
              controller: _weightController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: _isFish
                    ? 'Est. weight (lb, optional)'
                    : 'Est. weight (lb, optional, manual)',
              ),
            ),
            TextField(
              controller: _baitController,
              decoration: InputDecoration(
                labelText: _isFish ? 'Bait / lure' : 'Weapon / ammo',
              ),
            ),
            if (!_isFish)
              TextField(
                controller: _shotController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Shot distance (yds, optional)',
                ),
              ),
            const SizedBox(height: 12),
            const Text(
              'Map pin (optional): enter coordinates or leave blank. '
              'No coordinates are invented.',
              style: TextStyle(fontStyle: FontStyle.italic),
            ),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _latController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Latitude',
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _lngController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Longitude',
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _save,
          child: const Text('Save'),
        ),
      ],
    );
  }
}
