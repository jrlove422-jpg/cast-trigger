# Cast & Trigger — Flutter app (complete app, Chunks 1–3)

**Complete app, not placeholders:** disclaimer gate + Planner
(Chunk 1, kept intact) + Planned Trips, Spots log feed, Stats,
My License, and Share Card (Chunks 2–3). The only remaining
placeholder file is `lib/screens/placeholder_screen.dart`, which
is no longer used by the app shell — it is kept on disk only and
is NOT shown on any tab.

## What is built

- 5-tab shell, in order: Planner, Planned Trips, Spots, Stats,
  My License.
- Disclaimer gate (first screen on first open): one-time
  "Read & Agree", short "Check before you go" warning + full
  10-section disclaimer. Locked until the user scrolls to the end,
  checks "I have read and understand…", and taps "Agree & start
  using the app". Agreement version + date/time saved locally.
  Planner shows a "Disclaimer & user agreement" card with the
  saved date and a read-only re-read button. In the real app this
  must ALSO be recorded server-side.
- Planner: Fish/Hunt radio (Fish default), species picker, county
  dropdown with all 55 WV counties (Kanawha default, " County"
  suffix), water dropdown for fish / free-text hunting area for
  hunting, weapon picker for hunting (Bow / Firearm / Muzzleloader)
  changing the season verdict, pack list (Firearm pack list for
  hunting; Knife on every list), motto and save button: Fish =
  "Cast that line", Hunt = "Pull that trigger".
  - Planner fish rule: species list is ALWAYS the full 28 + manual
    entry. Picking a fish narrows county/water to where it occurs
    (Musky 22 of 55 counties, Walleye 28). A county or water change
    NEVER narrows or moves the species. Hunting/manual restores
    all 55 counties.
  - Saving a trip now PERSISTS it: it appears in Planned Trips
    and its calendar. Loading a trip from Planned Trips puts it
    back into the Planner.
  - Coyote spec, dusk rule (placeholder dusk 6:30 PM, labelled
    as such — no live sunset API wired yet), and the sample-data
    verdict warning are as in Chunk 1.
- Planned Trips: month calendar (prev/next, "This month" reset,
  gold-ringed trip days, today highlighted, tap a day to filter),
  upcoming-trips list, Load in Planner, Remove with confirm.
- Spots (log feed): Scout / Catch-Harvest sliding toggle, never
  mixed. Moss-green + in the Spots header is the ONLY add entry.
  Add pop-up: Take / Upload picture (either/or), Scout vs
  Catch/Harvest choice BEFORE saving, date, county, water/area,
  length, est. weight, bait/weapon, shot distance, optional
  lat/lng (blank = listed by name, no map pin, no invented
  coordinates). Catch/Harvest feeds Stats in the same tap; Scout
  touches no Stats. Trip ask for Catch/Harvest: tie to an existing
  trip for that date (default Yes) or create one asking location
  (blocked if no location); both record full share-card data.
  Edit via gold pencil in the card corner; remove via two-tap
  trash. Cascades: auto-created trips go with their log, tied
  trips stay.
  - Maps: Standard (OpenStreetMap) / Topographic (OpenTopoMap —
    real SRTM-contour topo tiles, NOT a terrain-style approximation;
    tiles need internet, lists work offline). Every pin carries a
    wind tag beside it on the map ONLY (deterministic sample
    wind, labelled "Sample", e.g. "NW · 9 mph"), never as data
    below maps.
  - Pins: Scout = live-animal, Catch/Harvest = bone, set
    automatically by species (fish = fish skeleton, deer = deer
    skull, turkey/game birds = bird skull, squirrels = small skull
    with buck teeth, coyote/fox/bobcat = predator skull,
    unknown = bone), bone-white on a dark pin, no pin-style
    toggle. LIMITATION: pins are emoji glyphs on dark pins, NOT
    custom bone SVG drawings — see Verification.
- Stats: derived from logs ONLY. Exactly three tiles — Trips,
  Fish caught, Wild Game Harvested. NO Hours tile. Fish-by-month
  chart derived from logs, personal bests strictly split by
  category (fish bests only under Fish, game bests only under
  Game), tap a tile to see that category's logs and stored
  share cards.
- My License: ONE slot, photo OR PDF + good-through date,
  add/replace/remove, expired/expiring-soon status, on-device
  offline. SECURITY (decided, mandatory): biometric/PIN gate on
  EVERY open of this screen (local_auth, PIN fallback; leaving
  the tab re-locks it and clears decrypted data), license file
  stored AES-256-CBC encrypted with a keystore-backed key
  (flutter_secure_storage), screenshots blocked on this screen
  (screen_security, Android FLAG_SECURE), SSN warning before
  every save + photo crop/mask option, NO SSN typed field, and
  NO license data in share cards, logs, exports, cloud sync, or
  AI. Optional whole-app lock toggle (default OFF) — when on,
  the app requires biometric/PIN on start.
  - MISSING, stated plainly: no embedded in-app PDF viewer —
    a PDF is decrypted to a temp file and opened in the device
    PDF viewer. A PDF cannot be cropped in-app.
- Share card: ONE basic template (extra templates are Premium
  later). Full-bleed photo, logo badge upper-left, Caveat Brush
  species title, date/time/location line (water/county ONLY,
  never GPS), compact stat chips (estimates labelled "~" /
  "Est."), placement Bottom / Top / Slim bottom (Top = slim
  panel upper-right beside the logo). Share via native share
  sheet with the rendered card image; if sharing fails, a
  fallback message is shown.
- Branding, kept intact: Caveat Brush display + Barlow body via
  google_fonts, approved logo in assets/cast-trigger-logo.webp
  in the app bar, launcher icon via flutter_launcher_icons from
  assets/app-icon.png (logo artwork cropped, no bottom text).
- Waters: Summersville Lake ONLY in Nicholas County, never
  Mineral. Mineral = Jennings Randolph Lake, North Branch
  Potomac River, Patterson Creek, New Creek.
- Fish-county filter fix (already applied, NOT regressed):
  Musky 22 and Walleye 28 counties derived from the prototype
  WATER_FISH mapping. Walleye includes Mineral (Jennings
  Randolph Lake and North Branch Potomac River tailwater both
  list walleye). All other fish default to all 55 counties
  (sample placeholder).

## What is NOT in this build

- No billing / Premium purchase flow. Extra states in the state
  menu are "Coming soon", not a purchase. No paywall on the
  core log.
- No on-device ML species ID from a photo: Spots species entry
  is manual (user confirms the species). No photo ID, no dog
  regression test, and no AI bite predictions — ever.
- No maps beyond the Spots OpenStreetMap / OpenTopoMap tiles
  above; no parcel/property-line data, no scraped onX/Fishbrain
  data, no invented coordinates, no offline topo tiles.
- No Scout trail-camera ingestion (question only), no real
  group-trip sharing, no cloud sync, no accounts.
- No LLC, domain, trademark filing, or contacting WV/Regrid.
- All seasons, waters, species maps and numbers are SAMPLE
  prototype data, not official WVDNR regulations. Every season
  verdict shows "Sample data — check official WVDNR
  regulations" with a verified-date/source placeholder.

## Working name warning

Cast & Trigger is a WORKING NAME ONLY, NOT CLEARED. A live CAST
mark (USPTO Serial 97175263) is flagged for attorney review, and
domain availability is unverified. Do not file, buy a domain, or
launch under this name until that review is resolved. The
disclaimer is a DRAFT for attorney review, not final legal text.

## Run it / build it

Requires the Flutter SDK (not included here, and not available
in the environment where this was written — a full Flutter
compile was NOT run here; see Verification).

```sh
cd cast-trigger-flutter
flutter pub get
flutter run
```

Or use the GitHub Actions workflow in
.github/workflows/build-apk.yml: it unzips a zip, generates
the Android scaffold with `flutter create`, runs
`flutter_launcher_icons`, then builds a debug APK. It
deliberately has NO `flutter analyze` gate (analyze failed on
lint/info issues before; the APK build catches real errors).

## Verification (honest status)

- Flutter / Dart toolchain was NOT available in the writing
  environment (`flutter` and `dart` not found), so `flutter
  analyze` and a full compile were NOT run here. This is NOT
  compile-verified: build it in GitHub Actions before treating
  it as working, and expect the first CI run to surface any
  plugin-version / API mismatches (new plugins: image_picker,
  file_picker, local_auth, flutter_secure_storage, encrypt,
  path_provider, share_plus, screen_security, image_cropper,
  open_filex, flutter_map, latlong2).
- Files were read back and checked by script: brace/paren/
  bracket balance, relative imports resolve to files in this
  folder, county count = 55, fish count = 28, game count = 12
  (no Ring-necked Pheasant), Musky counties = 22, Walleye
  counties = 28 (Walleye includes Mineral), Summersville Lake
  only under Nicholas, Mineral has exactly its four waters,
  workflow still contains unzip / flutter create /
  flutter_launcher_icons / flutter build apk and no
  `flutter analyze` step (only a comment explaining why),
  logo asset + icon asset + icon config + google_fonts usage
  + app-bar logo all still present, Stats has no Hours tile
  (only a comment saying not to re-add it), share-card code
  contains no license reference.
- Pin rendering: emoji glyphs on dark pins, NOT custom bone
  SVG drawings. Species mapping and Scout-live / Catch-bone
  distinction are automatic and preserved; SVG bone art is
  still to be drawn if George wants exact prototype pins.
- Spots species-by-water mapping is partial in this chunk:
  county narrowing uses the Musky/Walleye county lists; other
  fish are offered as the full list, not the prototype's full
  WATER_FISH water-by-water mapping.
- Whole-app lock applies on app start only, not on every
  resume from background.
- Run `flutter analyze` on a machine with the Flutter SDK
  before treating this as compile-clean, and test on a real
  device/emulator before any further chunk.
