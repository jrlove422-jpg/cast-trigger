import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../data/app_store.dart';

/// Planned Trips: month calendar + upcoming trips list.
/// Saving from the Planner actually persists here (AppStore).
/// Tapping "Load in Planner" sends the trip back to the Planner tab
/// via AppStore.pendingPlannerTrip; the shell switches to Planner.
class PlannedTripsScreen extends StatefulWidget {
  const PlannedTripsScreen({
    super.key,
    required this.onLoadTrip,
  });

  final VoidCallback onLoadTrip;

  @override
  State<PlannedTripsScreen> createState() => _PlannedTripsScreenState();
}

class _PlannedTripsScreenState extends State<PlannedTripsScreen> {
  final AppStore _store = AppStore.instance;
  DateTime _month = DateTime(
    DateTime.now().year,
    DateTime.now().month,
    1,
  );
  DateTime? _selectedDay;

  @override
  void initState() {
    super.initState();
    _store.load();
  }

  String _formatDate(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  String _monthLabel(DateTime m) {
    const names = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    return '${names[m.month - 1]} ${m.year}';
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _store,
      builder: (context, _) {
        final trips = [..._store.trips]
          ..sort((a, b) => a.date.compareTo(b.date));
        final tripDays = <DateTime, List<Trip>>{};
        for (final t in trips) {
          final d = Trip.dateOnly(t.date);
          tripDays.putIfAbsent(d, () => []).add(t);
        }
        final firstWeekday = DateTime(_month.year, _month.month, 1).weekday;
        // Monday-first calendar grid.
        final leading = (firstWeekday - 1) % 7;
        final daysInMonth = DateTime(
          _month.year,
          _month.month + 1,
          0,
        ).day;
        final today = Trip.dateOnly(DateTime.now());
        final shown = _selectedDay == null
            ? trips
            : trips
                .where(
                  (t) => Trip.dateOnly(t.date) == _selectedDay,
                )
                .toList();
        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Planned Trips',
                style: GoogleFonts.caveatBrush(fontSize: 30),
              ),
              const SizedBox(height: 4),
              const Text(
                'A typed location carries through the whole trip on '
                'every screen.',
                style: TextStyle(fontStyle: FontStyle.italic),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  IconButton(
                    onPressed: () => setState(() {
                      _month = DateTime(_month.year, _month.month - 1, 1);
                    }),
                    icon: const Icon(Icons.chevron_left),
                  ),
                  Expanded(
                    child: Center(
                      child: Text(
                        _monthLabel(_month),
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => setState(() {
                      _month = DateTime(_month.year, _month.month + 1, 1);
                    }),
                    icon: const Icon(Icons.chevron_right),
                  ),
                  TextButton(
                    onPressed: () => setState(() {
                      _month = DateTime(
                        DateTime.now().year,
                        DateTime.now().month,
                        1,
                      );
                      _selectedDay = null;
                    }),
                    child: const Text('This month'),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 7,
                ),
                itemCount: leading + daysInMonth,
                itemBuilder: (context, index) {
                  if (index < leading) return const SizedBox.shrink();
                  final day = index - leading + 1;
                  final date = DateTime(_month.year, _month.month, day);
                  final hasTrip = tripDays.containsKey(date);
                  final isToday = date == today;
                  final isSelected = date == _selectedDay;
                  return InkWell(
                    onTap: () => setState(() {
                      _selectedDay =
                          isSelected ? null : date;
                    }),
                    child: Container(
                      margin: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        color: isToday
                            ? const Color(0xFF6B8F5E).withOpacity(0.35)
                            : null,
                        border: Border.all(
                          color: hasTrip
                              ? const Color(0xFFD4AF37)
                              : isSelected
                                  ? Colors.white54
                                  : Colors.transparent,
                          width: hasTrip ? 2 : 1,
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Center(child: Text('$day')),
                    ),
                  );
                },
              ),
              const SizedBox(height: 16),
              Text(
                _selectedDay == null
                    ? 'Upcoming trips'
                    : 'Trips on ${_formatDate(_selectedDay!)} '
                        '(tap the day again to show all)',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              if (shown.isEmpty)
                const Text(
                  'No trips yet. Save one from the Planner, or save '
                  'a Catch / Harvest log in Spots and a trip will be '
                  'created for that day.',
                )
              else
                for (final trip in shown)
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            trip.species,
                            style: GoogleFonts.caveatBrush(fontSize: 24),
                          ),
                          Text(
                            '${_formatDate(trip.date)} · ${trip.place}, '
                            '${trip.county} County',
                          ),
                          if (trip.weapon.isNotEmpty)
                            Text('Weapon: ${trip.weapon}'),
                          if (trip.autoCreated)
                            const Text(
                              'Created automatically from a log entry.',
                              style: TextStyle(
                                fontStyle: FontStyle.italic,
                              ),
                            ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              TextButton(
                                onPressed: () {
                                  _store.requestPlannerLoad(trip);
                                  widget.onLoadTrip();
                                },
                                child: const Text('Load in Planner'),
                              ),
                              TextButton(
                                onPressed: () async {
                                  final ok = await showDialog<bool>(
                                    context: context,
                                    builder: (ctx) => AlertDialog(
                                      title: const Text('Remove trip?'),
                                      content: const Text(
                                        'This removes the planned '
                                        'trip. Logs tied to it are '
                                        'not removed.',
                                      ),
                                      actions: [
                                        TextButton(
                                          onPressed: () =>
                                              Navigator.of(ctx).pop(false),
                                          child: const Text('Keep'),
                                        ),
                                        ElevatedButton(
                                          onPressed: () =>
                                              Navigator.of(ctx).pop(true),
                                          child: const Text('Remove'),
                                        ),
                                      ],
                                    ),
                                  );
                                  if (ok == true) {
                                    await _store.removeTrip(trip.id);
                                  }
                                },
                                child: const Text('Remove'),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
            ],
          ),
        );
      },
    );
  }
}
