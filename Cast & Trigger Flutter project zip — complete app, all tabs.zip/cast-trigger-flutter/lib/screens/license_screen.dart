import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:local_auth/local_auth.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:screen_security/screen_security.dart';

import '../data/app_store.dart';
import '../data/license_service.dart';

/// My License — ONE slot: one photo OR one PDF + one good-through
/// date, on-device offline, add / replace / remove, expired /
/// expiring-soon status.
///
/// SECURITY SPEC — DECIDED, MANDATORY, NOT OPTIONAL:
/// - Biometric/PIN gate on EVERY open of this screen. The shell
///   passes [isActive]; when this tab becomes active the screen
///   locks again and re-authenticates. Leaving the tab clears the
///   decrypted photo from memory.
/// - License file stored ENCRYPTED (LicenseService, AES-256-CBC,
///   key in flutter_secure_storage). Plaintext only in memory, or
///   in a temp file at PDF-open time.
/// - Screenshots blocked while this screen is active, via
///   screen_security (Android FLAG_SECURE).
/// - NO license data in share cards, logs, exports, cloud sync, or
///   AI. This screen never calls any share/export/AI code with
///   license bytes.
/// - Warn before saving, and offer photo cropping/masking, because
///   a license photo may show an SSN / hunter safety number.
///   NO SSN is ever stored as a typed field — there is no SSN field.
/// - Optional whole-app lock toggle, default OFF. When ON, the app
///   shows a biometric unlock screen on start (see AppLockScreen).
///
/// MISSING, stated plainly: no embedded in-app PDF viewer in this
/// chunk — a PDF is decrypted to a temp file and opened with the
/// device's PDF viewer. A PDF cannot be cropped/masked in-app;
/// the warning tells the user to mask it outside the app first.
class MyLicenseScreen extends StatefulWidget {
  const MyLicenseScreen({super.key, required this.isActive});

  /// True only while this tab is the selected tab in the shell.
  final bool isActive;

  @override
  State<MyLicenseScreen> createState() => _MyLicenseScreenState();
}

class _MyLicenseScreenState extends State<MyLicenseScreen> {
  final LocalAuthentication _auth = LocalAuthentication();
  final ScreenSecurity _screenSecurity = ScreenSecurity();
  final AppStore _store = AppStore.instance;

  bool _locked = true;
  bool _authenticating = false;
  String? _authError;
  LicenseMeta? _meta;
  Uint8List? _photoBytes;
  bool _loadingMeta = false;

  // Staged new license, before the SSN warning + save.
  LicenseKind? _stagedKind;
  String? _stagedName;
  List<int>? _stagedBytes;
  DateTime? _goodThrough;

  @override
  void initState() {
    super.initState();
    _store.load();
    if (widget.isActive) _onBecameActive();
  }

  @override
  void didUpdateWidget(MyLicenseScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!oldWidget.isActive && widget.isActive) {
      _onBecameActive();
    } else if (oldWidget.isActive && !widget.isActive) {
      _onBecameInactive();
    }
  }

  @override
  void dispose() {
    _disableScreenSecurity();
    super.dispose();
  }

  Future<void> _enableScreenSecurity() async {
    try {
      await _screenSecurity.enable();
    } catch (_) {}
  }

  Future<void> _disableScreenSecurity() async {
    try {
      await _screenSecurity.disable();
    } catch (_) {}
  }

  Future<void> _onBecameActive() async {
    await _enableScreenSecurity();
    setState(() {
      _locked = true;
      _photoBytes = null;
      _authError = null;
    });
    await _authenticate();
  }

  void _onBecameInactive() {
    // Leaving the tab locks the screen and clears decrypted data.
    _disableScreenSecurity();
    setState(() {
      _locked = true;
      _photoBytes = null;
      _meta = null;
    });
  }

  Future<void> _authenticate() async {
    if (_authenticating) return;
    setState(() {
      _authenticating = true;
      _authError = null;
    });
    bool ok = false;
    try {
      final canCheck = await _auth.canCheckBiometrics;
      final isSupported = await _auth.isDeviceSupported();
      if (!canCheck && !isSupported) {
        // No biometric / device credential available: do NOT show
        // the license. The user must enrol a device lock first.
        setState(() {
          _authError =
              'No biometric or device lock is available on this '
              'device. Enrol a fingerprint, face, or device PIN '
              'first, then try again.';
        });
      } else {
        ok = await _auth.authenticate(
          localizedReason: 'Unlock My License',
          options: const AuthenticationOptions(
            biometricOnly: false, // PIN / device credential fallback
            stickyAuth: true,
            useErrorDialogs: true,
          ),
        );
        if (!ok) {
          setState(() {
            _authError = 'Authentication was not completed. '
                'Your license stays hidden.';
          });
        }
      }
    } catch (e) {
      setState(() {
        _authError = 'Authentication failed. Your license stays hidden.';
      });
    }
    setState(() {
      _authenticating = false;
      _locked = !ok;
    });
    if (ok) await _loadMeta();
  }

  Future<void> _loadMeta() async {
    setState(() => _loadingMeta = true);
    final meta = await LicenseService.instance.loadMeta();
    Uint8List? photo;
    if (meta != null && meta.kind == LicenseKind.photo) {
      photo = await LicenseService.instance.decryptBytes();
    }
    if (mounted) {
      setState(() {
        _meta = meta;
        _photoBytes = photo;
        _loadingMeta = false;
      });
    }
  }

  String _formatDate(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  Future<void> _pickPhoto() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked == null) return;
    final bytes = await picked.readAsBytes();
    setState(() {
      _stagedKind = LicenseKind.photo;
      _stagedName = picked.name;
      _stagedBytes = bytes.toList();
      _goodThrough ??= DateTime.now().add(const Duration(days: 365));
    });
  }

  Future<void> _takePhoto() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.camera);
    if (picked == null) return;
    final bytes = await picked.readAsBytes();
    setState(() {
      _stagedKind = LicenseKind.photo;
      _stagedName = picked.name;
      _stagedBytes = bytes.toList();
      _goodThrough ??= DateTime.now().add(const Duration(days: 365));
    });
  }

  Future<void> _pickPdf() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
    );
    if (result == null || result.files.isEmpty) return;
    final file = result.files.single;
    List<int>? bytes;
    if (file.path != null) {
      try {
        bytes = await File(file.path!).readAsBytes();
      } catch (_) {
        bytes = file.bytes?.toList();
      }
    } else {
      bytes = file.bytes?.toList();
    }
    if (bytes == null || bytes.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Could not read that PDF. Try again.'),
          ),
        );
      }
      return;
    }
    setState(() {
      _stagedKind = LicenseKind.pdf;
      _stagedName = file.name;
      _stagedBytes = bytes;
      _goodThrough ??= DateTime.now().add(const Duration(days: 365));
    });
  }

  Future<void> _cropStagedPhoto() async {
    if (_stagedBytes == null) return;
    // image_cropper needs a file path, not bytes: write staged bytes
    // to a cache temp file, crop, then read the result back. The
    // staged temp file is in the app cache, not shared storage, and
    // is not a saved license.
    try {
      final cache = await getTemporaryDirectory();
      final stagedPath =
          '${cache.path}/ct_license_staged_${DateTime.now().microsecondsSinceEpoch}.jpg';
      await File(stagedPath).writeAsBytes(_stagedBytes!, flush: true);
      final cropped =
          await ImageCropper().cropImage(sourcePath: stagedPath);
      if (cropped == null) return;
      final bytes = await cropped.readAsBytes();
      setState(() {
        _stagedBytes = bytes.toList();
      });
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Could not crop that photo.'),
          ),
        );
      }
    }
  }

  Future<void> _pickGoodThrough() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _goodThrough ?? DateTime.now(),
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now().add(const Duration(days: 365 * 10)),
    );
    if (picked != null) setState(() => _goodThrough = picked);
  }

  Future<void> _saveStaged() async {
    if (_stagedKind == null ||
        _stagedName == null ||
        _stagedBytes == null ||
        _goodThrough == null) {
      return;
    }
    // SSN warning — mandatory before every save. No SSN field exists.
    final proceed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Check before you save'),
        content: const Text(
          'If this photo or PDF shows your Social Security number '
          'or hunter safety number, consider cropping or masking '
          'that part first. This app never stores an SSN as a '
          'typed field, and never shares, exports, or sends this '
          'license anywhere. It is stored encrypted on this device '
          'only.\n\n'
          'This is a copy — still carry your official license as '
          'required, and check WVDNR rules.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('I understand — save'),
          ),
        ],
      ),
    );
    if (proceed != true) return;
    final meta = await LicenseService.instance.saveLicense(
      kind: _stagedKind!,
      fileName: _stagedName!,
      bytes: _stagedBytes!,
      goodThrough: _goodThrough!,
    );
    Uint8List? photo;
    if (meta.kind == LicenseKind.photo) {
      photo = await LicenseService.instance.decryptBytes();
    }
    if (mounted) {
      setState(() {
        _meta = meta;
        _photoBytes = photo;
        _stagedKind = null;
        _stagedName = null;
        _stagedBytes = null;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('License saved encrypted on this device.'),
        ),
      );
    }
  }

  Future<void> _remove() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Remove license?'),
        content: const Text(
          'This deletes the encrypted license from this device.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Keep'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Remove'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await LicenseService.instance.removeLicense();
    if (mounted) {
      setState(() {
        _meta = null;
        _photoBytes = null;
      });
    }
  }

  Future<void> _openPdf() async {
    final meta = _meta;
    if (meta == null || meta.kind != LicenseKind.pdf) return;
    final path =
        await LicenseService.instance.decryptToTempFile('pdf');
    if (path == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Could not open that PDF.'),
          ),
        );
      }
      return;
    }
    await OpenFilex.open(path);
  }

  @override
  Widget build(BuildContext context) {
    if (_locked) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.lock, size: 48),
              const SizedBox(height: 12),
              Text(
                'My License is locked',
                style: GoogleFonts.caveatBrush(fontSize: 28),
              ),
              const SizedBox(height: 8),
              const Text(
                'Every open requires biometric or device-PIN '
                'authentication, because a license photo may show '
                'an SSN / hunter safety number.',
                textAlign: TextAlign.center,
              ),
              if (_authError != null) ...[
                const SizedBox(height: 12),
                Text(
                  _authError!,
                  style: const TextStyle(color: Colors.red),
                  textAlign: TextAlign.center,
                ),
              ],
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: _authenticating ? null : _authenticate,
                icon: const Icon(Icons.fingerprint),
                label: Text(
                  _authenticating ? 'Checking…' : 'Unlock with biometrics / PIN',
                ),
              ),
            ],
          ),
        ),
      );
    }
    if (_loadingMeta) {
      return const Center(child: CircularProgressIndicator());
    }
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'My License',
            style: GoogleFonts.caveatBrush(fontSize: 30),
          ),
          const SizedBox(height: 4),
          const Text(
            'One license, on-device only, offline. This is a copy — '
            'still carry your official license as required, and '
            'check WVDNR rules.',
            style: TextStyle(fontStyle: FontStyle.italic),
          ),
          const SizedBox(height: 16),
          if (_meta == null && _stagedKind == null)
            const Text(
              'No license saved yet. Add a photo or PDF below.',
            ),
          if (_meta != null) ...[
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            _meta!.fileName,
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: _meta!.status == 'Expired'
                                ? Colors.red
                                : _meta!.status == 'Expiring soon'
                                    ? const Color(0xFFD4AF37)
                                    : const Color(0xFF6B8F5E),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(_meta!.status),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text('Size: ${_meta!.fileSize} bytes'),
                    Text(
                      'Good through: ${_formatDate(_meta!.goodThrough)}',
                    ),
                    const SizedBox(height: 12),
                    if (_meta!.kind == LicenseKind.photo &&
                        _photoBytes != null)
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.memory(
                          _photoBytes!,
                          fit: BoxFit.cover,
                        ),
                      )
                    else if (_meta!.kind == LicenseKind.pdf)
                      ListTile(
                        leading: const Icon(Icons.picture_as_pdf),
                        title: const Text('PDF license'),
                        subtitle: const Text(
                          'Encrypted on-device. Opens in the '
                          'device PDF viewer.',
                        ),
                        trailing: TextButton(
                          onPressed: _openPdf,
                          child: const Text('Open PDF'),
                        ),
                      ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        TextButton(
                          onPressed: _remove,
                          child: const Text('Remove'),
                        ),
                        const Spacer(),
                        const Text(
                          'Screenshots blocked on this screen.',
                          style: TextStyle(
                            fontSize: 12,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
          ],
          const Text(
            'Add / replace license',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: [
              OutlinedButton.icon(
                onPressed: _takePhoto,
                icon: const Icon(Icons.camera_alt),
                label: const Text('Take photo'),
              ),
              OutlinedButton.icon(
                onPressed: _pickPhoto,
                icon: const Icon(Icons.upload),
                label: const Text('Upload photo'),
              ),
              OutlinedButton.icon(
                onPressed: _pickPdf,
                icon: const Icon(Icons.picture_as_pdf),
                label: const Text('Upload PDF'),
              ),
            ],
          ),
          if (_stagedKind != null) ...[
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Staged: $_stagedName'),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Text('Good through: '),
                        TextButton(
                          onPressed: _pickGoodThrough,
                          child: Text(
                            _goodThrough == null
                                ? 'Pick a date'
                                : _formatDate(_goodThrough!),
                          ),
                        ),
                      ],
                    ),
                    if (_stagedKind == LicenseKind.photo)
                      TextButton(
                        onPressed: _cropStagedPhoto,
                        child: const Text(
                          'Crop / mask photo before saving',
                        ),
                      ),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _saveStaged,
                        child: const Text('Save license'),
                      ),
                    ),
                    TextButton(
                      onPressed: () => setState(() {
                        _stagedKind = null;
                        _stagedName = null;
                        _stagedBytes = null;
                      }),
                      child: const Text('Discard staged file'),
                    ),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 24),
          const Text(
            'Settings',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          AnimatedBuilder(
            animation: _store,
            builder: (context, _) => SwitchListTile(
              title: const Text('Whole-app lock'),
              subtitle: const Text(
                'When on, the app requires biometric / PIN '
                'authentication on start. Default off.',
              ),
              value: _store.wholeAppLock,
              onChanged: (v) => _store.setWholeAppLock(v),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'License data is never shared, exported, synced to the '
            'cloud, or sent to AI. There is no SSN field in this app.',
            style: TextStyle(fontStyle: FontStyle.italic),
          ),
        ],
      ),
    );
  }
}

/// Small app-lock screen, shown on start when the whole-app lock
/// toggle is on. The disclaimer gate still runs first on first open.
class AppLockScreen extends StatefulWidget {
  const AppLockScreen({super.key, required this.onUnlocked});

  final VoidCallback onUnlocked;

  @override
  State<AppLockScreen> createState() => _AppLockScreenState();
}

class _AppLockScreenState extends State<AppLockScreen> {
  final LocalAuthentication _auth = LocalAuthentication();
  bool _checking = false;
  String? _error;

  Future<void> _unlock() async {
    setState(() {
      _checking = true;
      _error = null;
    });
    bool ok = false;
    try {
      ok = await _auth.authenticate(
        localizedReason: 'Unlock Cast & Trigger',
        options: const AuthenticationOptions(
          biometricOnly: false,
          stickyAuth: true,
          useErrorDialogs: true,
        ),
      );
    } catch (_) {
      ok = false;
    }
    setState(() {
      _checking = false;
      if (!ok) {
        _error = 'Authentication was not completed.';
      }
    });
    if (ok) widget.onUnlocked();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.lock, size: 48),
              const SizedBox(height: 12),
              Text(
                'Cast & Trigger is locked',
                style: GoogleFonts.caveatBrush(fontSize: 28),
              ),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(
                  _error!,
                  style: const TextStyle(color: Colors.red),
                ),
              ],
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: _checking ? null : _unlock,
                icon: const Icon(Icons.fingerprint),
                label: Text(_checking ? 'Checking…' : 'Unlock'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
