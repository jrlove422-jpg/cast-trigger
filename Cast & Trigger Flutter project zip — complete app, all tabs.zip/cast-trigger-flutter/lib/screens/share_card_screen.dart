import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:cross_file/cross_file.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../data/app_store.dart';

/// Basic share card — ONE template for now (extra templates are
/// Premium later). Approved design: full-bleed photo, final logo
/// badge upper-left, rugged brush species title, date/time/location
/// line, compact stat chips at the bottom, photo dominant.
/// Location is water/county ONLY — never GPS, even if the log has
/// coordinates. Estimates are labelled "~" / "Est.".
/// Info-panel placement: Bottom / Top / Slim bottom. Top puts the
/// panel upper-right beside the logo, slim and smaller.
enum CardPlacement { bottom, top, slimBottom }

class ShareCardScreen extends StatefulWidget {
  const ShareCardScreen({super.key, required this.log});

  final LogEntry log;

  @override
  State<ShareCardScreen> createState() => _ShareCardScreenState();
}

class _ShareCardScreenState extends State<ShareCardScreen> {
  final GlobalKey _cardKey = GlobalKey();
  CardPlacement _placement = CardPlacement.bottom;
  bool _sharing = false;

  String _formatDateTime(DateTime d) {
    final hour = d.hour % 12 == 0 ? 12 : d.hour % 12;
    final ampm = d.hour >= 12 ? 'PM' : 'AM';
    return '${d.year}-${d.month.toString().padLeft(2, '0')}-'
        '${d.day.toString().padLeft(2, '0')} · $hour:'
        '${d.minute.toString().padLeft(2, '0')} $ampm';
  }

  List<Widget> _chips() {
    final log = widget.log;
    final chips = <Widget>[];
    void add(String text) {
      chips.add(
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.black87,
            borderRadius: BorderRadius.circular(999),
          ),
          child: Text(text, style: const TextStyle(fontSize: 12)),
        ),
      );
    }

    if (log.lengthIn != null) add('Length ${log.lengthIn} in');
    if (log.weightLb != null) {
      add('Est. weight ~${log.weightLb} lb');
    }
    if (log.baitOrWeapon.isNotEmpty) {
      add(log.isFish
          ? 'Bait: ${log.baitOrWeapon}'
          : 'Weapon: ${log.baitOrWeapon}');
    }
    if (log.shotDistanceYds != null) {
      add('Shot: ${log.shotDistanceYds} yds');
    }
    return chips;
  }

  Widget _infoPanel({required bool slim}) {
    final log = widget.log;
    return Container(
      padding: EdgeInsets.all(slim ? 8 : 12),
      decoration: BoxDecoration(
        color: Colors.black87,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            log.species,
            style: GoogleFonts.caveatBrush(
              fontSize: slim ? 26 : 34,
              color: Colors.white,
            ),
          ),
          Text(
            '${_formatDateTime(log.date)} · ${log.place}, '
            '${log.county} County',
            style: TextStyle(
              fontSize: slim ? 12 : 14,
              color: Colors.white70,
            ),
          ),
          const SizedBox(height: 6),
          Wrap(spacing: 6, runSpacing: 6, children: _chips()),
        ],
      ),
    );
  }

  Widget _card() {
    final log = widget.log;
    final photo = log.photoPath;
    final hasPhoto = photo != null && File(photo).existsSync();
    return AspectRatio(
      aspectRatio: 3 / 4,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Container(color: const Color(0xFF121417)),
          if (hasPhoto)
            Image.file(
              File(photo),
              fit: BoxFit.cover,
              errorBuilder: (_, _, _) => const Center(
                child: Icon(Icons.photo, size: 64),
              ),
            )
          else
            const Center(child: Icon(Icons.photo, size: 64)),
          // Logo badge, upper-left, always.
          Positioned(
            top: 12,
            left: 12,
            child: Image.asset(
              'assets/cast-trigger-logo.webp',
              height: 56,
              errorBuilder: (_, _, _) => const SizedBox.shrink(),
            ),
          ),
          if (_placement == CardPlacement.top)
            Positioned(
              top: 12,
              right: 12,
              left: 120,
              child: _infoPanel(slim: true),
            )
          else
            Positioned(
              left: 12,
              right: 12,
              bottom: 12,
              child: _infoPanel(
                slim: _placement == CardPlacement.slimBottom,
              ),
            ),
        ],
      ),
    );
  }

  Future<void> _share() async {
    if (_sharing) return;
    setState(() => _sharing = true);
    try {
      final boundary = _cardKey.currentContext?.findRenderObject()
          as RenderRepaintBoundary?;
      if (boundary == null) throw Exception('Card not rendered');
      final image = await boundary.toImage(pixelRatio: 2);
      final byteData =
          await image.toByteData(format: ui.ImageByteFormat.png);
      if (byteData == null) throw Exception('Card render failed');
      final bytes = byteData.buffer.asUint8List();
      final dir = await getTemporaryDirectory();
      final path =
          '${dir.path}/ct_share_card_${widget.log.id}.png';
      await File(path).writeAsBytes(bytes, flush: true);
      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(path)],
          text:
              '${widget.log.species} · ${widget.log.place}, '
              '${widget.log.county} County — Cast & Trigger',
        ),
      );
    } catch (_) {
      // Download fallback: save the card text summary and tell the
      // user — never silently fail a share.
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Could not open the share sheet. The card is still '
              'here to view and screenshot.',
            ),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _sharing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Share card')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            SegmentedButton<CardPlacement>(
              segments: const [
                ButtonSegment(
                  value: CardPlacement.bottom,
                  label: Text('Bottom'),
                ),
                ButtonSegment(
                  value: CardPlacement.top,
                  label: Text('Top'),
                ),
                ButtonSegment(
                  value: CardPlacement.slimBottom,
                  label: Text('Slim bottom'),
                ),
              ],
              selected: {_placement},
              onSelectionChanged: (v) =>
                  setState(() => _placement = v.first),
            ),
            const SizedBox(height: 16),
            RepaintBoundary(key: _cardKey, child: _card()),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _share,
                icon: const Icon(Icons.share),
                label: Text(_sharing ? 'Sharing…' : 'Share photo'),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Location shows water/county only, never GPS. '
              'Sharing this card does not make the log public.',
              style: TextStyle(fontStyle: FontStyle.italic),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
