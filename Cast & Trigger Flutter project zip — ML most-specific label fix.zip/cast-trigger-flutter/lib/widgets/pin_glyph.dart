import 'package:flutter/material.dart';

/// Prototype pins, exactly as in the prototype
/// (`cast-trigger-app-prototype.html`).
///
/// Prototype `.pin` (CSS lines ~214, 247-256):
///   width/height 26px, border-radius 50% (a CIRCLE, no tip),
///   background moss `var(--moss)` (#8fae6b in the prototype;
///   the Flutter app theme's moss #6B8F5E is used here, per the
///   app's colour scheme), color #101408 (dark), border 2px solid
///   bone-white #ece5d1, box-shadow 0 3px 10px rgba(0,0,0,.55).
///   `.pin--bone`: background #171912, color bone-white #ece5d1,
///   border-color bone-white.
///   `.bone-pin svg`: 16px x 16px inside the 26px circle.
///   `.pin-dot` (log-card dot): 20px circle, 1.5px border,
///   `.bone-pin svg` 12px x 12px inside it.
///
/// Bone glyphs are the prototype's `PIN_BONE_SVGS` (lines
/// ~4872-4880), transcribed path-for-path into a CustomPainter
/// (same 24x24 viewBox, same stroke widths: fish 1.7, deer 1.6,
/// bird 1.7, squirrel 1.6, predator 1.6, round caps/joins):
/// fish skeleton, deer skull + antlers, bird skull + beak,
/// squirrel skull + buck teeth, predator skull + snout.
/// Unknown species: the prototype's `pinBoneSymbolForKey` returns
/// a plain bone '🦴' — here that is a plain bone *drawing*
/// (shaft with a knob at each end), not an emoji.
///
/// Scout pins use the same circle in the prototype's `.pin`
/// style: moss background, dark (#101408) glyph — the prototype's
/// live pins are the `PIN_SYMBOLS` animals (🦌🦃🐿️🐦🕊️🐺🦊🐆🐟🐾)
/// in dark text on moss. The Flutter live glyphs are filled
/// silhouettes of the same family in dark ink on moss, so a Scout
/// pin never looks like a skeleton.
///
/// The family follows the species automatically; there is no
/// pin-style toggle. The same widget is used in the log card
/// (size 20, glyph 12) and on the map (size 26, glyph 16), so
/// card and map always match. Because the pin is a circle with
/// no tip, the map marker must be aligned CENTRE on the
/// coordinates (Alignment.center), not bottomCenter.
enum PinFamily { fish, deer, bird, squirrel, predator, unknown }

PinFamily pinFamilyForSpecies(String species, bool isFish) {
  if (isFish) return PinFamily.fish;
  if (species == 'Whitetail Deer') return PinFamily.deer;
  if (species == 'Wild Turkey' ||
      species == 'Ruffed Grouse' ||
      species == 'Northern Bobwhite Quail' ||
      species == 'Mourning Dove' ||
      species == 'American Woodcock') {
    return PinFamily.bird;
  }
  if (species.contains('Squirrel')) return PinFamily.squirrel;
  if (species == 'Coyote' ||
      species.contains('Fox') ||
      species == 'Bobcat') {
    return PinFamily.predator;
  }
  return PinFamily.unknown;
}

/// A prototype pin: a circle, 26px on the map (glyph 16px) and
/// 20px in a log card (glyph 12px). Bone = dark #171912 circle
/// with a bone-white skeleton glyph. Scout = moss circle with a
/// dark live-animal glyph.
class PinMarker extends StatelessWidget {
  const PinMarker({
    super.key,
    required this.family,
    required this.isBone,
    this.size = 26,
  });

  final PinFamily family;
  final bool isBone;

  /// Circle diameter in logical pixels: 26 on the map,
  /// 20 in a log card (prototype `.pin` / `.pin-dot`).
  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _PinPainter(family: family, isBone: isBone),
      ),
    );
  }
}

class _PinPainter extends CustomPainter {
  _PinPainter({required this.family, required this.isBone});

  final PinFamily family;
  final bool isBone;

  // Prototype colours: --bone #ece5d1, .pin--bone #171912,
  // .pin color #101408, app moss #6B8F5E.
  static const Color boneWhite = Color(0xFFECE5D1);
  static const Color boneDark = Color(0xFF171912);
  static const Color moss = Color(0xFF6B8F5E);
  static const Color darkInk = Color(0xFF101408);

  @override
  void paint(Canvas canvas, Size size) {
    // Prototype .pin: 26px circle, 2px bone-white border.
    // Prototype .pin-dot: 20px circle, 1.5px border.
    final borderWidth = size.width >= 26 ? 2.0 : 1.5;
    final radius = size.width / 2 - borderWidth / 2;
    final center = Offset(size.width / 2, size.height / 2);
    // Soft shadow, as in the prototype (0 3px 10px rgba(0,0,0,.55)).
    canvas.drawCircle(
      center + const Offset(0, 1.5),
      radius,
      Paint()
        ..color = Colors.black.withOpacity(0.55)
        ..style = PaintingStyle.fill
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3),
    );
    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..color = isBone ? boneDark : moss
        ..style = PaintingStyle.fill,
    );
    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..color = boneWhite
        ..style = PaintingStyle.stroke
        ..strokeWidth = borderWidth,
    );
    // Glyph: 16px inside the 26px circle, 12px inside the 20px
    // dot (prototype .bone-pin svg sizes), i.e. glyph = size*16/26.
    final glyphSize = size.width * 16 / 26;
    final scale = glyphSize / 24;
    canvas.save();
    canvas.translate(
      center.dx - glyphSize / 2,
      center.dy - glyphSize / 2,
    );
    canvas.scale(scale, scale);
    if (isBone) {
      _paintBone(canvas, family);
    } else {
      _paintLive(canvas, family);
    }
    canvas.restore();
  }

  // ---- Bone drawings: stroke, bone-white, transcribed
  // path-for-path from the prototype's PIN_BONE_SVGS
  // (24x24 viewBox, round caps/joins). Stroke widths are the
  // prototype's own per family: fish 1.7, deer 1.6, bird 1.7,
  // squirrel 1.6, predator 1.6. ----
  void _paintBone(Canvas canvas, PinFamily family) {
    final strokeWidth = switch (family) {
      PinFamily.fish => 1.7,
      PinFamily.deer => 1.6,
      PinFamily.bird => 1.7,
      PinFamily.squirrel => 1.6,
      PinFamily.predator => 1.6,
      PinFamily.unknown => 1.7,
    };
    final stroke = Paint()
      ..color = boneWhite
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final fill = Paint()
      ..color = boneWhite
      ..style = PaintingStyle.fill;
    switch (family) {
      case PinFamily.fish:
        // Fish skeleton: head, spine, ribs, tail fork.
        // Prototype: M2.6 12c0-2.3 1.8-4 4.2-4l1.7 2v4l-1.7 2
        // c-2.4 0-4.2-1.7-4.2-4Z
        final head = Path()
          ..moveTo(2.6, 12)
          ..cubicTo(2.6, 9.7, 4.4, 8, 6.8, 8)
          ..lineTo(8.5, 10)
          ..lineTo(8.5, 14)
          ..lineTo(6.8, 16)
          ..cubicTo(4.4, 16, 2.6, 14.3, 2.6, 12)
          ..close();
        canvas.drawPath(head, stroke);
        canvas.drawCircle(const Offset(5.4, 11), 0.9, fill);
        canvas.drawLine(const Offset(8.5, 12), const Offset(19.1, 12), stroke);
        // Ribs, prototype: M11 12l-1-3.1, M14 12l-1-3.1,
        // M16.8 12l-.8-2.5 (and the same downwards).
        for (final x in [11.0, 14.0]) {
          canvas.drawLine(Offset(x, 12), Offset(x - 1, 8.9), stroke);
          canvas.drawLine(Offset(x, 12), Offset(x - 1, 15.1), stroke);
        }
        canvas.drawLine(const Offset(16.8, 12), const Offset(16.0, 9.5), stroke);
        canvas.drawLine(const Offset(16.8, 12), const Offset(16.0, 14.5), stroke);
        canvas.drawLine(const Offset(19.1, 12), const Offset(21.7, 8.9), stroke);
        canvas.drawLine(const Offset(19.1, 12), const Offset(21.7, 15.1), stroke);
      case PinFamily.deer:
        // Deer skull + antlers.
        // Prototype: M8.6 8.2C6.7 6.8 5.7 4.9 6 2.7
        // M6.9 5.4c-1.1-.4-2.1-.3-2.9.4
        // M8.6 8.2c.4-2 1.3-3.3 2.5-4 (and mirrored right).
        final antlers = Path()
          ..moveTo(8.6, 8.2)
          ..cubicTo(6.7, 6.8, 5.7, 4.9, 6.0, 2.7)
          ..moveTo(6.9, 5.4)
          ..cubicTo(5.8, 5.0, 4.8, 5.1, 4.0, 5.8)
          ..moveTo(8.6, 8.2)
          ..cubicTo(9.0, 6.2, 9.9, 4.9, 11.1, 4.2)
          ..moveTo(15.4, 8.2)
          ..cubicTo(17.3, 6.8, 18.3, 4.9, 18.0, 2.7)
          ..moveTo(17.1, 5.4)
          ..cubicTo(18.2, 5.0, 19.2, 5.1, 20.0, 5.8)
          ..moveTo(15.4, 8.2)
          ..cubicTo(15.0, 6.2, 14.1, 4.9, 12.9, 4.2);
        canvas.drawPath(antlers, stroke);
        final skull = Path()
          ..moveTo(8.9, 7.6)
          ..lineTo(15.1, 7.6)
          ..lineTo(14.2, 13.4)
          ..lineTo(13.1, 19.3)
          ..lineTo(10.9, 19.3)
          ..lineTo(9.8, 13.4)
          ..close();
        canvas.drawPath(skull, stroke);
        canvas.drawCircle(const Offset(10.7, 11), 1, fill);
        canvas.drawCircle(const Offset(13.3, 11), 1, fill);
        canvas.drawLine(const Offset(11, 16.6), const Offset(13, 16.6), stroke);
      case PinFamily.bird:
        // Bird skull: round head, beak, leg.
        // Prototype: circle cx8.8 cy9.2 r4.4; M12.4 7.2 21 10
        // l-8.4 2.2; M12.9 12.9l5.2-.9; M7.2 13.2 5.6 17;
        // M5.6 17l-1.8 2.4; M5.6 17h3.
        canvas.drawCircle(const Offset(8.8, 9.2), 4.4, stroke);
        canvas.drawCircle(const Offset(7.8, 8.4), 1, fill);
        final beak = Path()
          ..moveTo(12.4, 7.2)
          ..lineTo(21, 10)
          ..lineTo(12.6, 12.2);
        canvas.drawPath(beak, stroke);
        canvas.drawLine(const Offset(12.9, 12.9), const Offset(18.1, 12), stroke);
        canvas.drawLine(const Offset(7.2, 13.2), const Offset(5.6, 17), stroke);
        canvas.drawLine(const Offset(5.6, 17), const Offset(3.8, 19.4), stroke);
        canvas.drawLine(const Offset(5.6, 17), const Offset(8.6, 17), stroke);
      case PinFamily.squirrel:
        // Squirrel skull: ears, round head, buck teeth.
        // Prototype: M8.7 6.2 8 3.6; M15.3 6.2 16 3.6;
        // circle cx12 cy10.2 r5; M10.6 14.6v3.8h2.8v-3.8
        // M12 14.6v3.8.
        canvas.drawLine(const Offset(8.7, 6.2), const Offset(8, 3.6), stroke);
        canvas.drawLine(const Offset(15.3, 6.2), const Offset(16, 3.6), stroke);
        canvas.drawCircle(const Offset(12, 10.2), 5, stroke);
        canvas.drawCircle(const Offset(10, 9.6), 1.1, fill);
        canvas.drawCircle(const Offset(14, 9.6), 1.1, fill);
        final teeth = Path()
          ..moveTo(10.6, 14.6)
          ..lineTo(10.6, 18.4)
          ..lineTo(13.4, 18.4)
          ..lineTo(13.4, 14.6)
          ..moveTo(12, 14.6)
          ..lineTo(12, 18.4);
        canvas.drawPath(teeth, stroke);
      case PinFamily.predator:
        // Predator skull: pointed ear, round head, snout.
        // Prototype: M6.2 6.8 7.2 3.6l2.4 2; circle cx8.6
        // cy10 r4.3; M12.2 8.4 19.4 10.4v2.8l-6.9.6;
        // M16.4 13.2l-.7 2.6-1-2.4.
        final ear = Path()
          ..moveTo(6.2, 6.8)
          ..lineTo(7.2, 3.6)
          ..lineTo(9.6, 5.6);
        canvas.drawPath(ear, stroke);
        canvas.drawCircle(const Offset(8.6, 10), 4.3, stroke);
        canvas.drawCircle(const Offset(7.6, 9.2), 1, fill);
        final snout = Path()
          ..moveTo(12.2, 8.4)
          ..lineTo(19.4, 10.4)
          ..lineTo(19.4, 13.2)
          ..lineTo(12.5, 13.8);
        canvas.drawPath(snout, stroke);
        canvas.drawLine(const Offset(16.4, 13.2), const Offset(15.7, 15.8), stroke);
        canvas.drawLine(const Offset(15.7, 15.8), const Offset(14.7, 13.4), stroke);
      case PinFamily.unknown:
        // Plain bone drawing (prototype pinBoneSymbolForKey
        // returns a plain bone '🦴' for an unknown species):
        // shaft with a knob at each end.
        canvas.drawLine(const Offset(7, 12), const Offset(17, 12), stroke);
        canvas.drawCircle(const Offset(6, 10.5), 1.6, fill);
        canvas.drawCircle(const Offset(6, 13.5), 1.6, fill);
        canvas.drawCircle(const Offset(18, 10.5), 1.6, fill);
        canvas.drawCircle(const Offset(18, 13.5), 1.6, fill);
    }
  }

  // ---- Live drawings: filled silhouette of the same family,
  // in dark ink (#101408, the prototype .pin color) on the moss
  // pin, so a Scout pin never looks like a skeleton. Eye
  // cut-outs are painted in the moss background colour. ----
  void _paintLive(Canvas canvas, PinFamily family) {
    final fill = Paint()
      ..color = darkInk
      ..style = PaintingStyle.fill;
    final stroke = Paint()
      ..color = darkInk
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.7
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final cutout = Paint()
      ..color = moss
      ..style = PaintingStyle.fill;
    switch (family) {
      case PinFamily.fish:
        final body = Path()
          ..moveTo(3, 12)
          ..cubicTo(3, 8.5, 6, 7, 10, 7)
          ..lineTo(16, 7)
          ..lineTo(19, 12)
          ..lineTo(16, 17)
          ..lineTo(10, 17)
          ..cubicTo(6, 17, 3, 15.5, 3, 12)
          ..close();
        canvas.drawPath(body, fill);
        final tail = Path()
          ..moveTo(19, 12)
          ..lineTo(22.5, 8.5)
          ..lineTo(22.5, 15.5)
          ..close();
        canvas.drawPath(tail, fill);
        canvas.drawCircle(const Offset(6.5, 11), 1, cutout);
      case PinFamily.deer:
        // Filled skull + stroked antlers (same antler paths as bone).
        final skull = Path()
          ..moveTo(8.9, 7.6)
          ..lineTo(15.1, 7.6)
          ..lineTo(14.2, 13.4)
          ..lineTo(13.1, 19.3)
          ..lineTo(10.9, 19.3)
          ..lineTo(9.8, 13.4)
          ..close();
        canvas.drawPath(skull, fill);
        canvas.drawLine(const Offset(8.6, 8.2), const Offset(6, 2.7), stroke);
        canvas.drawLine(const Offset(8.6, 8.2), const Offset(11.1, 4.2), stroke);
        canvas.drawLine(const Offset(15.4, 8.2), const Offset(18, 2.7), stroke);
        canvas.drawLine(const Offset(15.4, 8.2), const Offset(12.9, 4.2), stroke);
        canvas.drawCircle(const Offset(10.7, 11), 1, cutout);
        canvas.drawCircle(const Offset(13.3, 11), 1, cutout);
      case PinFamily.bird:
        canvas.drawCircle(const Offset(9, 10), 5.5, fill);
        final beak = Path()
          ..moveTo(13.5, 8)
          ..lineTo(21, 10.5)
          ..lineTo(13.5, 13)
          ..close();
        canvas.drawPath(beak, fill);
        canvas.drawCircle(const Offset(7.5, 9), 1, cutout);
      case PinFamily.squirrel:
        canvas.drawCircle(const Offset(12, 11), 5.5, fill);
        final earL = Path()
          ..moveTo(8.5, 7)
          ..lineTo(7.5, 3.5)
          ..lineTo(10.5, 6)
          ..close();
        final earR = Path()
          ..moveTo(15.5, 7)
          ..lineTo(16.5, 3.5)
          ..lineTo(13.5, 6)
          ..close();
        canvas.drawPath(earL, fill);
        canvas.drawPath(earR, fill);
        canvas.drawCircle(const Offset(10, 10.5), 1, cutout);
        canvas.drawCircle(const Offset(14, 10.5), 1, cutout);
        // Bushy tail, stroked.
        final tail = Path()
          ..moveTo(17, 13)
          ..cubicTo(21, 12, 21.5, 7, 18.5, 5.5);
        canvas.drawPath(tail, stroke);
      case PinFamily.predator:
        canvas.drawCircle(const Offset(11, 11), 5.5, fill);
        final earL = Path()
          ..moveTo(7, 7.5)
          ..lineTo(6, 3.5)
          ..lineTo(9.5, 5.5)
          ..close();
        final earR = Path()
          ..moveTo(15, 7.5)
          ..lineTo(16, 3.5)
          ..lineTo(12.5, 5.5)
          ..close();
        canvas.drawPath(earL, fill);
        canvas.drawPath(earR, fill);
        final snout = Path()
          ..moveTo(14, 9)
          ..lineTo(20, 11)
          ..lineTo(14, 14.5)
          ..close();
        canvas.drawPath(snout, fill);
        canvas.drawCircle(const Offset(9, 10), 1, cutout);
      case PinFamily.unknown:
        // Paw print (prototype Scout pin for no animal: '🐾').
        canvas.drawCircle(const Offset(12, 14), 3.2, fill);
        canvas.drawCircle(const Offset(8, 9), 1.6, fill);
        canvas.drawCircle(const Offset(12, 8), 1.6, fill);
        canvas.drawCircle(const Offset(16, 9), 1.6, fill);
    }
  }

  @override
  bool shouldRepaint(covariant _PinPainter old) =>
      old.family != family || old.isBone != isBone;
}
