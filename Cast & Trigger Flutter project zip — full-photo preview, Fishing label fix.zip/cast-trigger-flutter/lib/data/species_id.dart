/// Automatic species suggestion from a photo — SUGGESTION ONLY.
///
/// Uses Google ML Kit's bundled base image-labeling model
/// (`google_mlkit_image_labeling`, base model). No model file is
/// bundled in this repo and none is downloaded: the model ships
/// inside the ML Kit SDK itself. That is deliberate: a bundled
/// TFLite model would need a 1001-label file in exact ImageNet
/// order plus a minSdk bump, and a wrong label order silently
/// mislabels every photo. ML Kit returns label strings, so the
/// mapping below works on the label text itself.
///
/// HONEST LIMITS — read before trusting this file:
/// - ML Kit's base model labels are BROAD categories, not a
///   WV species classifier. It can say "fish", "trout", "deer",
///   "fox" — it cannot reliably tell a Largemouth Bass from a
///   Smallmouth Bass, or a Rainbow Trout from a Brown Trout.
///   Where the model only supports a category, this service
///   returns that category (with candidate species for the user
///   to pick) and NEVER invents a precise species.
/// - MOST-SPECIFIC MATCH (2026-11-05): ML Kit usually returns
///   several labels at once (e.g. "fish" 92% + "trout" 68%).
///   _mapLabels now scans ALL surviving labels and returns the
///   MOST SPECIFIC match, not the first (highest-confidence)
///   one — exact species > specific category (trout, bass,
///   catfish, grouse, …) > generic category ("fish", "bird").
///   A single-candidate category (grouse, quail, dove,
///   woodcock) counts as exact, since there is only one
///   possible species in it. This fix can only surface
///   specificity the model actually returned: if the only
///   surviving label really is just "fish" or "bird", the
///   result stays that generic category and the user picks
///   the exact species manually. A custom trained WV species
///   model would be needed to distinguish species the base
///   model never labels (e.g. Largemouth vs Smallmouth).
/// - The result is a suggestion only. It is never a legal species
///   ID, never a bag-limit or season verdict, and the user always
///   confirms the species in the Spots dialog before saving.
/// - No AI bite predictions, ever. This only labels what is in
///   a photo the user already took.
///
/// Confidence / guard rules (mirroring the prototype's MobileNet
/// rules: >=25% confidence, and >= half the top label's confidence):
/// - Labels below 0.25, or below half the top label's confidence,
///   are discarded before mapping — EXCEPT the low-tier rule
///   below (2026-11-05): a label >=0.25 but below half the top
///   is still considered, but ONLY for a rank-2 specific
///   category (trout, bass, catfish, …) and ONLY when the
///   higher-confidence labels gave nothing better than a generic
///   rank-1 category. See _mapLabels for the false-positive
///   reasoning: a low-tier match can only NARROW the dropdown
///   to that category, never auto-fill a species, and the user
///   can Dismiss back to the full list — so the worst case is
///   one extra tap, not a wrong species saved.
/// - ACTIVITY LABELS (2026-11-05): the model often returns an
///   activity, not an animal — "Fishing" 96% for a bass photo.
///   "Fishing" must NOT match the 'fish' category by substring
///   ("fishing" contains "fish"). Matching is now word-boundary
///   based (see _matches), and activity words ("fishing",
///   "angling", "hunting") are rank-1 generic evidence only:
///   they say fish/game, never a species, and never block a
///   more specific label underneath.
/// - NON-GAME GUARD (the dog-as-bass regression test): if the
///   TOP surviving label is a non-game subject (dog, cat, person,
///   horse, vehicle, food, …), the result is non-game, even if a
///   lower label mentions a fish or animal. A dog photo must
///   never be labelled Largemouth Bass (or any game species).
///   The guard is checked on the TOP label overall, before any
///   low-tier label is considered, so loosening the guard for
///   specificity can never let a low "bass" label override a
///   top "dog" label.
/// - If no surviving label maps to a game category, the result
///   is "unidentified" — the UI falls back to manual entry.
///   Identification failure never blocks saving a log manually.
library;

import 'package:google_mlkit_image_labeling/google_mlkit_image_labeling.dart';

/// The outcome of one photo-identification attempt.
class SpeciesSuggestion {
  const SpeciesSuggestion({
    required this.kind,
    required this.rawLabel,
    required this.confidence,
    this.suggestedSpecies,
    this.candidateSpecies = const [],
  });

  /// 'fish' | 'game' | 'nonGame' | 'unidentified'
  final String kind;

  /// The ML Kit label that produced this result, e.g. "Trout".
  final String rawLabel;

  /// Confidence of that label, 0.0–1.0.
  final double confidence;

  /// An exact app species, only when the label supports one
  /// (e.g. "Whitetail Deer"). Null for category-only results.
  final String? suggestedSpecies;

  /// Exact species the user may pick from, for category-only
  /// results (e.g. the four trouts). Empty for exact results.
  final List<String> candidateSpecies;

  bool get isGame => kind == 'fish' || kind == 'game';
  bool get isFish => kind == 'fish';
  bool get isNonGame => kind == 'nonGame';
  bool get isUnidentified => kind == 'unidentified';
  bool get hasExactSpecies => suggestedSpecies != null;

  String get confidencePct => '${(confidence * 100).round()}%';
}

/// On-device photo species suggestion. One-shot: create, run, close.
class SpeciesIdService {
  /// Labels that are never game species in this app, even if the
  /// photo also contains something animal-like. Checked against
  /// the TOP surviving label (see the guard rule above).
  static const List<String> _nonGameKeywords = [
    'dog', 'puppy', 'cat', 'kitten', 'person', 'people', 'human',
    'man', 'woman', 'child', 'face', 'horse', 'cow', 'pig', 'sheep',
    'goat', 'rabbit', 'hare', 'bear', 'vehicle', 'car', 'boat',
    'food', 'furniture', 'building', 'plant', 'flower', 'tree',
  ];

  /// Exact-label mapping: keyword -> app species name.
  /// Only entries the base model can plausibly return as a label.
  static const Map<String, String> _exactSpecies = {
    'whitetail deer': 'Whitetail Deer',
    'deer': 'Whitetail Deer',
    'wild turkey': 'Wild Turkey',
    'turkey': 'Wild Turkey',
    'coyote': 'Coyote',
    'red fox': 'Red Fox',
    'gray fox': 'Gray Fox',
    'grey fox': 'Gray Fox',
    'bobcat': 'Bobcat',
    'lynx': 'Bobcat',
    'common carp': 'Common Carp',
    'carp': 'Common Carp',
    'yellow perch': 'Yellow Perch',
    'perch': 'Yellow Perch',
    'chain pickerel': 'Chain Pickerel',
    'pickerel': 'Chain Pickerel',
    'freshwater drum': 'Freshwater Drum',
    'drum': 'Freshwater Drum',
  };

  /// Category mapping: keyword -> (kind, candidate species).
  /// Used when the label supports a group, not one species.
  static const Map<String, _Category> _categories = {
    'trout': _Category('fish', [
      'Rainbow Trout',
      'Brown Trout',
      'Brook Trout',
      'Golden Rainbow Trout',
    ]),
    'bass': _Category('fish', [
      'Largemouth Bass',
      'Smallmouth Bass',
      'Spotted Bass',
    ]),
    'catfish': _Category('fish', [
      'Channel Catfish',
      'Flathead Catfish',
      'Blue Catfish',
    ]),
    'crappie': _Category('fish', ['Black Crappie', 'White Crappie']),
    'sunfish': _Category('fish', [
      'Bluegill',
      'Redear Sunfish',
      'Redbreast Sunfish',
      'Green Sunfish',
    ]),
    'bluegill': _Category('fish', [
      'Bluegill',
      'Redear Sunfish',
      'Redbreast Sunfish',
      'Green Sunfish',
    ]),
    'walleye': _Category('fish', ['Walleye', 'Saugeye', 'Sauger']),
    'sauger': _Category('fish', ['Walleye', 'Saugeye', 'Sauger']),
    'saugeye': _Category('fish', ['Walleye', 'Saugeye', 'Sauger']),
    'fish': _Category('fish', []),
    'squirrel': _Category('game', ['Gray Squirrel', 'Fox Squirrel']),
    'fox': _Category('game', ['Red Fox', 'Gray Fox']),
    'grouse': _Category('game', ['Ruffed Grouse']),
    'quail': _Category('game', ['Northern Bobwhite Quail']),
    'dove': _Category('game', ['Mourning Dove']),
    'woodcock': _Category('game', ['American Woodcock']),
    'bird': _Category('game', [
      'Wild Turkey',
      'Ruffed Grouse',
      'Northern Bobwhite Quail',
      'Mourning Dove',
      'American Woodcock',
    ]),
  };

  /// Activity labels the base model returns instead of an
  /// animal — "Fishing" for a bass photo, "Hunting" for a
  /// deer photo. Rank-1 generic evidence only (kind, no
  /// candidates): they prove fish/game, never a species.
  /// Kept separate from _categories so "fishing" can never
  /// match the 'fish' category by substring.
  static const Map<String, String> _activityKinds = {
    'fishing': 'fish',
    'angling': 'fish',
    'hunting': 'game',
  };

  /// Keyword matching with word boundaries. Single-word keys
  /// must match a whole word: "fishing" does NOT match 'fish',
  /// "dogfish" does NOT match 'dog' here (the non-game guard
  /// keeps its own substring check on the top label). Multi-word
  /// keys ("red fox", "freshwater drum") match as a phrase.
  static bool _matches(String text, String key) {
    if (key.contains(' ')) return text.contains(key);
    return RegExp('\\b${RegExp.escape(key)}\\b').hasMatch(text);
  }

  /// Identify a photo at [photoPath]. Never throws: any failure
  /// (no model, plugin error, timeout) returns an unidentified
  /// result so the UI can fall back to manual entry.
  static Future<SpeciesSuggestion> identify(String photoPath) async {
    try {
      final labeler = ImageLabeler(
        options: ImageLabelerOptions(confidenceThreshold: 0.25),
      );
      try {
        final inputImage = InputImage.fromFilePath(photoPath);
        final labels = await labeler
            .processImage(inputImage)
            .timeout(const Duration(seconds: 20));
        return _mapLabels(labels);
      } finally {
        // close() is fire-and-forget in this plugin's API (the
        // docs show it un-awaited); do not await a void return.
        labeler.close();
      }
    } catch (_) {
      return const SpeciesSuggestion(
        kind: 'unidentified',
        rawLabel: '',
        confidence: 0,
      );
    }
  }

  /// Apply the confidence + guard rules to ML Kit's labels.
  /// Exposed for testing the mapping without a photo.
  static SpeciesSuggestion mapLabelsForTest(
    List<({String label, double confidence})> labels,
  ) {
    return _mapLabels(
      labels
          .map((l) => _Label(l.label, l.confidence))
          .toList(growable: false),
    );
  }

  static SpeciesSuggestion _mapLabels(List<dynamic> labels) {
    if (labels.isEmpty) {
      return const SpeciesSuggestion(
        kind: 'unidentified',
        rawLabel: '',
        confidence: 0,
      );
    }
    // Sort by confidence descending; the plugin returns labels in
    // arbitrary order, so never trust labels.first as the top.
    final sorted = [...labels]
      ..sort((a, b) => _confidence(b).compareTo(_confidence(a)));
    final top = _confidence(sorted.first);
    if (top < 0.25) {
      return const SpeciesSuggestion(
        kind: 'unidentified',
        rawLabel: '',
        confidence: 0,
      );
    }
    // Keep only labels >=25% AND >= half the top label's confidence.
    final surviving = sorted
        .where((l) => _confidence(l) >= 0.25 && _confidence(l) >= top * 0.5)
        .toList(growable: false);
    if (surviving.isEmpty) {
      return const SpeciesSuggestion(
        kind: 'unidentified',
        rawLabel: '',
        confidence: 0,
      );
    }
    final topLabel = _label(surviving.first).toLowerCase();
    // NON-GAME GUARD: top surviving label is not game -> non-game,
    // no matter what lower labels say. This is the dog-as-bass
    // regression test: a dog photo's top label is a dog/breed.
    if (_nonGameKeywords.any((k) => topLabel.contains(k))) {
      return SpeciesSuggestion(
        kind: 'nonGame',
        rawLabel: _label(surviving.first),
        confidence: _confidence(surviving.first),
      );
    }
    // Game mapping: MOST SPECIFIC match among ALL surviving
    // labels, not the first match in confidence order. The old
    // code returned on the first category match, so "fish" 92%
    // + "trout" 68% returned plain "fish" and never looked at
    // the more specific "trout" label — that is why George
    // only ever saw "fish" or "bird".
    //
    // Specificity rank: 3 = exact species (including a
    // single-candidate category, e.g. grouse -> Ruffed Grouse,
    // which has only one possible species); 2 = specific
    // category (trout, bass, catfish, crappie, sunfish, walleye,
    // squirrel, fox); 1 = generic category ("fish", "bird").
    // Higher rank always wins, regardless of confidence (every
    // surviving label is already >= half the top confidence).
    // Within the same rank, highest confidence wins.
    SpeciesSuggestion? best;
    var bestRank = 0;
    var bestConfidence = -1.0;
    for (final label in surviving) {
      final text = _label(label).toLowerCase();
      final confidence = _confidence(label);
      // Exact species — rank 3.
      for (final entry in _exactSpecies.entries) {
        if (_matches(text, entry.key)) {
          if (3 > bestRank || (3 == bestRank && confidence > bestConfidence)) {
            bestRank = 3;
            bestConfidence = confidence;
            best = SpeciesSuggestion(
              kind: _kindForSpecies(entry.value),
              rawLabel: _label(label),
              confidence: confidence,
              suggestedSpecies: entry.value,
            );
          }
          break;
        }
      }
      // Categories — rank 2 (specific) or 1 (generic).
      // Word-boundary matching: "fishing" does NOT match 'fish'
      // and "sunfish" does NOT match 'fish' — only the whole
      // word "fish" does.
      for (final entry in _categories.entries) {
        if (!_matches(text, entry.key)) continue;
        final isGeneric = entry.key == 'fish' || entry.key == 'bird';
        // A single-candidate category is exact: there is only
        // one possible species, so it auto-fills like an exact
        // result (grouse -> Ruffed Grouse, quail -> Northern
        // Bobwhite Quail, dove -> Mourning Dove, woodcock ->
        // American Woodcock).
        final isSingleCandidate = entry.value.species.length == 1;
        final rank = isSingleCandidate ? 3 : (isGeneric ? 1 : 2);
        if (rank > bestRank || (rank == bestRank && confidence > bestConfidence)) {
          bestRank = rank;
          bestConfidence = confidence;
          best = isSingleCandidate
              ? SpeciesSuggestion(
                  kind: entry.value.kind,
                  rawLabel: _label(label),
                  confidence: confidence,
                  suggestedSpecies: entry.value.species.first,
                )
              : SpeciesSuggestion(
                  kind: entry.value.kind,
                  rawLabel: _label(label),
                  confidence: confidence,
                  candidateSpecies: entry.value.species,
                );
        }
        break;
      }
      // Activity labels — rank 1 generic only ("fishing" /
      // "angling" -> fish, "hunting" -> game; no candidates).
      // They say what the photo is about, never a species, and
      // they never outrank a specific label from another label.
      for (final entry in _activityKinds.entries) {
        if (!_matches(text, entry.key)) continue;
        if (1 > bestRank) {
          bestRank = 1;
          bestConfidence = confidence;
          best = SpeciesSuggestion(
            kind: entry.value,
            rawLabel: _label(label),
            confidence: confidence,
            candidateSpecies: const [],
          );
        }
        break;
      }
    }
    // LOW-TIER SPECIFICITY (2026-11-05): labels >=0.25 but below
    // half the top confidence were previously discarded outright,
    // so "Fishing" 96% + "bass" 40% returned plain generic and
    // never saw the bass label. If the high-confidence labels
    // gave nothing better than generic (bestRank <= 1), scan
    // those low labels for a RANK-2 specific category ONLY
    // (trout, bass, catfish, crappie, sunfish, walleye,
    // squirrel, fox) and return the highest-confidence one.
    //
    // FALSE-POSITIVE RISK, weighed and accepted: a low-tier
    // label is weaker evidence (40% vs 96%), so it could be
    // wrong — e.g. a trout photo with a spurious 30% "bass"
    // label would narrow the dropdown to the 3 bass. That is
    // why low-tier matches NEVER auto-fill a species (no exact
    // / single-candidate matches from this tier, not even grouse)
    // and can only narrow the dropdown to a category. The user
    // still confirms the species, the card still says
    // "Suggestion only — not a legal ID", and Dismiss restores
    // the full list — so the worst case is one extra tap, not a
    // wrong species saved. The non-game guard above already ran
    // on the TOP label overall, so a low "bass" label can never
    // override a top "dog" label.
    if (best == null || bestRank <= 1) {
      final low = sorted
          .where((l) =>
              _confidence(l) >= 0.25 && _confidence(l) < top * 0.5)
          .toList(growable: false);
      SpeciesSuggestion? lowBest;
      var lowConfidence = -1.0;
      for (final label in low) {
        final text = _label(label).toLowerCase();
        final confidence = _confidence(label);
        for (final entry in _categories.entries) {
          if (!_matches(text, entry.key)) continue;
          final isGeneric = entry.key == 'fish' || entry.key == 'bird';
          final isSingleCandidate = entry.value.species.length == 1;
          // Rank 2 only: generic and single-candidate (exact)
          // matches are excluded from the low tier.
          if (isGeneric || isSingleCandidate) break;
          if (confidence > lowConfidence) {
            lowConfidence = confidence;
            lowBest = SpeciesSuggestion(
              kind: entry.value.kind,
              rawLabel: _label(label),
              confidence: confidence,
              candidateSpecies: entry.value.species,
            );
          }
          break;
        }
      }
      if (lowBest != null) return lowBest;
    }
    if (best != null) return best;
    return SpeciesSuggestion(
      kind: 'unidentified',
      rawLabel: _label(surviving.first),
      confidence: _confidence(surviving.first),
    );
  }

  static String _kindForSpecies(String species) {
    return species.contains('Deer') ||
            species.contains('Turkey') ||
            species.contains('Squirrel') ||
            species.contains('Grouse') ||
            species.contains('Quail') ||
            species.contains('Dove') ||
            species.contains('Woodcock') ||
            species.contains('Coyote') ||
            species.contains('Fox') ||
            species.contains('Bobcat')
        ? 'game'
        : 'fish';
  }

  static String _label(dynamic label) {
    if (label is _Label) return label.text;
    try {
      return (label as dynamic).label as String;
    } catch (_) {
      return '';
    }
  }

  static double _confidence(dynamic label) {
    if (label is _Label) return label.confidence;
    try {
      return (label as dynamic).confidence as double;
    } catch (_) {
      return 0;
    }
  }
}

class _Category {
  const _Category(this.kind, this.species);
  final String kind;
  final List<String> species;
}

class _Label {
  const _Label(this.text, this.confidence);
  final String text;
  final double confidence;
}
