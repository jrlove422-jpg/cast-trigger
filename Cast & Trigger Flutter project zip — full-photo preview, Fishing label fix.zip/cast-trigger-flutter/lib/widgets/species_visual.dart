import 'dart:io';

import 'package:flutter/material.dart';

/// Shared species visual, reused by the Planner species card
/// (Fix #6) and the Planned Trips trip card (Fix #9).
///
/// Fish the prototype had test photos for show the bundled photo,
/// labelled "Sample photo" — the prototype itself reused only three
/// distinct photos across those 14 entries, so these are sample /
/// placeholder pictures, never a real catch photo. Every other
/// species shows its species icon instead. Manual / other entry
/// shows no visual, only the caller-supplied label.
const Map<String, String> speciesPhotoAssets = {
  'Largemouth Bass': 'assets/species/largemouth.jpg',
  'Smallmouth Bass': 'assets/species/smallmouth.jpg',
  'Rainbow Trout': 'assets/species/trout.jpg',
  'Brown Trout': 'assets/species/brown_trout.jpg',
  'Brook Trout': 'assets/species/brook_trout.jpg',
  'Golden Rainbow Trout': 'assets/species/golden_trout.jpg',
  'Muskellunge (Musky)': 'assets/species/musky.jpg',
  'Walleye': 'assets/species/walleye.jpg',
  'Saugeye': 'assets/species/saugeye.jpg',
  'Sauger': 'assets/species/sauger.jpg',
  'Yellow Perch': 'assets/species/yellow_perch.jpg',
  'Channel Catfish': 'assets/species/channel_catfish.jpg',
  'Flathead Catfish': 'assets/species/flathead_catfish.jpg',
  'Blue Catfish': 'assets/species/blue_catfish.jpg',
};

String speciesIcon(String species, bool isFish) {
  if (isFish) return '🐟';
  if (species == 'Whitetail Deer') return '🦌';
  if (species == 'Wild Turkey') return '🦃';
  if (species.contains('Squirrel')) return '🐿️';
  if (species.contains('Fox') || species == 'Coyote') return '🦊';
  return '🐾';
}

/// Photo (with "Sample photo" chip) or icon visual for [species].
/// [photoPath] is an optional real log/trip photo, which takes
/// precedence over the sample photo when it exists on disk.
class SpeciesVisual extends StatelessWidget {
  const SpeciesVisual({
    super.key,
    required this.species,
    required this.isFish,
    this.photoPath,
    this.height = 120,
  });

  final String species;
  final bool isFish;
  final String? photoPath;
  final double height;

  @override
  Widget build(BuildContext context) {
    final real = photoPath;
    if (real != null && File(real).existsSync()) {
      // Whole photo, no crop (was BoxFit.cover at height 120,
      // which cropped a portrait log photo on Planned Trips
      // cards the same way the Add-page preview did).
      // Dark container is the letterbox background.
      return Container(
        height: height,
        width: double.infinity,
        decoration: BoxDecoration(
          color: const Color(0xFF1E2429),
          borderRadius: BorderRadius.circular(8),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.file(
            File(real),
            fit: BoxFit.contain,
            errorBuilder: (context, error, stackTrace) =>
                _iconVisual(),
          ),
        ),
      );
    }
    final asset = speciesPhotoAssets[species];
    if (asset != null) {
      return Stack(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.asset(
              asset,
              height: height,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) =>
                  _iconVisual(),
            ),
          ),
          Positioned(
            right: 6,
            bottom: 6,
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 6,
                vertical: 2,
              ),
              decoration: BoxDecoration(
                color: Colors.black87,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text(
                'Sample photo',
                style: TextStyle(
                  fontSize: 11,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ),
          ),
        ],
      );
    }
    return _iconVisual();
  }

  Widget _iconVisual() {
    return Container(
      height: 80,
      width: double.infinity,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: const Color(0xFF1E2429),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        speciesIcon(species, isFish),
        style: const TextStyle(fontSize: 48),
      ),
    );
  }
}
