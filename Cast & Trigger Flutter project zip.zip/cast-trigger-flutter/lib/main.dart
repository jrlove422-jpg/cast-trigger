import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'data/disclaimer.dart';
import 'screens/disclaimer_gate.dart';
import 'screens/placeholder_screen.dart';
import 'screens/planner_screen.dart';
import 'widgets/state_pill.dart';

/// Cast & Trigger — Chunk 1: scaffold + Planner only.
///
/// Working name only — NOT cleared. No trademark filing, domain
/// purchase, LLC, or entity work is included here. Prototype seasons
/// and waters are SAMPLE data, not official WVDNR regulations.
/// No AI bite predictions, no parcel maps, no social feed.
/// Private by default, offline-first, local storage only in this chunk.
void main() {
  runApp(const CastTriggerApp());
}

class CastTriggerApp extends StatelessWidget {
  const CastTriggerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cast & Trigger',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF121417),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF6B8F5E), // moss green
          secondary: Color(0xFFD4AF37), // gold
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF6B8F5E),
            foregroundColor: Colors.white,
          ),
        ),
      ),
      home: const _GateOrShell(),
    );
  }
}

/// Shows the disclaimer gate on first open; the app shell after agreeing.
/// The agreement version + date/time are stored locally. The real app
/// must ALSO record the agreement server-side against the user account.
class _GateOrShell extends StatefulWidget {
  const _GateOrShell();

  @override
  State<_GateOrShell> createState() => _GateOrShellState();
}

class _GateOrShellState extends State<_GateOrShell> {
  String? _agreedAtIso;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadAgreement();
  }

  Future<void> _loadAgreement() async {
    final prefs = await SharedPreferences.getInstance();
    final version = prefs.getString('disclaimer_agreement_version');
    final agreedAt = prefs.getString('disclaimer_agreed_at');
    setState(() {
      // Only count an agreement saved under the current version.
      _agreedAtIso =
          (version == disclaimerVersion && agreedAt != null) ? agreedAt : null;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }
    if (_agreedAtIso == null) {
      return DisclaimerGateScreen(
        onAgreed: () {
          // Re-read the saved agreement so the Planner card shows it.
          _loadAgreement();
        },
      );
    }
    return _AppShell(agreedAtIso: _agreedAtIso);
  }
}

/// 5-tab shell, in the spec order:
/// Planner, Planned Trips, Spots, Stats, My License.
/// Chunk 1: Planner is fully built; the other four are placeholders
/// saying "Coming in a later chunk" so navigation works.
class _AppShell extends StatefulWidget {
  const _AppShell({required this.agreedAtIso});

  final String? agreedAtIso;

  @override
  State<_AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<_AppShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final screens = <Widget>[
      PlannerScreen(agreedAtIso: widget.agreedAtIso),
      const PlaceholderScreen(title: 'Planned Trips'),
      const PlaceholderScreen(title: 'Spots'),
      const PlaceholderScreen(title: 'Stats'),
      const PlaceholderScreen(title: 'My License'),
    ];
    const titles = [
      'Planner',
      'Planned Trips',
      'Spots',
      'Stats',
      'My License',
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('CAST & TRIGGER'),
        actions: const [StatePill()],
      ),
      body: IndexedStack(index: _index, children: screens),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        type: BottomNavigationBarType.fixed,
        onTap: (index) => setState(() => _index = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.map), label: 'Planner'),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today),
            label: 'Planned Trips',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.place), label: 'Spots'),
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: 'Stats',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.badge),
            label: 'My License',
          ),
        ],
      ),
    );
  }
}
