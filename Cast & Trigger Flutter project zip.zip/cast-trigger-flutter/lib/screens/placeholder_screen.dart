import 'package:flutter/material.dart';

/// Placeholder for a later chunk. Navigation works in Chunk 1; the
/// screen itself is intentionally not built yet.
/// Do not mistake this placeholder for a finished screen.
class PlaceholderScreen extends StatelessWidget {
  const PlaceholderScreen({super.key, required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'Coming in a later chunk.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
