import 'package:flutter/material.dart';

import '../data/disclaimer.dart';
import '../data/wv_data.dart';
import 'disclaimer_gate.dart';

/// Trip Planner — the only fully built screen in Chunk 1.
///
/// Rules that must not regress (see wv_data.dart and the brief):
/// 1. Fish/Hunt radio: Fish default, fish species only; Hunt shows
///    game species only. Switching restores the last-used species of
///    that kind and swaps the form (hunting area, weapon, pack list).
/// 2. Planner fish species list is ALWAYS the full 28 + manual entry.
///    Picking a fish narrows county/water to where it occurs.
///    A county or water change NEVER narrows or moves the species.
/// 3. Summersville Lake is ONLY in Nicholas County, never Mineral.
/// 4. Knife is on every pack list.
/// 5. Every season verdict is SAMPLE data, never official regulation.
class PlannerScreen extends StatefulWidget {
  const PlannerScreen({super.key, required this.agreedAtIso});

  /// ISO-8601 string saved by the disclaimer gate, or null.
  final String? agreedAtIso;

  @override
  State<PlannerScreen> createState() => _PlannerScreenState();
}

class _PlannerScreenState extends State<PlannerScreen> {
  static const String manualEntry = 'Manual / other entry';

  bool _isHunt = false;
  String _lastFish = 'Largemouth Bass';
  String _lastHunt = 'Whitetail Deer';
  String _species = 'Largemouth Bass';
  String _county = 'Kanawha';
  String _water = 'Kanawha River';
  final TextEditingController _huntingAreaController =
      TextEditingController();
  Weapon _weapon = Weapon.firearm;
  DateTime _tripDate = DateTime.now();
  bool _duskApplied = false;
  final Set<String> _checkedPack = {};

  @override
  void dispose() {
    _huntingAreaController.dispose();
    super.dispose();
  }

  bool get _isFish => !_isHunt;

  List<String> get _speciesOptions {
    final options = _isFish ? fishSpecies : gameSpecies;
    return [...options, manualEntry];
  }

  /// Counties available for the current pick. Hunting or manual entry
  /// restores all 55. A fish pick narrows to where it occurs.
  List<String> get _availableCounties {
    if (_isFish && _species != manualEntry) {
      return countiesForFish(_species);
    }
    return wvCounties;
  }

  String get _countNote {
    if (!_isFish) return '';
    final total = _availableCounties.length;
    return '$_species: $total of 55 counties';
  }

  List<String> get _availableWaters => watersForCounty(_county);

  List<String> get _packList {
    if (_isFish) {
      return const [
        'Rod & reel',
        'Tackle',
        'Knife',
        'Snacks & water',
        'First aid kit',
        'License in wallet',
      ];
    }
    final List<String> base;
    switch (_weapon) {
      case Weapon.bow:
        base = ['Bow', 'Arrows', 'Knife'];
        break;
      case Weapon.firearm:
        base = ['Firearm', 'Ammo', 'Knife'];
        break;
      case Weapon.muzzleloader:
        base = ['Muzzleloader', 'Powder & caps', 'Knife'];
        break;
    }
    final pack = [
      ...base,
      'Hunter orange',
      'Snacks & water',
      'First aid kit',
      'License in wallet',
    ];
    if (_species == 'Coyote') {
      // Red light + written landowner consent, per the coyote spec.
      // The consent item matters for Sept 1 – Dec 31 night hunting
      // on private land; it is shown year-round so it is never missed.
      pack.addAll(['Red light', 'Written landowner consent']);
    }
    return pack;
  }

  String get _motto => _isFish ? 'Cast that line' : 'Pull that trigger';

  String get _saveButtonText =>
      _isFish ? 'Cast that line — save trip' : 'Pull that trigger — save trip';

  /// Dusk rule (PLACEHOLDER calculation — do not claim a live sunset API
  /// is wired). For most hunting, if now is within 30 minutes before
  /// dusk or later, the trip date defaults to tomorrow. Fishing does
  /// not shift. Placeholder dusk is 6:30 PM local, to be replaced with
  /// a real sunrise/sunset source in a later chunk.
  bool _isNearOrAfterDusk(DateTime now) {
    final dusk = DateTime(now.year, now.month, now.day, 18, 30);
    return now.isAfter(dusk.subtract(const Duration(minutes: 30)));
  }

  void _switchKind(bool hunt) {
    setState(() {
      _isHunt = hunt;
      // Restore the last-used species of the chosen kind.
      _species = hunt ? _lastHunt : _lastFish;
      _checkedPack.clear();
      if (hunt) {
        final now = DateTime.now();
        if (_isNearOrAfterDusk(now)) {
          _tripDate = DateTime(now.year, now.month, now.day + 1);
          _duskApplied = true;
        } else {
          _duskApplied = false;
        }
      } else {
        _duskApplied = false;
        // If the restored fish does not occur in the current county,
        // move the county (not the species) to its first county.
        final counties = _availableCounties;
        if (!counties.contains(_county)) {
          _county = counties.first;
          _water = watersForCounty(_county).first;
        }
      }
    });
  }

  void _onSpeciesChanged(String? value) {
    if (value == null) return;
    setState(() {
      _species = value;
      if (_isFish) {
        _lastFish = value;
      } else {
        _lastHunt = value;
      }
      _checkedPack.clear();
      if (_isFish && value != manualEntry) {
        // Narrow county/water to where this fish occurs.
        // Never move the species itself here.
        final counties = _availableCounties;
        if (!counties.contains(_county)) {
          _county = counties.first;
        }
        final waters = watersForCounty(_county);
        if (!waters.contains(_water)) {
          _water = waters.first;
        }
      }
    });
  }

  void _onCountyChanged(String? value) {
    if (value == null) return;
    setState(() {
      _county = value;
      // KEY RULE: a county change NEVER narrows or moves the species.
      _water = watersForCounty(_county).first;
    });
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _tripDate,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now().add(const Duration(days: 365 * 2)),
    );
    if (picked != null) {
      setState(() {
        _tripDate = picked;
        _duskApplied = false;
      });
    }
  }

  String _formatDate(DateTime date) {
    final month = date.month.toString().padLeft(2, '0');
    final day = date.day.toString().padLeft(2, '0');
    return '${date.year}-$month-$day';
  }

  @override
  Widget build(BuildContext context) {
    final pack = _packList;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _motto,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          // Date row, with the dusk-rule note when it applied.
          Row(
            children: [
              const Text('Trip date: '),
              TextButton(
                onPressed: _pickDate,
                child: Text(_formatDate(_tripDate)),
              ),
            ],
          ),
          if (_duskApplied)
            const Text(
              'Date moved to tomorrow — dusk rule (placeholder dusk '
              '6:30 PM, not a live sunset API).',
              style: TextStyle(color: Color(0xFFD4AF37)),
            ),
          const SizedBox(height: 12),
          // Hunt / Fish radio — two buttons, Fish default.
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: _isFish ? null : () => _switchKind(false),
                  child: const Text('Fish'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ElevatedButton(
                  onPressed: _isHunt ? null : () => _switchKind(true),
                  child: const Text('Hunt'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // Species picker — always the full list for the chosen kind.
          DropdownButtonFormField<String>(
            value: _species,
            decoration: const InputDecoration(labelText: 'Species'),
            items: _speciesOptions
                .map(
                  (species) => DropdownMenuItem(
                    value: species,
                    child: Text(species),
                  ),
                )
                .toList(),
            onChanged: _onSpeciesChanged,
          ),
          if (_isFish) ...[
            const SizedBox(height: 8),
            Text(
              _countNote,
              style: const TextStyle(color: Color(0xFFD4AF37)),
            ),
          ],
          const SizedBox(height: 12),
          // County picker — suffixed " County" in the label items.
          DropdownButtonFormField<String>(
            value: _county,
            decoration: const InputDecoration(labelText: 'County'),
            items: _availableCounties
                .map(
                  (county) => DropdownMenuItem(
                    value: county,
                    child: Text('$county County'),
                  ),
                )
                .toList(),
            onChanged: _onCountyChanged,
          ),
          const SizedBox(height: 12),
          // Water dropdown for fish, free-text hunting area for hunting.
          if (_isFish)
            DropdownButtonFormField<String>(
              value: _water,
              decoration: const InputDecoration(labelText: 'Water'),
              items: _availableWaters
                  .map(
                    (water) => DropdownMenuItem(
                      value: water,
                      child: Text(water),
                    ),
                  )
                  .toList(),
              onChanged: (value) {
                if (value != null) setState(() => _water = value);
              },
            )
          else
            TextFormField(
              controller: _huntingAreaController,
              decoration: const InputDecoration(
                labelText: 'Hunting area',
                hintText: 'e.g. Kanawha State Forest, Ridge 3',
              ),
            ),
          // Weapon picker, hunting only. Changes the season verdict.
          if (_isHunt) ...[
            const SizedBox(height: 16),
            const Text('Weapon'),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: Weapon.values.map((weapon) {
                final selected = weapon == _weapon;
                return ChoiceChip(
                  label: Text(weapon.label),
                  selected: selected,
                  onSelected: (_) => setState(() => _weapon = weapon),
                );
              }).toList(),
            ),
          ],
          const SizedBox(height: 16),
          // Season verdict — SAMPLE DATA, always labelled as such.
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Can I go?',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _isFish
                        ? "You're clear to go."
                        : "You're clear to go. ${sampleSeasonWindow(_species, _weapon)}",
                  ),
                  if (_species == 'Coyote') ...[
                    const SizedBox(height: 8),
                    const Text(coyoteNote),
                  ],
                  const SizedBox(height: 8),
                  const Text(
                    'Sample data — check official WVDNR regulations. '
                    'Verified date: sample placeholder. '
                    'Source: WVDNR (placeholder — replace with the '
                    'verified source link in the real build).',
                    style: TextStyle(fontStyle: FontStyle.italic),
                  ),
                  const SizedBox(height: 8),
                  const Text(disclaimerShort),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          // Pack checklist.
          Text(
            _isHunt ? 'Firearm pack list' : 'Pack list',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          for (final item in pack)
            CheckboxListTile(
              value: _checkedPack.contains(item),
              onChanged: (checked) {
                setState(() {
                  if (checked == true) {
                    _checkedPack.add(item);
                  } else {
                    _checkedPack.remove(item);
                  }
                });
              },
              title: Text(item),
              controlAffinity: ListTileControlAffinity.leading,
              dense: true,
            ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                // Chunk 1: no trip persistence yet. Planned Trips is a
                // placeholder screen in this chunk; saving a trip for
                // real is a later chunk. The button text and motto
                // still follow the Fish/Hunt rule.
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text(
                      'Trip saved locally (sample data only). '
                      'Planned Trips persistence arrives in a later chunk.',
                    ),
                  ),
                );
              },
              child: Text(_saveButtonText),
            ),
          ),
          const SizedBox(height: 16),
          // Disclaimer & user agreement card.
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Disclaimer & user agreement',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    widget.agreedAtIso != null
                        ? 'Agreed: ${widget.agreedAtIso!.substring(0, 10)}'
                        : 'Not yet agreed.',
                  ),
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: () {
                      showDialog<void>(
                        context: context,
                        builder: (_) => const DisclaimerReadOnlyDialog(),
                      );
                    },
                    child: const Text('Re-read disclaimer'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
