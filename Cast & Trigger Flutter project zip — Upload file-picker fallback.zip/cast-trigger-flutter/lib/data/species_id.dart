/// Automatic species suggestion from a photo — SUGGESTION ONLY.
///
/// Uses Google ML Kit's bundled base image-labeling model
/// (`google_mlkit_image_labeling`, base model). No model file is
/// bundled in this repo and none is downloaded: the model ships
/// inside the ML Kit SDK itself. That is deliberate: a bundled
/// TFLite model would need a 1001-label file in exact ImageNet
/// order plus a minSdk bump, and a wrong label order silently
/// mislabels every photo. ML Kit returns label strings, so the
/// mapping below works on the label text itself.
///
/// HONEST LIMITS — read before trusting this file:
/// - ML Kit's base model labels are BROAD categories, not a
///   WV species classifier. It can say "fish", "trout", "deer",
///   "fox" — it cannot reliably tell a Largemouth Bass from a
///   Smallmouth Bass, or a Rainbow Trout from a Brown Trout.
///   Where the model only supports a category, this service
///   returns that category (with candidate species for the user
///   to pick) and NEVER invents a precise species.
/// - The result is a suggestion only. It is never a legal species
///   ID, never a bag-limit or season verdict, and the user always
///   confirms the species in the Spots dialog before saving.
/// - No AI bite predictions, ever. This only labels what is in
///   a photo the user already took.
///
/// Confidence / guard rules (mirroring the prototype's MobileNet
/// rules: >=25% confidence, and >= half the top label's confidence):
/// - Labels below 0.25, or below half the top label's confidence,
///   are discarded before mapping.
/// - NON-GAME GUARD (the dog-as-bass regression test): if the
///   TOP surviving label is a non-game subject (dog, cat, person,
///   horse, vehicle, food, …), the result is non-game, even if a
///   lower label mentions a fish or animal. A dog photo must
///   never be labelled Largemouth Bass (or any game species).
/// - If no surviving label maps to a game category, the result
///   is "unidentified" — the UI falls back to manual entry.
///   Identification failure never blocks saving a log manually.
library;

import 'package:google_mlkit_image_labeling/google_mlkit_image_labeling.dart';

/// The outcome of one photo-identification attempt.
class SpeciesSuggestion {
  const SpeciesSuggestion({
    required this.kind,
    required this.rawLabel,
    required this.confidence,
    this.suggestedSpecies,
    this.candidateSpecies = const [],
  });

  /// 'fish' | 'game' | 'nonGame' | 'unidentified'
  final String kind;

  /// The ML Kit label that produced this result, e.g. "Trout".
  final String rawLabel;

  /// Confidence of that label, 0.0–1.0.
  final double confidence;

  /// An exact app species, only when the label supports one
  /// (e.g. "Whitetail Deer"). Null for category-only results.
  final String? suggestedSpecies;

  /// Exact species the user may pick from, for category-only
  /// results (e.g. the four trouts). Empty for exact results.
  final List<String> candidateSpecies;

  bool get isGame => kind == 'fish' || kind == 'game';
  bool get isFish => kind == 'fish';
  bool get isNonGame => kind == 'nonGame';
  bool get isUnidentified => kind == 'unidentified';
  bool get hasExactSpecies => suggestedSpecies != null;

  String get confidencePct => '${(confidence * 100).round()}%';
}

/// On-device photo species suggestion. One-shot: create, run, close.
class SpeciesIdService {
  /// Labels that are never game species in this app, even if the
  /// photo also contains something animal-like. Checked against
  /// the TOP surviving label (see the guard rule above).
  static const List<String> _nonGameKeywords = [
    'dog', 'puppy', 'cat', 'kitten', 'person', 'people', 'human',
    'man', 'woman', 'child', 'face', 'horse', 'cow', 'pig', 'sheep',
    'goat', 'rabbit', 'hare', 'bear', 'vehicle', 'car', 'boat',
    'food', 'furniture', 'building', 'plant', 'flower', 'tree',
  ];

  /// Exact-label mapping: keyword -> app species name.
  /// Only entries the base model can plausibly return as a label.
  static const Map<String, String> _exactSpecies = {
    'whitetail deer': 'Whitetail Deer',
    'deer': 'Whitetail Deer',
    'wild turkey': 'Wild Turkey',
    'turkey': 'Wild Turkey',
    'coyote': 'Coyote',
    'red fox': 'Red Fox',
    'gray fox': 'Gray Fox',
    'grey fox': 'Gray Fox',
    'bobcat': 'Bobcat',
    'lynx': 'Bobcat',
    'common carp': 'Common Carp',
    'carp': 'Common Carp',
    'yellow perch': 'Yellow Perch',
    'perch': 'Yellow Perch',
    'chain pickerel': 'Chain Pickerel',
    'pickerel': 'Chain Pickerel',
    'freshwater drum': 'Freshwater Drum',
    'drum': 'Freshwater Drum',
  };

  /// Category mapping: keyword -> (kind, candidate species).
  /// Used when the label supports a group, not one species.
  static const Map<String, _Category> _categories = {
    'trout': _Category('fish', [
      'Rainbow Trout',
      'Brown Trout',
      'Brook Trout',
      'Golden Rainbow Trout',
    ]),
    'bass': _Category('fish', [
      'Largemouth Bass',
      'Smallmouth Bass',
      'Spotted Bass',
    ]),
    'catfish': _Category('fish', [
      'Channel Catfish',
      'Flathead Catfish',
      'Blue Catfish',
    ]),
    'crappie': _Category('fish', ['Black Crappie', 'White Crappie']),
    'sunfish': _Category('fish', [
      'Bluegill',
      'Redear Sunfish',
      'Redbreast Sunfish',
      'Green Sunfish',
    ]),
    'bluegill': _Category('fish', [
      'Bluegill',
      'Redear Sunfish',
      'Redbreast Sunfish',
      'Green Sunfish',
    ]),
    'walleye': _Category('fish', ['Walleye', 'Saugeye', 'Sauger']),
    'sauger': _Category('fish', ['Walleye', 'Saugeye', 'Sauger']),
    'saugeye': _Category('fish', ['Walleye', 'Saugeye', 'Sauger']),
    'fish': _Category('fish', []),
    'squirrel': _Category('game', ['Gray Squirrel', 'Fox Squirrel']),
    'fox': _Category('game', ['Red Fox', 'Gray Fox']),
    'grouse': _Category('game', ['Ruffed Grouse']),
    'quail': _Category('game', ['Northern Bobwhite Quail']),
    'dove': _Category('game', ['Mourning Dove']),
    'woodcock': _Category('game', ['American Woodcock']),
    'bird': _Category('game', [
      'Wild Turkey',
      'Ruffed Grouse',
      'Northern Bobwhite Quail',
      'Mourning Dove',
      'American Woodcock',
    ]),
  };

  /// Identify a photo at [photoPath]. Never throws: any failure
  /// (no model, plugin error, timeout) returns an unidentified
  /// result so the UI can fall back to manual entry.
  static Future<SpeciesSuggestion> identify(String photoPath) async {
    try {
      final labeler = ImageLabeler(
        options: ImageLabelerOptions(confidenceThreshold: 0.25),
      );
      try {
        final inputImage = InputImage.fromFilePath(photoPath);
        final labels = await labeler
            .processImage(inputImage)
            .timeout(const Duration(seconds: 20));
        return _mapLabels(labels);
      } finally {
        // close() is fire-and-forget in this plugin's API (the
        // docs show it un-awaited); do not await a void return.
        labeler.close();
      }
    } catch (_) {
      return const SpeciesSuggestion(
        kind: 'unidentified',
        rawLabel: '',
        confidence: 0,
      );
    }
  }

  /// Apply the confidence + guard rules to ML Kit's labels.
  /// Exposed for testing the mapping without a photo.
  static SpeciesSuggestion mapLabelsForTest(
    List<({String label, double confidence})> labels,
  ) {
    return _mapLabels(
      labels
          .map((l) => _Label(l.label, l.confidence))
          .toList(growable: false),
    );
  }

  static SpeciesSuggestion _mapLabels(List<dynamic> labels) {
    if (labels.isEmpty) {
      return const SpeciesSuggestion(
        kind: 'unidentified',
        rawLabel: '',
        confidence: 0,
      );
    }
    // Sort by confidence descending; the plugin returns labels in
    // arbitrary order, so never trust labels.first as the top.
    final sorted = [...labels]
      ..sort((a, b) => _confidence(b).compareTo(_confidence(a)));
    final top = _confidence(sorted.first);
    if (top < 0.25) {
      return const SpeciesSuggestion(
        kind: 'unidentified',
        rawLabel: '',
        confidence: 0,
      );
    }
    // Keep only labels >=25% AND >= half the top label's confidence.
    final surviving = sorted
        .where((l) => _confidence(l) >= 0.25 && _confidence(l) >= top * 0.5)
        .toList(growable: false);
    if (surviving.isEmpty) {
      return const SpeciesSuggestion(
        kind: 'unidentified',
        rawLabel: '',
        confidence: 0,
      );
    }
    final topLabel = _label(surviving.first).toLowerCase();
    // NON-GAME GUARD: top surviving label is not game -> non-game,
    // no matter what lower labels say. This is the dog-as-bass
    // regression test: a dog photo's top label is a dog/breed.
    if (_nonGameKeywords.any((k) => topLabel.contains(k))) {
      return SpeciesSuggestion(
        kind: 'nonGame',
        rawLabel: _label(surviving.first),
        confidence: _confidence(surviving.first),
      );
    }
    // Game mapping, in surviving-label order (highest first).
    for (final label in surviving) {
      final text = _label(label).toLowerCase();
      for (final entry in _exactSpecies.entries) {
        if (text.contains(entry.key)) {
          return SpeciesSuggestion(
            kind: entry.value.contains('Deer') ||
                    entry.value.contains('Turkey') ||
                    entry.value.contains('Squirrel') ||
                    entry.value.contains('Grouse') ||
                    entry.value.contains('Quail') ||
                    entry.value.contains('Dove') ||
                    entry.value.contains('Woodcock') ||
                    entry.value.contains('Coyote') ||
                    entry.value.contains('Fox') ||
                    entry.value.contains('Bobcat')
                ? 'game'
                : 'fish',
            rawLabel: _label(label),
            confidence: _confidence(label),
            suggestedSpecies: entry.value,
          );
        }
      }
      for (final entry in _categories.entries) {
        if (text.contains(entry.key)) {
          return SpeciesSuggestion(
            kind: entry.value.kind,
            rawLabel: _label(label),
            confidence: _confidence(label),
            candidateSpecies: entry.value.species,
          );
        }
      }
    }
    return SpeciesSuggestion(
      kind: 'unidentified',
      rawLabel: _label(surviving.first),
      confidence: _confidence(surviving.first),
    );
  }

  static String _label(dynamic label) {
    if (label is _Label) return label.text;
    try {
      return (label as dynamic).label as String;
    } catch (_) {
      return '';
    }
  }

  static double _confidence(dynamic label) {
    if (label is _Label) return label.confidence;
    try {
      return (label as dynamic).confidence as double;
    } catch (_) {
      return 0;
    }
  }
}

class _Category {
  const _Category(this.kind, this.species);
  final String kind;
  final List<String> species;
}

class _Label {
  const _Label(this.text, this.confidence);
  final String text;
  final double confidence;
}
