/// Disclaimer text for the Cast & Trigger agreement gate.
///
/// DRAFT ONLY — for attorney review before launch. This is not legal
/// advice and is not final legal text. Do not present it as such.
/// Version the agreement so a future disclaimer change can re-prompt.
const String disclaimerVersion = '1.0';

/// Short version: shown under every season verdict and on the Planner
/// before saving, and at the top of the agreement gate.
const String disclaimerShort = 'Check before you go. Cast & Trigger is a '
    'planning helper, not an official source. Seasons, bag and creel '
    'limits, licenses, stamps, zones, and county rules change — sometimes '
    'mid-season — and the information in this app may be out of date or '
    'wrong for your exact location, weapon, or license class. Always '
    'double-check the current official regulations for the state, county, '
    'and water or land where you will hunt or fish before you go, and '
    'follow those official rules, not this app, if they differ. Cast & '
    'Trigger is not responsible for a ticket, fine, license suspension, '
    'or other penalty that results from relying on information in this '
    'app. You are responsible for knowing and following the law where '
    'you hunt and fish.';

const String disclaimerCheckboxLabel =
    'I have read and understand this disclaimer. I will always '
    'double-check the current official regulations.';

/// One section of the full disclaimer.
class DisclaimerSection {
  const DisclaimerSection(this.title, this.body);
  final String title;
  final String body;
}

/// Full version, 10 sections (substance from the brief).
/// Section titles are the app's headings; the body text is the
/// plain-language substance to be reviewed by counsel.
const List<DisclaimerSection> disclaimerSections = [
  DisclaimerSection(
    '1. Not an official source',
    'Cast & Trigger is a planning helper, not an official source, and is '
        'not affiliated with the West Virginia Division of Natural '
        'Resources (WVDNR) or any other agency.',
  ),
  DisclaimerSection(
    '2. Information may be wrong or out of date',
    'Seasons, limits, zones, and rules change, sometimes mid-season. '
        'Information in this app may be out of date or wrong even when '
        'it shows a verified date.',
  ),
  DisclaimerSection(
    '3. Always double-check — official rules control',
    'Before you go, double-check the current official regulations for '
        'your state, county / zone / wildlife management area / land, '
        'species, sex, weapon, and license class, including any special '
        'rules. If official rules differ from this app, follow the '
        'official rules.',
  ),
  DisclaimerSection(
    '4. No legal advice',
    'Nothing in this app is legal advice. It does not tell you whether '
        'a particular hunt or fishing trip is legal for you.',
  ),
  DisclaimerSection(
    '5. Photo estimates only',
    'Species suggestions, lengths, and weights from a photo are '
        'estimates only. They are never a legal identification. Measure '
        'your catch or harvest yourself.',
  ),
  DisclaimerSection(
    '6. Maps are not survey-grade',
    'Maps, spots, and pins are not survey-grade property lines and are '
        'not trespass advice. A map line is not permission to hunt or '
        'fish private land — get written landowner permission.',
  ),
  DisclaimerSection(
    '7. Safety is your responsibility',
    'Hunting and fishing carry real risks. You are responsible for your '
        'own safety, equipment, and decisions in the field.',
  ),
  DisclaimerSection(
    '8. Limitation of liability',
    'To the fullest extent permitted by law, Cast & Trigger is not '
        'liable for a ticket, fine, license suspension, or other penalty '
        'resulting from relying on information in this app.',
  ),
  DisclaimerSection(
    '9. Your logs are your records',
    'Your logs are your own records. Tagging, checking, and reporting '
        'duties remain yours, under the rules that apply to you.',
  ),
  DisclaimerSection(
    '10. This disclaimer may be updated',
    'This disclaimer may be updated. The version in force at the time '
        'you use the app applies. A material change may ask you to agree '
        'again.',
  ),
];
