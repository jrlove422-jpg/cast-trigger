import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:encrypt/encrypt.dart' as enc;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// License storage — SECURITY SPEC (decided, mandatory):
/// - Biometric/PIN gate on the My License screen on EVERY open
///   (enforced in license_screen.dart, not here).
/// - The license file is stored ENCRYPTED on-device (AES-256-CBC).
///   The key lives in flutter_secure_storage (keystore-backed on
///   Android). The IV is stored alongside the metadata; an IV is not
///   secret. Plaintext is only ever held in memory, or in a temp file
///   created at open-time for a PDF viewer.
/// - No SSN is ever stored as a typed field. The app never extracts,
///   OCRs, or sends license data anywhere.
/// - The license is NEVER included in share cards, logs, exports,
///   cloud sync, or AI calls. This service is only ever called from
///   the gated My License screen.
///
/// What is NOT in this chunk (stated plainly, not silently omitted):
/// - No embedded in-app PDF viewer. A PDF is decrypted to a temp file
///   and opened with the device's PDF viewer via open_filex.
/// - Cropping/masking is offered for photos via image_cropper before
///   saving; a PDF cannot be cropped in-app — the pre-save warning
///   tells the user to mask it outside the app first.
enum LicenseKind { photo, pdf }

class LicenseMeta {
  LicenseMeta({
    required this.kind,
    required this.fileName,
    required this.fileSize,
    required this.goodThrough,
    required this.ivBase64,
  });

  final LicenseKind kind;
  final String fileName;
  final int fileSize;
  final DateTime goodThrough;
  final String ivBase64;

  String get status {
    final today = DateTime(
      DateTime.now().year,
      DateTime.now().month,
      DateTime.now().day,
    );
    final due = DateTime(
      goodThrough.year,
      goodThrough.month,
      goodThrough.day,
    );
    if (due.isBefore(today)) return 'Expired';
    if (due.difference(today).inDays <= 30) return 'Expiring soon';
    return 'Valid';
  }

  Map<String, dynamic> toJson() => {
        'kind': kind.name,
        'fileName': fileName,
        'fileSize': fileSize,
        'goodThrough': goodThrough.toIso8601String(),
        'ivBase64': ivBase64,
      };

  factory LicenseMeta.fromJson(Map<String, dynamic> j) => LicenseMeta(
        kind: j['kind'] == 'pdf' ? LicenseKind.pdf : LicenseKind.photo,
        fileName: j['fileName'] as String,
        fileSize: j['fileSize'] as int,
        goodThrough: DateTime.parse(j['goodThrough'] as String),
        ivBase64: j['ivBase64'] as String,
      );
}

class LicenseService {
  LicenseService._();

  static final LicenseService instance = LicenseService._();

  static const _keyName = 'ct_license_key_b64';
  static const _metaName = 'ct_license_meta';
  static const _encFileName = 'license.enc';

  final FlutterSecureStorage _secure = const FlutterSecureStorage();

  Future<Directory> _docsDir() async =>
      getApplicationDocumentsDirectory();

  Future<enc.Key> _key() async {
    var stored = await _secure.read(key: _keyName);
    if (stored == null) {
      final random = Random.secure();
      final bytes =
          List<int>.generate(32, (_) => random.nextInt(256));
      stored = base64Encode(bytes);
      await _secure.write(key: _keyName, value: stored);
    }
    return enc.Key.fromBase64(stored);
  }

  Future<LicenseMeta?> loadMeta() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_metaName);
    if (raw == null) return null;
    try {
      return LicenseMeta.fromJson(
        jsonDecode(raw) as Map<String, dynamic>,
      );
    } catch (_) {
      return null;
    }
  }

  /// Encrypt and save a license file, replacing any previous license.
  /// [bytes] are the original file bytes; [fileName]/[fileSize] are
  /// the original file's name and size (shown in the UI, not the
  /// encrypted blob's). Replacing a photo with a PDF (or vice versa)
  /// clears the other — only one slot exists.
  Future<LicenseMeta> saveLicense({
    required LicenseKind kind,
    required String fileName,
    required List<int> bytes,
    required DateTime goodThrough,
  }) async {
    final key = await _key();
    final ivBytes =
        List<int>.generate(16, (_) => Random.secure().nextInt(256));
    final iv = enc.IV(Uint8List.fromList(ivBytes));
    final encrypter = enc.Encrypter(enc.AES(key, mode: enc.AESMode.cbc));
    final encrypted = encrypter.encryptBytes(bytes, iv: iv);
    final dir = await _docsDir();
    final file = File('${dir.path}/$_encFileName');
    await file.writeAsBytes(encrypted.bytes, flush: true);
    final meta = LicenseMeta(
      kind: kind,
      fileName: fileName,
      fileSize: bytes.length,
      goodThrough: goodThrough,
      ivBase64: base64Encode(ivBytes),
    );
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_metaName, jsonEncode(meta.toJson()));
    return meta;
  }

  /// Decrypt the stored license into memory. Callers must NOT write
  /// these bytes to a permanent file, and must NOT pass them to any
  /// share, export, or AI call.
  Future<Uint8List?> decryptBytes() async {
    final meta = await loadMeta();
    if (meta == null) return null;
    final dir = await _docsDir();
    final file = File('${dir.path}/$_encFileName');
    if (!await file.exists()) return null;
    final key = await _key();
    final iv = enc.IV.fromBase64(meta.ivBase64);
    final encrypter = enc.Encrypter(enc.AES(key, mode: enc.AESMode.cbc));
    final encrypted =
        enc.Encrypted(await file.readAsBytes());
    final decrypted = encrypter.decryptBytes(encrypted, iv: iv);
    return Uint8List.fromList(decrypted);
  }

  /// Decrypt to a temp file, for opening a PDF in the device viewer.
  /// The caller should delete the temp file when done if possible;
  /// it lives in the app cache directory, not in shared storage.
  Future<String?> decryptToTempFile(String extension) async {
    final bytes = await decryptBytes();
    if (bytes == null) return null;
    final cache = await getTemporaryDirectory();
    final path =
        '${cache.path}/ct_license_temp.$extension';
    final file = File(path);
    await file.writeAsBytes(bytes, flush: true);
    return path;
  }

  Future<void> removeLicense() async {
    final dir = await _docsDir();
    final file = File('${dir.path}/$_encFileName');
    try {
      if (await file.exists()) await file.delete();
    } catch (_) {}
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_metaName);
    // The key is deliberately kept in secure storage: it is useless
    // without a license file, and keeping it avoids key churn if the
    // user adds a new license later.
  }
}
