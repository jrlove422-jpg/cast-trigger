import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Placeholder for a later chunk. Navigation works in Chunk 1; the
/// screen itself is intentionally not built yet.
/// Do not mistake this placeholder for a finished screen.
class PlaceholderScreen extends StatelessWidget {
  const PlaceholderScreen({super.key, required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title,
              style: GoogleFonts.caveatBrush(fontSize: 30),
            ),
            const SizedBox(height: 12),
            const Text(
              'Coming in a later chunk.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
