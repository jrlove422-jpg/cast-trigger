import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/disclaimer.dart';
import '../widgets/state_pill.dart';

/// Read-only re-read view of the full disclaimer.
/// Used from the Planner's "Disclaimer & user agreement" card.
/// No checkbox, no agree button — this is review only.
class DisclaimerReadOnlyDialog extends StatelessWidget {
  const DisclaimerReadOnlyDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Disclaimer & user agreement'),
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(disclaimerShort),
            const SizedBox(height: 16),
            for (final section in disclaimerSections) ...[
              Text(
                section.title,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              Text(section.body),
              const SizedBox(height: 12),
            ],
            const Text(
              'Draft for attorney review — not final legal text.',
              style: TextStyle(fontStyle: FontStyle.italic),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Close'),
        ),
      ],
    );
  }
}

/// One-time "Read & Agree" gate, shown on first open only.
/// The app stays locked until the user:
///  1. scrolls to the end of the disclaimer (unlocks the checkbox), then
///  2. checks "I have read and understand…", then
///  3. taps "Agree & start using the app".
/// The agreement (version + date/time) is saved locally. In the real app
/// this must ALSO be recorded server-side against the user account —
/// local storage alone is a prototype limitation carried over here.
class DisclaimerGateScreen extends StatefulWidget {
  const DisclaimerGateScreen({super.key, required this.onAgreed});

  final VoidCallback onAgreed;

  @override
  State<DisclaimerGateScreen> createState() => _DisclaimerGateScreenState();
}

class _DisclaimerGateScreenState extends State<DisclaimerGateScreen> {
  final ScrollController _scrollController = ScrollController();
  bool _reachedEnd = false;
  bool _checked = false;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
    // If the whole disclaimer fits without scrolling (large screen),
    // there is no scroll end to reach — unlock the checkbox.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients &&
          _scrollController.position.maxScrollExtent <= 0) {
        setState(() => _reachedEnd = true);
      }
    });
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (!_scrollController.hasClients) return;
    final position = _scrollController.position;
    // Reached the end (with a small tolerance) unlocks the checkbox.
    if (position.pixels >= position.maxScrollExtent - 20 && !_reachedEnd) {
      setState(() => _reachedEnd = true);
    }
  }

  Future<void> _agree() async {
    setState(() => _saving = true);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('disclaimer_agreement_version', disclaimerVersion);
    await prefs.setString(
      'disclaimer_agreed_at',
      DateTime.now().toIso8601String(),
    );
    if (!mounted) return;
    widget.onAgreed();
  }

  @override
  Widget build(BuildContext context) {
    final canAgree = _reachedEnd && _checked && !_saving;
    return Scaffold(
      appBar: AppBar(
        title: const Text('CAST & TRIGGER'),
        actions: const [StatePill()],
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              controller: _scrollController,
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Read & Agree',
                    style: GoogleFonts.caveatBrush(fontSize: 30),
                  ),
                  const SizedBox(height: 12),
                  const Text(disclaimerShort),
                  const SizedBox(height: 16),
                  for (final section in disclaimerSections) ...[
                    Text(
                      section.title,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(section.body),
                    const SizedBox(height: 12),
                  ],
                  const Text(
                    'Draft for attorney review — not final legal text.',
                    style: TextStyle(fontStyle: FontStyle.italic),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                if (!_reachedEnd)
                  const Text(
                    'Scroll to the end to unlock the checkbox.',
                    style: TextStyle(color: Colors.grey),
                  ),
                CheckboxListTile(
                  value: _checked,
                  onChanged: _reachedEnd
                      ? (value) => setState(() => _checked = value ?? false)
                      : null,
                  title: const Text(disclaimerCheckboxLabel),
                  controlAffinity: ListTileControlAffinity.leading,
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: canAgree ? _agree : null,
                    child: Text(
                      _saving ? 'Saving…' : 'Agree & start using the app',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
