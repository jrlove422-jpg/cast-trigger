import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import '../data/app_store.dart';
import '../widgets/species_visual.dart';

/// Planned Trips: month calendar + upcoming trips list.
/// Saving from the Planner actually persists here (AppStore).
/// Tapping "Load in Planner" sends the trip back to the Planner tab
/// via AppStore.pendingPlannerTrip; the shell switches to Planner.
class PlannedTripsScreen extends StatefulWidget {
  const PlannedTripsScreen({
    super.key,
    required this.onLoadTrip,
  });

  final VoidCallback onLoadTrip;

  @override
  State<PlannedTripsScreen> createState() => _PlannedTripsScreenState();
}

class _PlannedTripsScreenState extends State<PlannedTripsScreen> {
  final AppStore _store = AppStore.instance;
  DateTime _month = DateTime(
    DateTime.now().year,
    DateTime.now().month,
    1,
  );
  DateTime? _selectedDay;

  @override
  void initState() {
    super.initState();
    _store.load();
  }

  String _formatDate(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  /// Pack list for a trip, mirroring the Planner pack lists.
  /// Fish: rod pack. Hunt: weapon pack + hunter orange etc., plus
  /// the Coyote red-light / written-consent items for Coyote.
  List<String> _packListFor(Trip trip) {
    if (trip.isFish) {
      return const [
        'Rod & reel',
        'Tackle',
        'Knife',
        'Snacks & water',
        'First aid kit',
        'License in wallet',
      ];
    }
    final List<String> base;
    switch (trip.weapon) {
      case 'Bow':
        base = ['Bow', 'Arrows', 'Knife'];
        break;
      case 'Muzzleloader':
        base = ['Muzzleloader', 'Powder & caps', 'Knife'];
        break;
      default:
        base = ['Firearm', 'Ammo', 'Knife'];
    }
    final pack = [
      ...base,
      'Hunter orange',
      'Snacks & water',
      'First aid kit',
      'License in wallet',
    ];
    if (trip.species == 'Coyote') {
      pack.addAll(['Red light', 'Written landowner consent']);
    }
    return pack;
  }

  /// Fix #10 — Share trip, MOCK ONLY (prototype parity).
  /// Real group-trip sharing is NOT built: it needs accounts and
  /// cloud sync, and group trips are PREMIUM. This panel is built
  /// live from the trip's own values, shows the plan only, and
  /// states plainly that nothing is sent or saved in this build.
  /// Exact spot/pins opt-in starts OFF and is never used to share
  /// anything here: "Copy invite message" copies plan-only text
  /// (date, species, county/water, pack list — no GPS, no exact
  /// pins, no past catches) and "Share via…" does NOT open a share
  /// sheet as if it were a real group trip; it explains the mock.
  Future<void> _openShareTrip(Trip trip) async {
    final pack = _packListFor(trip);
    final planText = [
      'Cast & Trigger trip (mock invite — nothing sent)',
      '${trip.species} — ${_formatDate(trip.date)}',
      '${trip.place}, ${trip.county} County',
      if (trip.weapon.isNotEmpty) 'Weapon: ${trip.weapon}',
      'Pack list: ${pack.join(', ')}',
    ].join('\n');
    final invited = <String>[];
    final nameController = TextEditingController();
    var shareExactPins = false;
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) {
          return AlertDialog(
            title: Row(
              children: [
                const Expanded(child: Text('Share trip')),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFFD4AF37),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    'Premium',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Group trips (mock)',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text('${trip.species} — ${_formatDate(trip.date)}'),
                  Text('${trip.place}, ${trip.county} County'),
                  if (trip.weapon.isNotEmpty)
                    Text('Weapon: ${trip.weapon}'),
                  const SizedBox(height: 8),
                  const Text(
                    'Pack list:',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  for (final item in pack) Text('• $item'),
                  const SizedBox(height: 12),
                  const Text(
                    'Invited friends see the plan only — not your '
                    'spot book, exact pins, or past catches.',
                    style: TextStyle(fontStyle: FontStyle.italic),
                  ),
                  SwitchListTile(
                    title: const Text('Share exact spot / pins'),
                    subtitle: const Text(
                      'Starts OFF. Even with this on, this mock '
                      'never sends pins.',
                    ),
                    value: shareExactPins,
                    onChanged: (v) =>
                        setDialogState(() => shareExactPins = v),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Invite friends (this session only):',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: nameController,
                          decoration: const InputDecoration(
                            labelText: 'Friend name',
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      TextButton(
                        onPressed: () {
                          final name = nameController.text.trim();
                          if (name.isEmpty) return;
                          final exists = invited.any(
                            (n) => n.toLowerCase() == name.toLowerCase(),
                          );
                          if (exists) return; // duplicates blocked
                          setDialogState(() {
                            invited.add(name);
                            nameController.clear();
                          });
                        },
                        child: const Text('Add'),
                      ),
                    ],
                  ),
                  if (invited.isEmpty)
                    const Text('No one invited yet.')
                  else
                    for (final name in invited)
                      Row(
                        children: [
                          Expanded(child: Text('• $name')),
                          IconButton(
                            icon: const Icon(Icons.close, size: 18),
                            onPressed: () => setDialogState(
                              () => invited.remove(name),
                            ),
                          ),
                        ],
                      ),
                  const SizedBox(height: 12),
                  const Text(
                    'Mock only — nothing is sent or saved in this '
                    'build. Real group-trip sharing needs accounts '
                    'and cloud sync, and group trips are Premium '
                    'when they launch.',
                    style: TextStyle(fontStyle: FontStyle.italic),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () async {
                  await Clipboard.setData(
                    ClipboardData(text: planText),
                  );
                  if (ctx.mounted) {
                    ScaffoldMessenger.of(ctx).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Invite message copied (mock — plan only, '
                          'no pins, nothing sent).',
                        ),
                      ),
                    );
                  }
                },
                child: const Text('Copy invite message'),
              ),
              TextButton(
                onPressed: () {
                  ScaffoldMessenger.of(ctx).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Sharing is a mock in this build — nothing '
                        'is sent. Use "Copy invite message" to '
                        'copy the plan text.',
                      ),
                    ),
                  );
                },
                child: const Text('Share via…'),
              ),
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(),
                child: const Text('Close'),
              ),
            ],
          );
        },
      ),
    );
    nameController.dispose();
  }

  String _monthLabel(DateTime m) {
    const names = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    return '${names[m.month - 1]} ${m.year}';
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _store,
      builder: (context, _) {
        final trips = [..._store.trips]
          ..sort((a, b) => a.date.compareTo(b.date));
        final tripDays = <DateTime, List<Trip>>{};
        for (final t in trips) {
          final d = Trip.dateOnly(t.date);
          tripDays.putIfAbsent(d, () => []).add(t);
        }
        final firstWeekday = DateTime(_month.year, _month.month, 1).weekday;
        // Monday-first calendar grid.
        final leading = (firstWeekday - 1) % 7;
        final daysInMonth = DateTime(
          _month.year,
          _month.month + 1,
          0,
        ).day;
        final today = Trip.dateOnly(DateTime.now());
        final shown = _selectedDay == null
            ? trips
            : trips
                .where(
                  (t) => Trip.dateOnly(t.date) == _selectedDay,
                )
                .toList();
        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Planned Trips',
                style: GoogleFonts.caveatBrush(fontSize: 30),
              ),
              const SizedBox(height: 4),
              const Text(
                'A typed location carries through the whole trip on '
                'every screen.',
                style: TextStyle(fontStyle: FontStyle.italic),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  IconButton(
                    onPressed: () => setState(() {
                      _month = DateTime(_month.year, _month.month - 1, 1);
                    }),
                    icon: const Icon(Icons.chevron_left),
                  ),
                  Expanded(
                    child: Center(
                      child: Text(
                        _monthLabel(_month),
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => setState(() {
                      _month = DateTime(_month.year, _month.month + 1, 1);
                    }),
                    icon: const Icon(Icons.chevron_right),
                  ),
                  TextButton(
                    onPressed: () => setState(() {
                      _month = DateTime(
                        DateTime.now().year,
                        DateTime.now().month,
                        1,
                      );
                      _selectedDay = null;
                    }),
                    child: const Text('This month'),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 7,
                ),
                itemCount: leading + daysInMonth,
                itemBuilder: (context, index) {
                  if (index < leading) return const SizedBox.shrink();
                  final day = index - leading + 1;
                  final date = DateTime(_month.year, _month.month, day);
                  // Fix #8: compare date-only on both sides, so a
                  // time component stored on a trip can never hide
                  // the mark. The trip mark is a GOLD DOT inside the
                  // cell, independent of the selection outline and
                  // of the today fill — the old code used only a
                  // gold border, which was indistinguishable from
                  // the selected-day outline and was read as "no
                  // dot" (e.g. the 2026-11-05 Largemouth Bass trip).
                  final hasTrip =
                      tripDays.containsKey(Trip.dateOnly(date));
                  final isToday = date == today;
                  final isSelected = date == _selectedDay;
                  return InkWell(
                    onTap: () => setState(() {
                      _selectedDay =
                          isSelected ? null : date;
                    }),
                    child: Container(
                      margin: const EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        color: isToday
                            ? const Color(0xFF6B8F5E).withOpacity(0.35)
                            : null,
                        border: Border.all(
                          color: isSelected
                              ? Colors.white54
                              : Colors.transparent,
                          width: 1,
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('$day'),
                          const SizedBox(height: 2),
                          if (hasTrip)
                            Container(
                              width: 8,
                              height: 8,
                              decoration: const BoxDecoration(
                                color: Color(0xFFD4AF37),
                                shape: BoxShape.circle,
                              ),
                            )
                          else
                            const SizedBox(height: 8),
                        ],
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 8),
              const Row(
                children: [
                  Icon(
                    Icons.circle,
                    size: 8,
                    color: Color(0xFFD4AF37),
                  ),
                  SizedBox(width: 6),
                  Text(
                    'Gold dot = trip that day. Tap a day to filter.',
                    style: TextStyle(fontStyle: FontStyle.italic),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Text(
                _selectedDay == null
                    ? 'Upcoming trips'
                    : 'Trips on ${_formatDate(_selectedDay!)} '
                        '(tap the day again to show all)',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              if (shown.isEmpty)
                const Text(
                  'No trips yet. Save one from the Planner, or save '
                  'a Catch / Harvest log in Spots and a trip will be '
                  'created for that day.',
                )
              else
                for (final trip in shown)
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Fix #9: species photo / icon for this
                          // trip's species (same bundled sample
                          // photos + icon fallback as the Planner
                          // species card). A real photo from a log
                          // tied to this trip wins over the sample.
                          Builder(
                            builder: (context) {
                              String? logPhoto;
                              for (final log in _store.logs) {
                                if (log.tripId == trip.id &&
                                    log.photoPath != null) {
                                  logPhoto = log.photoPath;
                                  break;
                                }
                              }
                              return SpeciesVisual(
                                species: trip.species,
                                isFish: trip.isFish,
                                photoPath: logPhoto,
                              );
                            },
                          ),
                          const SizedBox(height: 8),
                          Text(
                            trip.species,
                            style: GoogleFonts.caveatBrush(fontSize: 24),
                          ),
                          Text(
                            '${_formatDate(trip.date)} · ${trip.place}, '
                            '${trip.county} County',
                          ),
                          if (trip.weapon.isNotEmpty)
                            Text('Weapon: ${trip.weapon}'),
                          if (trip.autoCreated)
                            const Text(
                              'Created automatically from a log entry.',
                              style: TextStyle(
                                fontStyle: FontStyle.italic,
                              ),
                            ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              TextButton(
                                onPressed: () {
                                  _store.requestPlannerLoad(trip);
                                  widget.onLoadTrip();
                                },
                                child: const Text('Load in Planner'),
                              ),
                              TextButton(
                                onPressed: () => _openShareTrip(trip),
                                child: const Text('Share trip'),
                              ),
                              TextButton(
                                onPressed: () async {
                                  final ok = await showDialog<bool>(
                                    context: context,
                                    builder: (ctx) => AlertDialog(
                                      title: const Text('Remove trip?'),
                                      content: const Text(
                                        'This removes the planned '
                                        'trip. Logs tied to it are '
                                        'not removed.',
                                      ),
                                      actions: [
                                        TextButton(
                                          onPressed: () =>
                                              Navigator.of(ctx).pop(false),
                                          child: const Text('Keep'),
                                        ),
                                        ElevatedButton(
                                          onPressed: () =>
                                              Navigator.of(ctx).pop(true),
                                          child: const Text('Remove'),
                                        ),
                                      ],
                                    ),
                                  );
                                  if (ok == true) {
                                    await _store.removeTrip(trip.id);
                                  }
                                },
                                child: const Text('Remove'),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
            ],
          ),
        );
      },
    );
  }
}
