import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../data/app_store.dart';
import '../data/disclaimer.dart';
import '../data/wv_data.dart';
import 'disclaimer_gate.dart';

/// Trip Planner — the only fully built screen in Chunk 1.
///
/// Rules that must not regress (see wv_data.dart and the brief):
/// 1. Fish/Hunt radio: Fish default, fish species only; Hunt shows
///    game species only. Switching restores the last-used species of
///    that kind and swaps the form (hunting area, weapon, pack list).
/// 2. Planner fish species list is ALWAYS the full 28 + manual entry.
///    Picking a fish narrows county/water to where it occurs.
///    A county or water change NEVER narrows or moves the species.
/// 3. Summersville Lake is ONLY in Nicholas County, never Mineral.
/// 4. Knife is on every pack list.
/// 5. Every season verdict is SAMPLE data, never official regulation.
class PlannerScreen extends StatefulWidget {
  const PlannerScreen({super.key, required this.agreedAtIso});

  /// ISO-8601 string saved by the disclaimer gate, or null.
  final String? agreedAtIso;

  @override
  State<PlannerScreen> createState() => _PlannerScreenState();
}

class _PlannerScreenState extends State<PlannerScreen> {
  static const String manualEntry = 'Manual / other entry';

  bool _isHunt = false;
  String _lastFish = 'Largemouth Bass';
  String _lastHunt = 'Whitetail Deer';
  String _species = 'Largemouth Bass';
  String _county = 'Kanawha';
  String _water = 'Kanawha River';
  final TextEditingController _huntingAreaController =
      TextEditingController();
  Weapon _weapon = Weapon.firearm;
  DateTime _tripDate = DateTime.now();
  bool _duskApplied = false;
  final Set<String> _checkedPack = {};
  final AppStore _store = AppStore.instance;
  String? _lastAppliedPendingId;

  @override
  void initState() {
    super.initState();
    _store.load();
    _store.addListener(_scheduleApplyPendingTrip);
    _scheduleApplyPendingTrip();
  }

  @override
  void dispose() {
    _store.removeListener(_scheduleApplyPendingTrip);
    _huntingAreaController.dispose();
    super.dispose();
  }

  void _scheduleApplyPendingTrip() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _applyPendingTrip();
    });
  }

  /// Load a trip back from Planned Trips. The shell switches to this
  /// tab after PlannedTrips sets AppStore.pendingPlannerTrip.
  void _applyPendingTrip() {
    final trip = _store.pendingPlannerTrip;
    if (trip == null || trip.id == _lastAppliedPendingId) return;
    _lastAppliedPendingId = trip.id;
    _store.clearPendingPlannerTrip();
    setState(() {
      _isHunt = !trip.isFish;
      _species = trip.species;
      if (trip.isFish) {
        _lastFish = trip.species;
      } else {
        _lastHunt = trip.species;
      }
      _county = trip.county;
      if (trip.isFish) {
        // Only accept a saved water that is still in the filtered
        // list for this species/county; otherwise fall back to the
        // first filtered water so the dropdown never gets a value
        // that is not in its items (which would crash it).
        final waters = watersForCountyAndFish(trip.county, trip.species);
        _water = waters.contains(trip.place) ? trip.place : waters.first;
      } else {
        _huntingAreaController.text = trip.place;
      }
      _tripDate = trip.date;
      _duskApplied = false;
      _checkedPack.clear();
      if (trip.weapon == 'Bow') {
        _weapon = Weapon.bow;
      } else if (trip.weapon == 'Muzzleloader') {
        _weapon = Weapon.muzzleloader;
      } else {
        _weapon = Weapon.firearm;
      }
    });
  }

  bool get _isFish => !_isHunt;

  List<String> get _speciesOptions {
    final options = _isFish ? fishSpecies : gameSpecies;
    return [...options, manualEntry];
  }

  /// Counties available for the current pick. Hunting or manual entry
  /// restores all 55. A fish pick narrows to where it occurs.
  List<String> get _availableCounties {
    if (_isFish && _species != manualEntry) {
      return countiesForFish(_species);
    }
    return wvCounties;
  }

  String get _countNote {
    if (!_isFish) return '';
    final total = _availableCounties.length;
    return '$_species: $total of 55 counties';
  }

  /// Waters filtered by BOTH county and fish species (Fix #1).
  /// Hunting / manual entry returns every water in the county.
  /// Previously this ignored the species entirely, so the water
  /// picker showed waters where the chosen fish does not occur
  /// (and most counties had no waters at all — see wv_data.dart).
  List<String> get _availableWaters {
    if (_isFish) {
      return watersForCountyAndFish(_county, _species);
    }
    return watersForCounty(_county);
  }

  /// Standard species picture for the trip (Fix #6, prototype parity).
  /// Asset path for the 14 fish the prototype had test photos for;
  /// null for every other species (game + remaining fish), which get
  /// the icon visual below instead. The prototype itself reused only
  /// three distinct photos across those 14 entries, so these files
  /// are labelled "Sample photo", never a real catch photo.
  static const Map<String, String> _speciesPhotoAssets = {
    'Largemouth Bass': 'assets/species/largemouth.jpg',
    'Smallmouth Bass': 'assets/species/smallmouth.jpg',
    'Rainbow Trout': 'assets/species/trout.jpg',
    'Brown Trout': 'assets/species/brown_trout.jpg',
    'Brook Trout': 'assets/species/brook_trout.jpg',
    'Golden Rainbow Trout': 'assets/species/golden_trout.jpg',
    'Muskellunge (Musky)': 'assets/species/musky.jpg',
    'Walleye': 'assets/species/walleye.jpg',
    'Saugeye': 'assets/species/saugeye.jpg',
    'Sauger': 'assets/species/sauger.jpg',
    'Yellow Perch': 'assets/species/yellow_perch.jpg',
    'Channel Catfish': 'assets/species/channel_catfish.jpg',
    'Flathead Catfish': 'assets/species/flathead_catfish.jpg',
    'Blue Catfish': 'assets/species/blue_catfish.jpg',
  };

  String _speciesIcon() {
    if (_isFish) return '🐟';
    if (_species == 'Whitetail Deer') return '🦌';
    if (_species == 'Wild Turkey') return '🦃';
    if (_species.contains('Squirrel')) return '🐿️';
    if (_species.contains('Fox') || _species == 'Coyote') return '🦊';
    return '🐾';
  }

  List<String> get _packList {
    if (_isFish) {
      return const [
        'Rod & reel',
        'Tackle',
        'Knife',
        'Snacks & water',
        'First aid kit',
        'License in wallet',
      ];
    }
    final List<String> base;
    switch (_weapon) {
      case Weapon.bow:
        base = ['Bow', 'Arrows', 'Knife'];
        break;
      case Weapon.firearm:
        base = ['Firearm', 'Ammo', 'Knife'];
        break;
      case Weapon.muzzleloader:
        base = ['Muzzleloader', 'Powder & caps', 'Knife'];
        break;
    }
    final pack = [
      ...base,
      'Hunter orange',
      'Snacks & water',
      'First aid kit',
      'License in wallet',
    ];
    if (_species == 'Coyote') {
      // Red light + written landowner consent, per the coyote spec.
      // The consent item matters for Sept 1 – Dec 31 night hunting
      // on private land; it is shown year-round so it is never missed.
      pack.addAll(['Red light', 'Written landowner consent']);
    }
    return pack;
  }

  String get _motto => _isFish ? 'Cast that line' : 'Pull that trigger';

  String get _saveButtonText =>
      _isFish ? 'Cast that line — save trip' : 'Pull that trigger — save trip';

  /// Dusk rule (PLACEHOLDER calculation — do not claim a live sunset API
  /// is wired). For most hunting, if now is within 30 minutes before
  /// dusk or later, the trip date defaults to tomorrow. Fishing does
  /// not shift. Placeholder dusk is 6:30 PM local, to be replaced with
  /// a real sunrise/sunset source in a later chunk.
  bool _isNearOrAfterDusk(DateTime now) {
    final dusk = DateTime(now.year, now.month, now.day, 18, 30);
    return now.isAfter(dusk.subtract(const Duration(minutes: 30)));
  }

  void _switchKind(bool hunt) {
    setState(() {
      _isHunt = hunt;
      // Restore the last-used species of the chosen kind.
      _species = hunt ? _lastHunt : _lastFish;
      _checkedPack.clear();
      if (hunt) {
        final now = DateTime.now();
        if (_isNearOrAfterDusk(now)) {
          _tripDate = DateTime(now.year, now.month, now.day + 1);
          _duskApplied = true;
        } else {
          _duskApplied = false;
        }
      } else {
        _duskApplied = false;
        // If the restored fish does not occur in the current county,
        // move the county (not the species) to its first county.
        final counties = _availableCounties;
        if (!counties.contains(_county)) {
          _county = counties.first;
          _water = _availableWaters.first;
        }
      }
    });
  }

  void _onSpeciesChanged(String? value) {
    if (value == null) return;
    setState(() {
      _species = value;
      if (_isFish) {
        _lastFish = value;
      } else {
        _lastHunt = value;
      }
      _checkedPack.clear();
      if (_isFish && value != manualEntry) {
        // Narrow county/water to where this fish occurs.
        // Never move the species itself here.
        final counties = _availableCounties;
        if (!counties.contains(_county)) {
          _county = counties.first;
        }
        // Filtered by county AND species (Fix #1): the old code used
        // watersForCounty() here, which ignored the species.
        final waters = _availableWaters;
        if (!waters.contains(_water)) {
          _water = waters.first;
        }
      }
    });
  }

  void _onCountyChanged(String? value) {
    if (value == null) return;
    setState(() {
      _county = value;
      // KEY RULE: a county change NEVER narrows or moves the species.
      // The water reset uses the species-filtered list (Fix #1).
      _water = _availableWaters.first;
    });
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _tripDate,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now().add(const Duration(days: 365 * 2)),
    );
    if (picked != null) {
      setState(() {
        _tripDate = picked;
        _duskApplied = false;
      });
    }
  }

  String _formatDate(DateTime date) {
    final month = date.month.toString().padLeft(2, '0');
    final day = date.day.toString().padLeft(2, '0');
    return '${date.year}-$month-$day';
  }

  @override
  Widget build(BuildContext context) {
    final pack = _packList;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _motto,
            style: GoogleFonts.caveatBrush(fontSize: 30),
          ),
          const SizedBox(height: 12),
          // Date row, with the dusk-rule note when it applied.
          Row(
            children: [
              const Text('Trip date: '),
              TextButton(
                onPressed: _pickDate,
                child: Text(_formatDate(_tripDate)),
              ),
            ],
          ),
          if (_duskApplied)
            const Text(
              'Date moved to tomorrow — dusk rule (placeholder dusk '
              '6:30 PM, not a live sunset API).',
              style: TextStyle(color: Color(0xFFD4AF37)),
            ),
          const SizedBox(height: 12),
          // Hunt / Fish radio — two buttons, Fish default.
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: _isFish ? null : () => _switchKind(false),
                  child: const Text('Fish'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ElevatedButton(
                  onPressed: _isHunt ? null : () => _switchKind(true),
                  child: const Text('Hunt'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // Species picker — always the full list for the chosen kind.
          DropdownButtonFormField<String>(
            value: _species,
            decoration: const InputDecoration(labelText: 'Species'),
            items: _speciesOptions
                .map(
                  (species) => DropdownMenuItem(
                    value: species,
                    child: Text(species),
                  ),
                )
                .toList(),
            onChanged: _onSpeciesChanged,
          ),
          if (_isFish) ...[
            const SizedBox(height: 8),
            Text(
              _countNote,
              style: const TextStyle(color: Color(0xFFD4AF37)),
            ),
          ],
          // Standard species picture (Fix #6, prototype parity):
          // the picture changes with the species picker. Fish with
          // a bundled prototype test photo show it, labelled
          // "Sample photo"; every other species shows its icon.
          // Manual / other entry shows no picture, only the label.
          const SizedBox(height: 12),
          Card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (_speciesPhotoAssets.containsKey(_species))
                  ClipRRect(
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(12),
                    ),
                    child: Image.asset(
                      _speciesPhotoAssets[_species]!,
                      height: 160,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) =>
                          const SizedBox.shrink(),
                    ),
                  )
                else if (_species != manualEntry)
                  Container(
                    height: 80,
                    width: double.infinity,
                    alignment: Alignment.center,
                    child: Text(
                      _speciesIcon(),
                      style: const TextStyle(fontSize: 48),
                    ),
                  ),
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          _species,
                          style: GoogleFonts.caveatBrush(fontSize: 24),
                        ),
                      ),
                      if (_speciesPhotoAssets.containsKey(_species))
                        const Text(
                          'Sample photo',
                          style: TextStyle(
                            fontSize: 12,
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          // County picker — suffixed " County" in the label items.
          // Defensive: a loaded trip's county is always in the list
          // for its kind, but never let a stale value crash the
          // dropdown if the lists ever change.
          DropdownButtonFormField<String>(
            value: _availableCounties.contains(_county)
                ? _county
                : _availableCounties.first,
            decoration: const InputDecoration(labelText: 'County'),
            items: _availableCounties
                .map(
                  (county) => DropdownMenuItem(
                    value: county,
                    child: Text('$county County'),
                  ),
                )
                .toList(),
            onChanged: _onCountyChanged,
          ),
          const SizedBox(height: 12),
          // Water dropdown for fish, free-text hunting area for hunting.
          if (_isFish)
            DropdownButtonFormField<String>(
              // Defensive: never hand the dropdown a value that is
              // not in its (now species-filtered) items.
              value: _availableWaters.contains(_water)
                  ? _water
                  : _availableWaters.first,
              decoration: const InputDecoration(labelText: 'Water'),
              items: _availableWaters
                  .map(
                    (water) => DropdownMenuItem(
                      value: water,
                      child: Text(water),
                    ),
                  )
                  .toList(),
              onChanged: (value) {
                if (value != null) setState(() => _water = value);
              },
            )
          else
            TextFormField(
              controller: _huntingAreaController,
              decoration: const InputDecoration(
                labelText: 'Hunting area',
                hintText: 'e.g. Kanawha State Forest, Ridge 3',
              ),
            ),
          // Weapon picker, hunting only. Changes the season verdict.
          if (_isHunt) ...[
            const SizedBox(height: 16),
            const Text('Weapon'),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: Weapon.values.map((weapon) {
                final selected = weapon == _weapon;
                return ChoiceChip(
                  label: Text(weapon.label),
                  selected: selected,
                  onSelected: (_) => setState(() => _weapon = weapon),
                );
              }).toList(),
            ),
          ],
          const SizedBox(height: 16),
          // Season verdict — SAMPLE DATA, always labelled as such.
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Can I go?',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _isFish
                        ? "You're clear to go."
                        : "You're clear to go. ${sampleSeasonWindow(_species, _weapon)}",
                  ),
                  if (_species == 'Coyote') ...[
                    const SizedBox(height: 8),
                    const Text(coyoteNote),
                  ],
                  const SizedBox(height: 8),
                  const Text(
                    'Sample data — check official WVDNR regulations. '
                    'Verified date: sample placeholder. '
                    'Source: WVDNR (placeholder — replace with the '
                    'verified source link in the real build).',
                    style: TextStyle(fontStyle: FontStyle.italic),
                  ),
                  const SizedBox(height: 8),
                  const Text(disclaimerShort),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          // Pack checklist.
          Text(
            _isHunt ? 'Firearm pack list' : 'Pack list',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          for (final item in pack)
            CheckboxListTile(
              value: _checkedPack.contains(item),
              onChanged: (checked) {
                setState(() {
                  if (checked == true) {
                    _checkedPack.add(item);
                  } else {
                    _checkedPack.remove(item);
                  }
                });
              },
              title: Text(item),
              controlAffinity: ListTileControlAffinity.leading,
              dense: true,
            ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () async {
                // Saving a trip now PERSISTS it in AppStore, so it
                // appears in Planned Trips and its calendar. Season
                // data is still SAMPLE — see the verdict card above.
                final place = _isFish
                    ? _water
                    : _huntingAreaController.text.trim();
                if (!_isFish && place.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Enter a hunting area before saving a '
                        'hunting trip.',
                      ),
                    ),
                  );
                  return;
                }
                await _store.addTrip(
                  Trip(
                    id: AppStore.newId(),
                    date: Trip.dateOnly(_tripDate),
                    species: _species,
                    isFish: _isFish,
                    county: _county,
                    place: place,
                    weapon: _isFish ? '' : _weapon.label,
                  ),
                );
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Trip saved. See Planned Trips. '
                        'Sample data only — check official WVDNR '
                        'regulations.',
                      ),
                    ),
                  );
                }
              },
              child: Text(_saveButtonText),
            ),
          ),
          const SizedBox(height: 16),
          // Disclaimer & user agreement card.
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Disclaimer & user agreement',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    widget.agreedAtIso != null
                        ? 'Agreed: ${widget.agreedAtIso!.substring(0, 10)}'
                        : 'Not yet agreed.',
                  ),
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: () {
                      showDialog<void>(
                        context: context,
                        builder: (_) => const DisclaimerReadOnlyDialog(),
                      );
                    },
                    child: const Text('Re-read disclaimer'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
