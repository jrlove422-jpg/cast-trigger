import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../data/app_store.dart';
import 'share_card_screen.dart';

/// Stats — DERIVED FROM LOGS ONLY. No hardcoded tiles.
/// Original three tiles: Trips, Fish caught, Wild Game Harvested.
/// NO Hours tile (removed 2026-11-04, do not re-add).
/// Personal bests are strictly split: fish bests only under Fish,
/// game bests only under Game.
/// Fix #11: Scout is now VISIBLE in Stats as a separate 4th tile
/// ("Scout spots") + tap-through list, derived from Scout logs
/// only. Scout counts are NEVER added into Trips, Fish caught, or
/// Wild Game Harvested — those three tiles' derivation is exactly
/// as before. Scout entries in Stats are view-only; edit/remove
/// stays in Spots.
/// Tapping a tile shows that category's logs and stored share cards
/// (Scout logs get no Share card button — they are view-only here).
class StatsScreen extends StatefulWidget {
  const StatsScreen({super.key});

  @override
  State<StatsScreen> createState() => _StatsScreenState();
}

class _StatsScreenState extends State<StatsScreen> {
  final AppStore _store = AppStore.instance;
  String _selected = 'trips'; // trips | fish | game | scout

  @override
  void initState() {
    super.initState();
    _store.load();
  }

  String _formatDate(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  String _monthLabel(String yyyyMm) {
    const names = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    final parts = yyyyMm.split('-');
    final month = int.tryParse(parts.length > 1 ? parts[1] : '') ?? 1;
    return '${names[month - 1]} ${parts[0]}';
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _store,
      builder: (context, _) {
        final tripsCount = _store.tripsCount;
        final fishCount = _store.fishCount;
        final gameCount = _store.gameCount;
        // Fix #11: Scout count, derived from Scout logs only.
        // This is a separate count — it is never added to any of
        // the three counts above.
        final scoutCount = _store.scoutLogs.length;
        final fishByMonth = _store.fishByMonth();
        final maxMonth = fishByMonth.isEmpty
            ? 1
            : fishByMonth
                .map((e) => e.value)
                .reduce((a, b) => a > b ? a : b);
        List<LogEntry> shown;
        String shownTitle;
        if (_selected == 'fish') {
          shown = _store.catchLogs.where((l) => l.isFish).toList();
          shownTitle = 'Fish caught';
        } else if (_selected == 'game') {
          shown = _store.catchLogs.where((l) => !l.isFish).toList();
          shownTitle = 'Wild Game Harvested';
        } else if (_selected == 'scout') {
          shown = _store.scoutLogs;
          shownTitle = 'Scout spots (not counted in Trips / Fish / Game)';
        } else {
          // Trips tile: one elapsed trip per Catch/Harvest log.
          shown = _store.catchLogs;
          shownTitle = 'Trips (one per log)';
        }
        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Stats',
                style: GoogleFonts.caveatBrush(fontSize: 30),
              ),
              const SizedBox(height: 4),
              const Text(
                'Derived from your logs. Scout spots are shown '
                'separately below and are not counted in Trips, '
                'Fish, or Game.',
                style: TextStyle(fontStyle: FontStyle.italic),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: _tile(
                      'Trips',
                      '$tripsCount',
                      _selected == 'trips',
                      () => setState(() => _selected = 'trips'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _tile(
                      'Fish caught',
                      '$fishCount',
                      _selected == 'fish',
                      () => setState(() => _selected = 'fish'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _tile(
                      'Wild Game Harvested',
                      '$gameCount',
                      _selected == 'game',
                      () => setState(() => _selected = 'game'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              // Fix #11: separate Scout tile, same style, second
              // row so the original three tiles are untouched.
              Row(
                children: [
                  Expanded(
                    child: _tile(
                      'Scout spots',
                      '$scoutCount',
                      _selected == 'scout',
                      () => setState(() => _selected = 'scout'),
                    ),
                  ),
                  const Expanded(child: SizedBox.shrink()),
                  const Expanded(child: SizedBox.shrink()),
                ],
              ),
              const SizedBox(height: 24),
              const Text(
                'Fish by month',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              if (fishByMonth.isEmpty)
                const Text('No fish logged yet.')
              else
                for (final entry in fishByMonth)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 80,
                          child: Text(_monthLabel(entry.key)),
                        ),
                        Expanded(
                          child: Container(
                            height: 18,
                            alignment: Alignment.centerLeft,
                            child: FractionallySizedBox(
                              widthFactor:
                                  entry.value / maxMonth,
                              child: Container(
                                color: const Color(0xFF6B8F5E),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text('${entry.value}'),
                      ],
                    ),
                  ),
              const SizedBox(height: 24),
              const Text(
                'Personal bests — Fish',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              if (_store.fishBests().isEmpty)
                const Text('No fish bests yet.')
              else
                for (final best in _store.fishBests()) Text('• $best'),
              const SizedBox(height: 16),
              const Text(
                'Personal bests — Wild Game',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              if (_store.gameBests().isEmpty)
                const Text('No game bests yet.')
              else
                for (final best in _store.gameBests()) Text('• $best'),
              const SizedBox(height: 24),
              Text(
                shownTitle,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              if (shown.isEmpty)
                const Text('Nothing here yet.')
              else
                for (final log in shown)
                  Card(
                    child: ListTile(
                      title: Text(log.species),
                      subtitle: Text(
                        '${_formatDate(log.date)} · ${log.place}, '
                        '${log.county} County',
                      ),
                      // Scout logs are view-only in Stats: no
                      // Share card button (Scout spots have no
                      // share card in Spots either). Edit/remove
                      // stays in Spots.
                      trailing: _selected == 'scout'
                          ? const Text('Scout')
                          : TextButton(
                              onPressed: () {
                                Navigator.of(context).push(
                                  MaterialPageRoute<void>(
                                    builder: (_) =>
                                        ShareCardScreen(log: log),
                                  ),
                                );
                              },
                              child: const Text('Share card'),
                            ),
                    ),
                  ),
            ],
          ),
        );
      },
    );
  }

  Widget _tile(
    String label,
    String value,
    bool selected,
    VoidCallback onTap,
  ) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: selected
              ? const Color(0xFF6B8F5E).withOpacity(0.35)
              : const Color(0xFF1E2429),
          border: Border.all(
            color: selected
                ? const Color(0xFFD4AF37)
                : Colors.white24,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Text(
              value,
              style: GoogleFonts.caveatBrush(fontSize: 30),
            ),
            Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
