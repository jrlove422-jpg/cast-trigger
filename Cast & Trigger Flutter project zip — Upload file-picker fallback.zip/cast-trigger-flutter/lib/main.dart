import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'data/app_store.dart';
import 'data/disclaimer.dart';
import 'screens/disclaimer_gate.dart';
import 'screens/license_screen.dart';
import 'screens/planned_trips_screen.dart';
import 'screens/planner_screen.dart';
import 'screens/spots_screen.dart';
import 'screens/stats_screen.dart';
import 'widgets/state_pill.dart';

/// Cast & Trigger — complete app: disclaimer gate + Planner +
/// Planned Trips + Spots (log feed) + Stats + My License.
/// The Planner (first tab) and the disclaimer gate (first screen
/// on first open) from Chunk 1 are kept intact; the other tabs
/// are no longer placeholders.
///
/// Working name only — NOT cleared. No trademark filing, domain
/// purchase, LLC, or entity work is included here. Prototype seasons
/// and waters are SAMPLE data, not official WVDNR regulations.
/// No AI bite predictions, no parcel maps, no social feed.
/// Private by default, offline-first, local storage only in this
/// chunk (no cloud sync, no accounts).
void main() {
  runApp(const CastTriggerApp());
}

class CastTriggerApp extends StatelessWidget {
  const CastTriggerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cast & Trigger',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF121417),
        // Prototype fonts: Caveat Brush for display, Barlow for body.
        textTheme: GoogleFonts.barlowTextTheme(
          ThemeData(brightness: Brightness.dark).textTheme,
        ),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF6B8F5E), // moss green
          secondary: Color(0xFFD4AF37), // gold
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF6B8F5E),
            foregroundColor: Colors.white,
          ),
        ),
      ),
      home: const _GateOrShell(),
    );
  }
}

/// Shows, in order: disclaimer gate on first open, then the optional
/// whole-app lock screen (only if the user turned that toggle on),
/// then the 5-tab app shell.
class _GateOrShell extends StatefulWidget {
  const _GateOrShell();

  @override
  State<_GateOrShell> createState() => _GateOrShellState();
}

class _GateOrShellState extends State<_GateOrShell> {
  final AppStore _store = AppStore.instance;
  String? _agreedAtIso;
  bool _loading = true;
  bool _appUnlocked = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final version = prefs.getString('disclaimer_agreement_version');
    final agreedAt = prefs.getString('disclaimer_agreed_at');
    await _store.load();
    if (mounted) {
      setState(() {
        // Only count an agreement saved under the current version.
        _agreedAtIso =
            (version == disclaimerVersion && agreedAt != null)
                ? agreedAt
                : null;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }
    if (_agreedAtIso == null) {
      return DisclaimerGateScreen(
        onAgreed: () {
          // Re-read the saved agreement so the Planner card shows it.
          _load();
        },
      );
    }
    // Whole-app lock (optional toggle, default off) applies on app
    // start only — it does not re-lock mid-session.
    if (_store.wholeAppLock && !_appUnlocked) {
      return AppLockScreen(
        onUnlocked: () => setState(() => _appUnlocked = true),
      );
    }
    return _AppShell(agreedAtIso: _agreedAtIso);
  }
}

/// 5-tab shell, in the spec order:
/// Planner, Planned Trips, Spots, Stats, My License.
class _AppShell extends StatefulWidget {
  const _AppShell({required this.agreedAtIso});

  final String? agreedAtIso;

  @override
  State<_AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<_AppShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset(
              'assets/cast-trigger-logo.webp',
              height: 36,
              errorBuilder: (context, error, stackTrace) =>
                  const SizedBox.shrink(),
            ),
            const SizedBox(width: 8),
            Text(
              'CAST & TRIGGER',
              style: GoogleFonts.caveatBrush(fontSize: 28),
            ),
          ],
        ),
        actions: const [StatePill()],
      ),
      body: IndexedStack(
        index: _index,
        children: [
          PlannerScreen(agreedAtIso: widget.agreedAtIso),
          PlannedTripsScreen(
            onLoadTrip: () => setState(() => _index = 0),
          ),
          const SpotsScreen(),
          const StatsScreen(),
          // My License re-authenticates on EVERY open: the shell
          // tells it whether this tab is currently selected.
          MyLicenseScreen(isActive: _index == 4),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        type: BottomNavigationBarType.fixed,
        onTap: (index) => setState(() => _index = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.map), label: 'Planner'),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today),
            label: 'Planned Trips',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.place), label: 'Spots'),
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart),
            label: 'Stats',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.badge),
            label: 'My License',
          ),
        ],
      ),
    );
  }
}
