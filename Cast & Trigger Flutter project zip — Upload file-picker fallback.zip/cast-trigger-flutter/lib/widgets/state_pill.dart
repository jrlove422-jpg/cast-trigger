import 'package:flutter/material.dart';

/// The WV pill in the upper-right corner of the app bar, on every screen.
/// Gold pill look, with a caret. Tapping opens the "Your state" menu.
/// WV is the only active state in v1. PA, OH, VA, KY, MD are grayed out
/// with "Coming soon" — tapping one shows a toast and does NOT switch.
/// Extra states are a Premium feature in a later chunk; no billing here.
class StatePill extends StatelessWidget {
  const StatePill({super.key});

  static const List<String> _comingSoon = ['PA', 'OH', 'VA', 'KY', 'MD'];

  static const Map<String, String> _fullNames = {
    'PA': 'Pennsylvania',
    'OH': 'Ohio',
    'VA': 'Virginia',
    'KY': 'Kentucky',
    'MD': 'Maryland',
  };

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: () => _showStateMenu(context),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
          decoration: BoxDecoration(
            border: Border.all(color: const Color(0xFF4D4225)),
            borderRadius: BorderRadius.circular(999),
          ),
          child: const Text(
            'WV ▾',
            style: TextStyle(
              color: Color(0xFFD4AF37),
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  void _showStateMenu(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Your state'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const ListTile(
                title: Text('WV — West Virginia'),
                trailing: Text('✓ Current'),
              ),
              const Divider(),
              for (final code in _comingSoon)
                ListTile(
                  title: Text(
                    '$code — ${_fullNames[code]}',
                    style: const TextStyle(color: Colors.grey),
                  ),
                  trailing: const Text(
                    'Coming soon',
                    style: TextStyle(color: Colors.grey),
                  ),
                  onTap: () {
                    Navigator.of(dialogContext).pop();
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          '${_fullNames[code]} is coming soon.',
                        ),
                      ),
                    );
                  },
                ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }
}
